#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include "server.h"
#include "database.h"
#include "analytics.h"

/* Case-insensitive string comparison */
static int ci_strcmp(const char *s1, const char *s2) {
    while (*s1 && *s2) {
        if (tolower((unsigned char)*s1) != tolower((unsigned char)*s2)) return 1;
        s1++; s2++;
    }
    return (*s1 == *s2) ? 0 : 1;
}

#define MAX_VAL(a, b) (((a) > (b)) ? (a) : (b))

#define BUFFER_SIZE (256 * 1024)
#define RESPONSE_SIZE (512 * 1024)

static char g_base_dir[512] = "";

static void send_response(SOCKET client, const char *status, const char *content_type, const char *body, int body_len) {
    char header[1024];
    int header_len = snprintf(header, sizeof(header),
        "HTTP/1.1 %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %d\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
        "Access-Control-Allow-Headers: Content-Type, Authorization\r\n"
        "X-Content-Type-Options: nosniff\r\n"
        "X-Frame-Options: SAMEORIGIN\r\n"
        "Connection: close\r\n\r\n",
        status, content_type, body_len);

    send(client, header, header_len, 0);
    send(client, body, body_len, 0);
}

static void send_response_with_cookie(SOCKET client, const char *status, const char *content_type, const char *body, int body_len, const char *cookie_str) {
    char header[1280];
    int header_len = snprintf(header, sizeof(header),
        "HTTP/1.1 %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %d\r\n"
        "Set-Cookie: %s; Path=/; SameSite=Strict\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
        "Access-Control-Allow-Headers: Content-Type, Authorization\r\n"
        "X-Content-Type-Options: nosniff\r\n"
        "X-Frame-Options: SAMEORIGIN\r\n"
        "Connection: close\r\n\r\n",
        status, content_type, body_len, cookie_str);

    send(client, header, header_len, 0);
    send(client, body, body_len, 0);
}

static const char* get_mime_type(const char *path) {
    const char *dot = strrchr(path, '.');
    if (!dot) return "application/octet-stream";
    if (strcmp(dot, ".html") == 0 || strcmp(dot, ".htm") == 0) return "text/html; charset=utf-8";
    if (strcmp(dot, ".css") == 0) return "text/css; charset=utf-8";
    if (strcmp(dot, ".js") == 0) return "application/javascript; charset=utf-8";
    if (strcmp(dot, ".json") == 0) return "application/json; charset=utf-8";
    if (strcmp(dot, ".png") == 0) return "image/png";
    if (strcmp(dot, ".jpg") == 0 || strcmp(dot, ".jpeg") == 0) return "image/jpeg";
    if (strcmp(dot, ".svg") == 0) return "image/svg+xml";
    if (strcmp(dot, ".ico") == 0) return "image/x-icon";
    if (strcmp(dot, ".csv") == 0) return "text/csv; charset=utf-8";
    if (strcmp(dot, ".pdf") == 0) return "application/pdf";
    return "text/plain; charset=utf-8";
}

static void send_file(SOCKET client, const char *filepath, const char *content_type) {
    /* 1. Prevent Directory Traversal */
    if (strstr(filepath, "..") != NULL) {
        const char *err = "<html><body><h1>403 Forbidden</h1><p>Access denied: Invalid file path traversal.</p></body></html>";
        send_response(client, "403 Forbidden", "text/html", err, (int)strlen(err));
        return;
    }

    char candidate[512];
    FILE *fp = fopen(filepath, "rb");
    if (!fp && g_base_dir[0]) {
        snprintf(candidate, sizeof(candidate), "%s/%s", g_base_dir, filepath);
        fp = fopen(candidate, "rb");
    }
    if (!fp) {
        snprintf(candidate, sizeof(candidate), "../%s", filepath);
        fp = fopen(candidate, "rb");
    }
    if (!fp && g_base_dir[0]) {
        snprintf(candidate, sizeof(candidate), "%s/../%s", g_base_dir, filepath);
        fp = fopen(candidate, "rb");
    }
    if (!fp) {
        char not_found[512];
        int nf_len = snprintf(not_found, sizeof(not_found),
            "<html><body><h1>404 Not Found</h1><p>Resource '%s' does not exist on this server.</p></body></html>", filepath);
        send_response(client, "404 Not Found", "text/html", not_found, nf_len);
        return;
    }

    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    char *buf = (char *)malloc(size + 1);
    if (!buf) {
        fclose(fp);
        const char *err = "500 Internal Error";
        send_response(client, "500 Internal Error", "text/plain", err, (int)strlen(err));
        return;
    }

    fread(buf, 1, size, fp);
    fclose(fp);

    send_response(client, "200 OK", content_type, buf, (int)size);
    free(buf);
}

static int get_query_param(const char *url, const char *param, char *out_val, size_t max_len) {
    const char *q = strchr(url, '?');
    if (!q) return 0;
    q++;

    size_t plen = strlen(param);
    const char *p = q;
    while (p && *p) {
        if (strncmp(p, param, plen) == 0 && p[plen] == '=') {
            const char *val_start = p + plen + 1;
            const char *val_end = strchr(val_start, '&');
            size_t vlen = val_end ? (size_t)(val_end - val_start) : strlen(val_start);
            if (vlen >= max_len) vlen = max_len - 1;
            strncpy(out_val, val_start, vlen);
            out_val[vlen] = '\0';
            return 1;
        }
        p = strchr(p, '&');
        if (p) p++;
    }
    return 0;
}

static int parse_json_string(const char *json, const char *key, char *out_val, size_t max_len) {
    char pattern[128];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char *pos = strstr(json, pattern);
    if (!pos) return 0;
    pos += strlen(pattern);
    while (*pos == ' ' || *pos == ':') pos++;
    if (*pos == '\"') {
        pos++;
        size_t idx = 0;
        while (*pos && idx < max_len - 1) {
            if (*pos == '\\' && *(pos + 1)) {
                pos++;
                if (*pos == 'n') out_val[idx++] = '\n';
                else if (*pos == 'r') out_val[idx++] = '\r';
                else if (*pos == 't') out_val[idx++] = '\t';
                else out_val[idx++] = *pos;
                pos++;
            } else if (*pos == '\"') {
                break;
            } else {
                out_val[idx++] = *pos++;
            }
        }
        out_val[idx] = '\0';
        return 1;
    }
    return 0;
}

static int parse_json_int(const char *json, const char *key, int default_val) {
    char pattern[128];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char *pos = strstr(json, pattern);
    if (!pos) return default_val;
    pos += strlen(pattern);
    while (*pos == ' ' || *pos == ':') pos++;
    return atoi(pos);
}

static float parse_json_float(const char *json, const char *key, float default_val) {
    char pattern[128];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char *pos = strstr(json, pattern);
    if (!pos) return default_val;
    pos += strlen(pattern);
    while (*pos == ' ' || *pos == ':') pos++;
    return (float)atof(pos);
}

/* Extract token from Authorization header, Cookie, or Query parameter */
static int extract_auth_token(const char *raw_request, const char *url, char *out_token, size_t max_len) {
    /* 1. Check Query parameter ?token=... */
    if (get_query_param(url, "token", out_token, max_len)) {
        if (strlen(out_token) > 0) return 1;
    }

    /* 2. Check Authorization: Bearer <token> */
    const char *auth = strstr(raw_request, "Authorization:");
    if (!auth) auth = strstr(raw_request, "authorization:");
    if (auth) {
        auth += 14;
        while (*auth == ' ') auth++;
        if (strncmp(auth, "Bearer ", 7) == 0) {
            auth += 7;
            while (*auth == ' ') auth++;
            const char *end = strstr(auth, "\r\n");
            size_t len = end ? (size_t)(end - auth) : strlen(auth);
            if (len >= max_len) len = max_len - 1;
            strncpy(out_token, auth, len);
            out_token[len] = '\0';
            return 1;
        }
    }

    /* 3. Check Cookie: session_token=<token> */
    const char *cookie = strstr(raw_request, "Cookie:");
    if (!cookie) cookie = strstr(raw_request, "cookie:");
    if (cookie) {
        const char *tpos = strstr(cookie, "session_token=");
        if (tpos) {
            tpos += 14;
            const char *end = strpbrk(tpos, ";\r\n");
            size_t len = end ? (size_t)(end - tpos) : strlen(tpos);
            if (len >= max_len) len = max_len - 1;
            strncpy(out_token, tpos, len);
            out_token[len] = '\0';
            return 1;
        }
    }

    out_token[0] = '\0';
    return 0;
}

/* Helper to trim leading & trailing whitespace */
static char* trim_whitespace(char *str) {
    while (isspace((unsigned char)*str)) str++;
    if (*str == 0) return str;
    char *end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) end--;
    end[1] = '\0';
    return str;
}

static void handle_api_request(SOCKET client, const char *raw_request, const char *method, const char *url, const char *body) {
    char json_resp[RESPONSE_SIZE];
    char auth_token[TOKEN_LEN] = {0};
    char session_user[ID_LEN] = {0};
    char session_role[16] = {0};

    extract_auth_token(raw_request, url, auth_token, sizeof(auth_token));
    int has_valid_session = validate_session_token(auth_token, session_user, session_role);

    /* ─── 0. OPTIONS Preflight ─── */
    if (strcmp(method, "OPTIONS") == 0) {
        send_response(client, "200 OK", "application/json", "{}", 2);
        return;
    }

    /* ─── 1. Student Login ─── */
    if (strcmp(method, "POST") == 0 && strstr(url, "/api/auth/student-login")) {
        char sid[ID_LEN] = {0}, pwd[PASS_LEN] = {0};
        parse_json_string(body, "student_id", sid, sizeof(sid));
        parse_json_string(body, "password", pwd, sizeof(pwd));

        if (strlen(sid) == 0 || strlen(pwd) == 0) {
            const char *err = "{\"success\":false,\"message\":\"Student ID and password are required.\"}";
            send_response(client, "400 Bad Request", "application/json", err, (int)strlen(err));
            return;
        }

        Student st;
        char new_token[TOKEN_LEN] = {0};
        int auth_res = authenticate_student(sid, pwd, &st, new_token);

        if (auth_res == 1) {
            char cookie_header[128];
            snprintf(cookie_header, sizeof(cookie_header), "session_token=%s", new_token);

            snprintf(json_resp, sizeof(json_resp),
                "{\"success\":true,\"token\":\"%s\",\"student\":{\"id\":\"%s\",\"name\":\"%s\",\"email\":\"%s\",\"dept\":\"%s\",\"semester\":%d,\"section\":\"%s\"}}",
                new_token, st.student_id, st.name, st.email, st.department, st.semester, st.section);
            send_response_with_cookie(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp), cookie_header);
        } else if (auth_res == -2) {
            const char *err = "{\"success\":false,\"message\":\"Account temporarily locked due to multiple failed attempts. Please retry after 10 minutes.\"}";
            send_response(client, "429 Too Many Requests", "application/json", err, (int)strlen(err));
        } else {
            const char *err = "{\"success\":false,\"message\":\"Invalid Student ID or password. Use demo UPES5000101 / student123.\"}";
            send_response(client, "401 Unauthorized", "application/json", err, (int)strlen(err));
        }
        return;
    }

    /* ─── 2. Faculty Login ─── */
    if (strcmp(method, "POST") == 0 && strstr(url, "/api/auth/faculty-login")) {
        char fid[ID_LEN] = {0}, pwd[PASS_LEN] = {0};
        parse_json_string(body, "faculty_id", fid, sizeof(fid));
        parse_json_string(body, "password", pwd, sizeof(pwd));

        if (strlen(fid) == 0 || strlen(pwd) == 0) {
            const char *err = "{\"success\":false,\"message\":\"Faculty ID / Email and password are required.\"}";
            send_response(client, "400 Bad Request", "application/json", err, (int)strlen(err));
            return;
        }

        Faculty f;
        char new_token[TOKEN_LEN] = {0};
        int auth_res = authenticate_faculty(fid, pwd, &f, new_token);

        if (auth_res == 1) {
            char cookie_header[128];
            snprintf(cookie_header, sizeof(cookie_header), "session_token=%s", new_token);

            snprintf(json_resp, sizeof(json_resp),
                "{\"success\":true,\"token\":\"%s\",\"faculty\":{\"id\":\"%s\",\"name\":\"%s\",\"email\":\"%s\",\"subjects\":\"%s\"}}",
                new_token, f.faculty_id, f.name, f.email, f.assigned_subjects);
            send_response_with_cookie(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp), cookie_header);
        } else if (auth_res == -2) {
            const char *err = "{\"success\":false,\"message\":\"Account temporarily locked due to multiple failed attempts. Please retry after 10 minutes.\"}";
            send_response(client, "429 Too Many Requests", "application/json", err, (int)strlen(err));
        } else {
            const char *err = "{\"success\":false,\"message\":\"Invalid Faculty ID or password. Use demo FAC101 / faculty123.\"}";
            send_response(client, "401 Unauthorized", "application/json", err, (int)strlen(err));
        }
        return;
    }

    /* ─── 3. Logout API ─── */
    if (strcmp(method, "POST") == 0 && strstr(url, "/api/auth/logout")) {
        if (strlen(auth_token) > 0) {
            destroy_session_token(auth_token);
        }
        const char *ok = "{\"success\":true,\"message\":\"Successfully logged out.\"}";
        send_response_with_cookie(client, "200 OK", "application/json", ok, (int)strlen(ok), "session_token=; Max-Age=0");
        return;
    }

    /* ─── 4. Student Dashboard Data ─── */
    if (strcmp(method, "GET") == 0 && strstr(url, "/api/student/dashboard")) {
        char sid[ID_LEN] = {0}, th_str[16] = {0};
        get_query_param(url, "id", sid, sizeof(sid));
        
        /* If no id supplied, use session user */
        if (strlen(sid) == 0 && has_valid_session && strcmp(session_role, "STUDENT") == 0) {
            strncpy(sid, session_user, ID_LEN - 1);
        }

        /* RBAC Check: If logged in as student, prevent snooping other students' records */
        if (has_valid_session && strcmp(session_role, "STUDENT") == 0 && strcmp(sid, session_user) != 0) {
            const char *err = "{\"success\":false,\"message\":\"Access denied: Students can only view their own attendance records.\"}";
            send_response(client, "403 Forbidden", "application/json", err, (int)strlen(err));
            return;
        }

        float threshold = 75.0f;
        if (get_query_param(url, "threshold", th_str, sizeof(th_str))) {
            threshold = (float)atof(th_str);
            if (threshold <= 0.0f) threshold = 75.0f;
        }

        Student *st = find_student_by_id(sid);
        if (!st) {
            const char *err = "{\"success\":false,\"message\":\"Student not found.\"}";
            send_response(client, "404 Not Found", "application/json", err, (int)strlen(err));
            return;
        }

        StudentDashboardData dash;
        get_student_dashboard_data(sid, threshold, &dash);

        int offset = snprintf(json_resp, sizeof(json_resp),
            "{\"success\":true,\"student\":{\"id\":\"%s\",\"name\":\"%s\",\"email\":\"%s\",\"dept\":\"%s\",\"semester\":%d,\"section\":\"%s\"},"
            "\"overall\":{\"conducted\":%d,\"attended\":%d,\"missed\":%d,\"percentage\":%.2f,\"threshold\":%.2f,\"is_eligible\":%s,\"classes_needed\":%d,\"allowable_leaves\":%d},"
            "\"subjects\":[",
            st->student_id, st->name, st->email, st->department, st->semester, st->section,
            dash.total_conducted, dash.total_attended, dash.total_missed, dash.overall_percentage,
            dash.required_threshold, dash.is_eligible ? "true" : "false",
            dash.overall_classes_needed, dash.overall_allowable_leaves);

        for (int i = 0; i < dash.subject_count; i++) {
            SubjectAnalytics *sa = &dash.subjects[i];
            offset += snprintf(json_resp + offset, sizeof(json_resp) - offset,
                "{\"code\":\"%s\",\"name\":\"%s\",\"attended\":%d,\"total\":%d,\"missed\":%d,\"percentage\":%.2f,\"is_eligible\":%s,\"classes_needed\":%d,\"allowable_leaves\":%d,\"remaining\":%d,\"is_achievable\":%s}%s",
                sa->subject_id, sa->subject_name, sa->attended, sa->total, sa->missed, sa->percentage,
                sa->is_eligible ? "true" : "false", sa->classes_needed, sa->allowable_leaves,
                sa->remaining_classes, sa->is_achievable ? "true" : "false",
                (i < dash.subject_count - 1) ? "," : "");
        }
        strcat(json_resp, "]}");
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 5. Student Attendance History ─── */
    if (strcmp(method, "GET") == 0 && strstr(url, "/api/student/history")) {
        char sid[ID_LEN] = {0}, sub[ID_LEN] = {0};
        get_query_param(url, "id", sid, sizeof(sid));
        get_query_param(url, "subject", sub, sizeof(sub));

        if (strlen(sid) == 0 && has_valid_session && strcmp(session_role, "STUDENT") == 0) {
            strncpy(sid, session_user, ID_LEN - 1);
        }

        if (has_valid_session && strcmp(session_role, "STUDENT") == 0 && strcmp(sid, session_user) != 0) {
            const char *err = "{\"success\":false,\"message\":\"Access denied: Students can only view their own history.\"}";
            send_response(client, "403 Forbidden", "application/json", err, (int)strlen(err));
            return;
        }

        AttendanceRecord recs[300];
        int count = get_student_attendance_history(sid, sub, recs, 300);

        int offset = snprintf(json_resp, sizeof(json_resp), "{\"success\":true,\"count\":%d,\"records\":[", count);
        for (int i = 0; i < count; i++) {
            Subject *sb = find_subject_by_id(recs[i].subject_id);
            const char *sb_name = sb ? sb->subject_name : recs[i].subject_id;
            offset += snprintf(json_resp + offset, sizeof(json_resp) - offset,
                "{\"id\":%d,\"subject_id\":\"%s\",\"subject_name\":\"%s\",\"date\":\"%s\",\"status\":\"%s\",\"updated_by\":\"%s\",\"last_updated\":\"%s\"}%s",
                recs[i].attendance_id, recs[i].subject_id, sb_name, recs[i].date, recs[i].status,
                recs[i].updated_by, recs[i].last_updated, (i < count - 1) ? "," : "");
        }
        strcat(json_resp, "]}");
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 6. Student Notifications ─── */
    if (strcmp(method, "GET") == 0 && strstr(url, "/api/student/notifications")) {
        char sid[ID_LEN] = {0};
        get_query_param(url, "id", sid, sizeof(sid));

        if (strlen(sid) == 0 && has_valid_session && strcmp(session_role, "STUDENT") == 0) {
            strncpy(sid, session_user, ID_LEN - 1);
        }

        Notification notifs[100];
        int unread = 0;
        int count = get_student_notifications(sid, notifs, 100, &unread);

        int offset = snprintf(json_resp, sizeof(json_resp), "{\"success\":true,\"unread_count\":%d,\"notifications\":[", unread);
        for (int i = 0; i < count; i++) {
            offset += snprintf(json_resp + offset, sizeof(json_resp) - offset,
                "{\"id\":%d,\"message\":\"%s\",\"subject_id\":\"%s\",\"type\":\"%s\",\"created_at\":\"%s\",\"read\":%s}%s",
                notifs[i].notification_id, notifs[i].message, notifs[i].subject_id, notifs[i].notification_type,
                notifs[i].created_at, notifs[i].read_status ? "true" : "false", (i < count - 1) ? "," : "");
        }
        strcat(json_resp, "]}");
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 7. Mark Notifications Read ─── */
    if (strcmp(method, "POST") == 0 && strstr(url, "/api/student/notifications/read")) {
        char sid[ID_LEN] = {0};
        get_query_param(url, "id", sid, sizeof(sid));
        if (strlen(sid) == 0) parse_json_string(body, "student_id", sid, sizeof(sid));
        if (strlen(sid) == 0 && has_valid_session) strncpy(sid, session_user, ID_LEN - 1);

        mark_notifications_read(sid);
        const char *ok = "{\"success\":true,\"message\":\"All notifications marked as read.\"}";
        send_response(client, "200 OK", "application/json", ok, (int)strlen(ok));
        return;
    }

    /* ─── 8. Recovery Calculator API ─── */
    if (strcmp(method, "POST") == 0 && strstr(url, "/api/student/calculator/recovery")) {
        int attended = parse_json_int(body, "attended", 0);
        int total = parse_json_int(body, "total", 0);
        float threshold = parse_json_float(body, "threshold", 75.0f);
        int planned = parse_json_int(body, "total_planned", 45);

        int needed = calculate_recovery_needed(attended, total, threshold);
        int remaining = MAX_VAL(0, planned - total);
        int achievable = check_recovery_achievable(needed, total, planned);

        float proj_pct = calculate_percentage(attended + needed, total + needed);

        snprintf(json_resp, sizeof(json_resp),
            "{\"success\":true,\"needed\":%d,\"projected_attended\":%d,\"projected_total\":%d,\"projected_pct\":%.2f,\"remaining_classes\":%d,\"is_achievable\":%s}",
            needed, attended + needed, total + needed, proj_pct, remaining, achievable ? "true" : "false");
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 9. Leave Calculator API (What-If) ─── */
    if (strcmp(method, "POST") == 0 && strstr(url, "/api/student/calculator/leave")) {
        int attended = parse_json_int(body, "attended", 0);
        int total = parse_json_int(body, "total", 0);
        int extra = parse_json_int(body, "extra_leaves", 1);
        float threshold = parse_json_float(body, "threshold", 75.0f);

        int max_leaves = calculate_allowable_leaves(attended, total, threshold);
        float proj_pct = 0.0f;
        int still_eligible = 0;
        simulate_hypothetical_leave(attended, total, extra, threshold, &proj_pct, &still_eligible);

        snprintf(json_resp, sizeof(json_resp),
            "{\"success\":true,\"allowable_leaves\":%d,\"extra_leaves\":%d,\"projected_total\":%d,\"projected_pct\":%.2f,\"is_still_eligible\":%s}",
            max_leaves, extra, total + extra, proj_pct, still_eligible ? "true" : "false");
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 10. Faculty Overview ─── */
    if (strcmp(method, "GET") == 0 && strstr(url, "/api/faculty/overview")) {
        int tot_st = 0, tot_sub = 0, tot_rec = 0, def_cnt = 0;
        get_faculty_overview(&tot_st, &tot_sub, &tot_rec, &def_cnt);

        snprintf(json_resp, sizeof(json_resp),
            "{\"success\":true,\"total_students\":%d,\"total_subjects\":%d,\"total_records\":%d,\"defaulters_count\":%d,\"eligible_count\":%d}",
            tot_st, tot_sub, tot_rec, def_cnt, tot_st - def_cnt);
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 11. Faculty Subjects List ─── */
    if (strcmp(method, "GET") == 0 && strstr(url, "/api/faculty/subjects")) {
        Subject subs[MAX_SUBJECTS];
        int count = get_all_subjects(subs, MAX_SUBJECTS);

        int offset = snprintf(json_resp, sizeof(json_resp), "{\"success\":true,\"subjects\":[");
        for (int i = 0; i < count; i++) {
            offset += snprintf(json_resp + offset, sizeof(json_resp) - offset,
                "{\"code\":\"%s\",\"name\":\"%s\",\"dept\":\"%s\",\"semester\":%d,\"planned\":%d}%s",
                subs[i].subject_id, subs[i].subject_name, subs[i].department, subs[i].semester,
                subs[i].total_planned, (i < count - 1) ? "," : "");
        }
        strcat(json_resp, "]}");
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 12. Faculty Roster for Manual Attendance ─── */
    if (strcmp(method, "GET") == 0 && strstr(url, "/api/faculty/roster")) {
        char sub[ID_LEN] = "CSE102", dt[DATE_LEN] = {0};
        get_query_param(url, "subject", sub, sizeof(sub));
        get_query_param(url, "date", dt, sizeof(dt));

        Student st_list[MAX_STUDENTS];
        char statuses[MAX_STUDENTS][STATUS_LEN];
        float pct_list[MAX_STUDENTS];
        int count = get_subject_roster(sub, dt, st_list, statuses, pct_list, MAX_STUDENTS);

        int offset = snprintf(json_resp, sizeof(json_resp), "{\"success\":true,\"subject\":\"%s\",\"date\":\"%s\",\"count\":%d,\"students\":[", sub, dt, count);
        for (int i = 0; i < count; i++) {
            offset += snprintf(json_resp + offset, sizeof(json_resp) - offset,
                "{\"id\":\"%s\",\"name\":\"%s\",\"percentage\":%.2f,\"status\":\"%s\"}%s",
                st_list[i].student_id, st_list[i].name, pct_list[i], statuses[i], (i < count - 1) ? "," : "");
        }
        strcat(json_resp, "]}");
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 13. Faculty Manual Attendance Submission ─── */
    if (strcmp(method, "POST") == 0 && strstr(url, "/api/faculty/attendance/manual")) {
        char sub_id[ID_LEN] = {0}, dt[DATE_LEN] = {0}, updated_by[ID_LEN] = "FAC101";
        parse_json_string(body, "subject_id", sub_id, sizeof(sub_id));
        parse_json_string(body, "date", dt, sizeof(dt));
        parse_json_string(body, "faculty_id", updated_by, sizeof(updated_by));
        if (has_valid_session && strlen(session_user) > 0) {
            strncpy(updated_by, session_user, ID_LEN - 1);
        }

        if (strlen(sub_id) == 0 || strlen(dt) == 0) {
            const char *err = "{\"success\":false,\"message\":\"Subject ID and Attendance Date are required.\"}";
            send_response(client, "400 Bad Request", "application/json", err, (int)strlen(err));
            return;
        }

        /* Parse array of records */
        int marked_count = 0;
        int updated_count = 0;
        const char *rec_pos = strstr(body, "\"records\":");
        if (rec_pos) {
            const char *item = strchr(rec_pos, '{');
            while (item) {
                const char *item_end = strchr(item, '}');
                if (!item_end) break;

                char item_buf[512] = {0};
                size_t ilen = (size_t)(item_end - item + 1);
                if (ilen < sizeof(item_buf)) {
                    strncpy(item_buf, item, ilen);
                    char sid[ID_LEN] = {0}, stat[STATUS_LEN] = "Present";
                    parse_json_string(item_buf, "student_id", sid, sizeof(sid));
                    parse_json_string(item_buf, "status", stat, sizeof(stat));
                    if (strlen(sid) > 0) {
                        int res = mark_or_update_attendance(sid, sub_id, dt, stat, updated_by);
                        if (res == 1) updated_count++;
                        else if (res == 2) marked_count++;
                    }
                }
                item = strchr(item_end, '{');
            }
        }

        snprintf(json_resp, sizeof(json_resp),
            "{\"success\":true,\"marked_count\":%d,\"updated_count\":%d,\"total_processed\":%d,\"message\":\"Attendance successfully synchronized (%d recorded, %d updated).\"}",
            marked_count, updated_count, marked_count + updated_count, marked_count, updated_count);
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 14. Faculty Attendance CSV/Excel Upload (Safe, Non-Strtok Parser) ─── */
    if (strcmp(method, "POST") == 0 && strstr(url, "/api/faculty/attendance/upload")) {
        char sub_id[ID_LEN] = {0}, faculty_id[ID_LEN] = "FAC101", fname[FILENAME_LEN] = "upload.csv";
        parse_json_string(body, "subject_id", sub_id, sizeof(sub_id));
        parse_json_string(body, "faculty_id", faculty_id, sizeof(faculty_id));
        parse_json_string(body, "file_name", fname, sizeof(fname));
        if (has_valid_session && strlen(session_user) > 0) {
            strncpy(faculty_id, session_user, ID_LEN - 1);
        }

        char *csv_content = (char *)malloc(BUFFER_SIZE);
        if (!csv_content) {
            const char *err = "{\"success\":false,\"message\":\"Out of memory while processing upload.\"}";
            send_response(client, "500 Internal Error", "application/json", err, (int)strlen(err));
            return;
        }
        memset(csv_content, 0, BUFFER_SIZE);
        parse_json_string(body, "csv_data", csv_content, BUFFER_SIZE);

        if (strlen(csv_content) == 0) {
            free(csv_content);
            const char *err = "{\"success\":false,\"message\":\"Uploaded file data is empty.\"}";
            send_response(client, "400 Bad Request", "application/json", err, (int)strlen(err));
            return;
        }

        int processed = 0, duplicates_updated = 0, rejected = 0;
        char errors_json[8192] = "[";
        int err_offset = 1;

        /* SAFE LINE-BY-LINE PARSER (NO NESTED STRTOK) */
        char *cursor = csv_content;
        int line_num = 0;

        while (*cursor) {
            line_num++;
            /* Find end of line */
            char *line_start = cursor;
            char *line_end = strpbrk(line_start, "\r\n");
            if (line_end) {
                *line_end = '\0';
                cursor = line_end + 1;
                while (*cursor == '\r' || *cursor == '\n') cursor++;
            } else {
                cursor += strlen(cursor);
            }

            char *line = trim_whitespace(line_start);
            if (strlen(line) == 0) continue;

            /* Skip CSV Header */
            if (line_num == 1 && (strstr(line, "student_id") || strstr(line, "Student ID") || strstr(line, "RollNo"))) {
                continue;
            }

            /* Split by comma safely */
            char cols[6][64];
            int col_count = 0;
            char *tok = line;
            while (tok && col_count < 6) {
                char *next_tok = strchr(tok, ',');
                if (next_tok) {
                    *next_tok = '\0';
                    strncpy(cols[col_count], trim_whitespace(tok), 63);
                    cols[col_count][63] = '\0';
                    tok = next_tok + 1;
                } else {
                    strncpy(cols[col_count], trim_whitespace(tok), 63);
                    cols[col_count][63] = '\0';
                    tok = NULL;
                }
                col_count++;
            }

            if (col_count < 3) {
                rejected++;
                if (err_offset < (int)sizeof(errors_json) - 128) {
                    err_offset += snprintf(errors_json + err_offset, sizeof(errors_json) - err_offset,
                        "%s\"Row %d: Missing required columns (expected StudentID, Date, Status)\"",
                        (rejected > 1 ? "," : ""), line_num);
                }
                continue;
            }

            char sid[ID_LEN] = {0}, dt[DATE_LEN] = {0}, stat[STATUS_LEN] = "Present", sub_cur[ID_LEN] = {0};

            /* Determine column positions based on count:
               Format A: student_id, name, date, status (4 cols)
               Format B: student_id, name, subject, date, status (5 cols)
               Format C: student_id, date, status (3 cols)
            */
            if (col_count == 3) {
                strncpy(sid, cols[0], ID_LEN - 1);
                strncpy(dt, cols[1], DATE_LEN - 1);
                strncpy(stat, cols[2], STATUS_LEN - 1);
            } else if (col_count == 4) {
                strncpy(sid, cols[0], ID_LEN - 1);
                /* cols[1] is name */
                strncpy(dt, cols[2], DATE_LEN - 1);
                strncpy(stat, cols[3], STATUS_LEN - 1);
            } else {
                strncpy(sid, cols[0], ID_LEN - 1);
                /* cols[1] is name */
                strncpy(sub_cur, cols[2], ID_LEN - 1);
                strncpy(dt, cols[3], DATE_LEN - 1);
                strncpy(stat, cols[4], STATUS_LEN - 1);
            }

            if (strlen(sub_cur) == 0) {
                strncpy(sub_cur, sub_id, ID_LEN - 1);
            }

            /* Normalize status: 'P' -> 'Present', 'A' -> 'Absent' */
            if (ci_strcmp(stat, "p") == 0 || ci_strcmp(stat, "present") == 0) strcpy(stat, "Present");
            else if (ci_strcmp(stat, "a") == 0 || ci_strcmp(stat, "absent") == 0) strcpy(stat, "Absent");
            else {
                rejected++;
                if (err_offset < (int)sizeof(errors_json) - 128) {
                    err_offset += snprintf(errors_json + err_offset, sizeof(errors_json) - err_offset,
                        "%s\"Row %d: Invalid status '%s' (must be Present or Absent)\"",
                        (rejected > 1 ? "," : ""), line_num, stat);
                }
                continue;
            }

            /* Validate student exists in CSE roster */
            if (!find_student_by_id(sid)) {
                rejected++;
                if (err_offset < (int)sizeof(errors_json) - 128) {
                    err_offset += snprintf(errors_json + err_offset, sizeof(errors_json) - err_offset,
                        "%s\"Row %d: Student ID '%s' not registered in database\"",
                        (rejected > 1 ? "," : ""), line_num, sid);
                }
                continue;
            }

            /* Validate subject exists */
            if (!find_subject_by_id(sub_cur)) {
                rejected++;
                if (err_offset < (int)sizeof(errors_json) - 128) {
                    err_offset += snprintf(errors_json + err_offset, sizeof(errors_json) - err_offset,
                        "%s\"Row %d: Subject ID '%s' is invalid\"",
                        (rejected > 1 ? "," : ""), line_num, sub_cur);
                }
                continue;
            }

            /* Apply record */
            int res = mark_or_update_attendance(sid, sub_cur, dt, stat, faculty_id);
            if (res == 1) duplicates_updated++;
            if (res > 0) processed++;
        }

        strcat(errors_json, "]");
        free(csv_content);

        const char *status_str = (processed > 0) ? (rejected > 0 ? "Partial" : "Success") : "Failed";
        save_upload_history_record(faculty_id, sub_id, fname, processed, status_str);

        snprintf(json_resp, sizeof(json_resp),
            "{\"success\":%s,\"processed\":%d,\"duplicates_updated\":%d,\"rejected\":%d,\"errors\":%s,\"message\":\"Successfully processed %d records (%d updated, %d rejected).\"}",
            (processed > 0) ? "true" : "false",
            processed, duplicates_updated, rejected, errors_json, processed, duplicates_updated, rejected);
        send_response(client, (processed > 0) ? "200 OK" : "400 Bad Request", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 15. Faculty Reports API ─── */
    if (strcmp(method, "GET") == 0 && strstr(url, "/api/faculty/reports")) {
        char report_type[32] = "low_attendance";
        get_query_param(url, "type", report_type, sizeof(report_type));

        Student st_list[MAX_STUDENTS];
        int st_count = get_all_students(st_list, MAX_STUDENTS);

        int offset = snprintf(json_resp, sizeof(json_resp), "{\"success\":true,\"report_type\":\"%s\",\"students\":[", report_type);
        int matched = 0;

        for (int i = 0; i < st_count; i++) {
            StudentDashboardData dash;
            get_student_dashboard_data(st_list[i].student_id, 75.0f, &dash);

            int include = 0;
            if (strcmp(report_type, "low_attendance") == 0) {
                if (dash.overall_percentage < 75.0f) include = 1;
            } else if (strcmp(report_type, "eligible") == 0) {
                if (dash.overall_percentage >= 75.0f) include = 1;
            } else {
                include = 1; /* all */
            }

            if (include) {
                if (matched > 0) {
                    offset += snprintf(json_resp + offset, sizeof(json_resp) - offset, ",");
                }
                offset += snprintf(json_resp + offset, sizeof(json_resp) - offset,
                    "{\"id\":\"%s\",\"name\":\"%s\",\"dept\":\"%s\",\"semester\":%d,\"section\":\"%s\",\"attended\":%d,\"conducted\":%d,\"percentage\":%.2f,\"status\":\"%s\",\"classes_needed\":%d,\"allowable_leaves\":%d}",
                    st_list[i].student_id, st_list[i].name, st_list[i].department, st_list[i].semester, st_list[i].section,
                    dash.total_attended, dash.total_conducted, dash.overall_percentage,
                    dash.is_eligible ? "Eligible" : "Defaulter", dash.overall_classes_needed, dash.overall_allowable_leaves);
                matched++;
            }
        }
        strcat(json_resp, "]}");
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── 16. Faculty Upload History ─── */
    if (strcmp(method, "GET") == 0 && strstr(url, "/api/faculty/upload-history")) {
        UploadRecord uploads[100];
        int count = get_upload_history_records(uploads, 100);

        int offset = snprintf(json_resp, sizeof(json_resp), "{\"success\":true,\"count\":%d,\"history\":[", count);
        for (int i = 0; i < count; i++) {
            offset += snprintf(json_resp + offset, sizeof(json_resp) - offset,
                "{\"id\":%d,\"faculty\":\"%s\",\"subject\":\"%s\",\"file\":\"%s\",\"date\":\"%s\",\"records\":%d,\"status\":\"%s\"}%s",
                uploads[i].upload_id, uploads[i].faculty_id, uploads[i].subject_id, uploads[i].file_name,
                uploads[i].upload_date, uploads[i].record_count, uploads[i].upload_status, (i < count - 1) ? "," : "");
        }
        strcat(json_resp, "]}");
        send_response(client, "200 OK", "application/json", json_resp, (int)strlen(json_resp));
        return;
    }

    /* ─── Default API 404 ─── */
    const char *err = "{\"success\":false,\"message\":\"API endpoint not found.\"}";
    send_response(client, "404 Not Found", "application/json", err, (int)strlen(err));
}

int start_upes_http_server(int port) {
    GetModuleFileNameA(NULL, g_base_dir, sizeof(g_base_dir));
    char *last_slash = strrchr(g_base_dir, '\\');
    if (!last_slash) last_slash = strrchr(g_base_dir, '/');
    if (last_slash) *last_slash = '\0';

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        printf("[ERROR] Winsock initialization failed: %d\n", WSAGetLastError());
        return 1;
    }

    SOCKET server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == INVALID_SOCKET) {
        printf("[ERROR] Socket creation failed: %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    int opt = 1;
    setsockopt(server_sock, SOL_SOCKET, SO_REUSEADDR, (const char *)&opt, sizeof(opt));

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons((u_short)port);

    if (bind(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        printf("[ERROR] Bind to port %d failed: %d\n", port, WSAGetLastError());
        closesocket(server_sock);
        WSACleanup();
        return 1;
    }

    if (listen(server_sock, 15) == SOCKET_ERROR) {
        printf("[ERROR] Listen failed: %d\n", WSAGetLastError());
        closesocket(server_sock);
        WSACleanup();
        return 1;
    }

    printf("\n=======================================================================\n");
    printf("   UPES Student Attendance Analysis System (C HTTP Engine v2.0)        \n");
    printf("=======================================================================\n");
    printf(" [STATUS] C Web Server is LIVE and listening at:\n");
    printf("          >> http://localhost:%d\n\n", port);
    printf(" [SECURITY] SHA-256 Hashing, Session Management & Rate Limiting ACTIVE\n");
    printf(" [STORAGE] Persistent Relational Storage active in /data\n");
    printf(" [DEMO ACCOUNTS]:\n");
    printf("   - Student Portal:  UPES5000101 / student123\n");
    printf("   - Faculty Portal:  FAC101 / faculty123\n\n");
    printf(" Press Ctrl+C in terminal to stop server.\n");
    printf("=======================================================================\n\n");

    char *recv_buf = (char *)malloc(BUFFER_SIZE);
    if (!recv_buf) {
        printf("[FATAL] Unable to allocate HTTP receive buffer.\n");
        return 1;
    }

    while (1) {
        struct sockaddr_in client_addr;
        int client_len = sizeof(client_addr);
        SOCKET client_sock = accept(server_sock, (struct sockaddr *)&client_addr, &client_len);
        if (client_sock == INVALID_SOCKET) continue;

        int total_bytes = 0;
        int bytes_recv = recv(client_sock, recv_buf, BUFFER_SIZE - 1, 0);
        if (bytes_recv <= 0) {
            closesocket(client_sock);
            continue;
        }
        total_bytes = bytes_recv;
        recv_buf[total_bytes] = '\0';

        /* FULL SOCKET READ LOOP FOR POST BODIES (USING CONTENT-LENGTH) */
        char *header_end = strstr(recv_buf, "\r\n\r\n");
        if (header_end) {
            const char *cl_pos = strstr(recv_buf, "Content-Length:");
            if (!cl_pos) cl_pos = strstr(recv_buf, "content-length:");
            if (cl_pos) {
                cl_pos += 15;
                while (*cl_pos == ' ') cl_pos++;
                int expected_content_len = atoi(cl_pos);
                int body_already_read = (int)(total_bytes - ((header_end + 4) - recv_buf));

                while (body_already_read < expected_content_len && total_bytes < BUFFER_SIZE - 1) {
                    int more = recv(client_sock, recv_buf + total_bytes, BUFFER_SIZE - 1 - total_bytes, 0);
                    if (more <= 0) break;
                    total_bytes += more;
                    body_already_read += more;
                    recv_buf[total_bytes] = '\0';
                }
            }
        }

        char method[16] = {0}, url[256] = {0};
        sscanf(recv_buf, "%15s %255s", method, url);

        /* Find start of body (after \r\n\r\n) */
        char *body = strstr(recv_buf, "\r\n\r\n");
        if (body) {
            body += 4;
        } else {
            body = "";
        }

        /* Clean path: strip query params */
        char clean_path[256];
        strncpy(clean_path, url, sizeof(clean_path) - 1);
        clean_path[sizeof(clean_path) - 1] = '\0';
        char *qmark = strchr(clean_path, '?');
        if (qmark) *qmark = '\0';

        /* Routing */
        if (strncmp(url, "/api/", 5) == 0) {
            handle_api_request(client_sock, recv_buf, method, url, body);
        } else if (strcmp(clean_path, "/") == 0 || strcmp(clean_path, "/index.html") == 0) {
            send_file(client_sock, "web_ui/index.html", "text/html; charset=utf-8");
        } else if (strcmp(clean_path, "/student-login") == 0 || strcmp(clean_path, "/student_login.html") == 0 || strcmp(clean_path, "/student_login") == 0) {
            send_file(client_sock, "web_ui/student_login.html", "text/html; charset=utf-8");
        } else if (strcmp(clean_path, "/faculty-login") == 0 || strcmp(clean_path, "/faculty_login.html") == 0 || strcmp(clean_path, "/faculty_login") == 0) {
            send_file(client_sock, "web_ui/faculty_login.html", "text/html; charset=utf-8");
        } else if (strcmp(clean_path, "/student-portal") == 0 || strcmp(clean_path, "/student_dashboard.html") == 0 || strcmp(clean_path, "/student_dashboard") == 0) {
            send_file(client_sock, "web_ui/student_dashboard.html", "text/html; charset=utf-8");
        } else if (strcmp(clean_path, "/faculty-portal") == 0 || strcmp(clean_path, "/faculty_dashboard.html") == 0 || strcmp(clean_path, "/faculty_dashboard") == 0) {
            send_file(client_sock, "web_ui/faculty_dashboard.html", "text/html; charset=utf-8");
        } else if (strcmp(clean_path, "/template/sample_attendance.csv") == 0 || strcmp(clean_path, "/upes_attendance_template.csv") == 0) {
            send_file(client_sock, "sample_templates/upes_attendance_template.csv", "text/csv; charset=utf-8");
        } else {
            /* General static file handler */
            const char *subpath = clean_path;
            while (*subpath == '/') subpath++;

            /* Strip leading "static/" if present */
            if (strncmp(subpath, "static/", 7) == 0) subpath += 7;

            char target_file[512];
            snprintf(target_file, sizeof(target_file), "web_ui/%s", subpath);
            const char *mime = get_mime_type(target_file);
            send_file(client_sock, target_file, mime);
        }

        closesocket(client_sock);
    }

    free(recv_buf);
    closesocket(server_sock);
    WSACleanup();
    return 0;
}
