#ifndef MODELS_H
#define MODELS_H

#include <time.h>

#define MAX_STUDENTS 100
#define MAX_FACULTY 10
#define MAX_SUBJECTS 10
#define MAX_ATTENDANCE_RECORDS 10000
#define MAX_NOTIFICATIONS 2000
#define MAX_UPLOADS 500
#define MAX_SESSIONS 100
#define MAX_AUDIT_LOGS 1000
#define MAX_ASSIGNMENTS 500

#define ID_LEN 32
#define NAME_LEN 64
#define EMAIL_LEN 64
#define PASS_LEN 64
#define HASH_LEN 68
#define SALT_LEN 32
#define DEPT_LEN 16
#define DATE_LEN 16
#define STATUS_LEN 16
#define MSG_LEN 256
#define FILENAME_LEN 128
#define TOKEN_LEN 68

typedef struct {
    char student_id[ID_LEN];
    char name[NAME_LEN];
    char email[EMAIL_LEN];
    char password_hash[HASH_LEN];
    char salt[SALT_LEN];
    char department[DEPT_LEN];
    int semester;
    char section[16];
} Student;

typedef struct {
    char faculty_id[ID_LEN];
    char name[NAME_LEN];
    char email[EMAIL_LEN];
    char password_hash[HASH_LEN];
    char salt[SALT_LEN];
    char assigned_subjects[128]; /* comma-separated subject IDs */
} Faculty;

typedef struct {
    char subject_id[ID_LEN];
    char subject_name[NAME_LEN];
    char department[DEPT_LEN];
    int semester;
    int total_planned; /* e.g. 45 classes */
} Subject;

typedef struct {
    char student_id[ID_LEN];
    char subject_id[ID_LEN];
} StudentSubjectAssignment;

typedef struct {
    int attendance_id;
    char student_id[ID_LEN];
    char subject_id[ID_LEN];
    char date[DATE_LEN];        /* YYYY-MM-DD */
    char status[STATUS_LEN];    /* "Present" or "Absent" */
    char updated_by[ID_LEN];
    char last_updated[32];      /* Timestamp */
} AttendanceRecord;

typedef struct {
    int notification_id;
    char student_id[ID_LEN];
    char message[MSG_LEN];
    char subject_id[ID_LEN];
    char notification_type[32]; /* "attendance_marked", "attendance_updated", "warning", "info" */
    char created_at[32];
    int read_status;            /* 0: Unread, 1: Read */
} Notification;

typedef struct {
    int upload_id;
    char faculty_id[ID_LEN];
    char subject_id[ID_LEN];
    char file_name[FILENAME_LEN];
    char upload_date[32];
    int record_count;
    char upload_status[32];     /* "Success", "Partial", "Failed" */
} UploadRecord;

typedef struct {
    char token[TOKEN_LEN];
    char user_id[ID_LEN];
    char role[16];             /* "STUDENT" or "FACULTY" */
    time_t expires_at;
    char created_at[32];
} UserSession;

typedef struct {
    char identifier[ID_LEN];
    int failed_count;
    time_t last_attempt;
} LoginAttempt;

typedef struct {
    int log_id;
    char action[32];           /* "MARK", "UPDATE", "UPLOAD" */
    char user_id[ID_LEN];
    char target_student[ID_LEN];
    char subject_id[ID_LEN];
    char date[DATE_LEN];
    char old_status[STATUS_LEN];
    char new_status[STATUS_LEN];
    char timestamp[32];
} AuditLog;

/* Computed analytics for API serialization */
typedef struct {
    char subject_id[ID_LEN];
    char subject_name[NAME_LEN];
    int attended;
    int total;
    int missed;
    float percentage;
    int is_eligible;            /* 1 if >= 75%, 0 otherwise */
    int classes_needed;         /* n = ceil((R*T - A)/(1 - R)) */
    int allowable_leaves;       /* x = floor((A/R) - T) */
    int remaining_classes;
    int is_achievable;          /* 1 if needed <= remaining_classes */
} SubjectAnalytics;

typedef struct {
    int total_conducted;
    int total_attended;
    int total_missed;
    float overall_percentage;
    float required_threshold;   /* 75.0% */
    int is_eligible;
    int overall_classes_needed;
    int overall_allowable_leaves;
    SubjectAnalytics subjects[MAX_SUBJECTS];
    int subject_count;
} StudentDashboardData;

#endif /* MODELS_H */
