#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "database.h"
#include "analytics.h"
#include "sha256.h"

#define MAX_VAL(a, b) (((a) > (b)) ? (a) : (b))

static Student g_students[MAX_STUDENTS];
static int g_student_count = 0;

static Faculty g_faculty[MAX_FACULTY];
static int g_faculty_count = 0;

static Subject g_subjects[MAX_SUBJECTS];
static int g_subject_count = 0;

static AttendanceRecord g_attendance[MAX_ATTENDANCE_RECORDS];
static int g_attendance_count = 0;

static Notification g_notifications[MAX_NOTIFICATIONS];
static int g_notification_count = 0;

static UploadRecord g_uploads[MAX_UPLOADS];
static int g_upload_count = 0;

static UserSession g_sessions[MAX_SESSIONS];
static int g_session_count = 0;

static LoginAttempt g_attempts[MAX_STUDENTS + MAX_FACULTY];
static int g_attempt_count = 0;

static AuditLog g_audit_logs[MAX_AUDIT_LOGS];
static int g_audit_count = 0;

static void get_current_timestamp(char *buf, size_t max_len) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    strftime(buf, max_len, "%Y-%m-%d %H:%M:%S", t);
}

static void generate_token(char *out_token, size_t max_len) {
    static int counter = 0;
    counter++;
    char seed_str[128];
    snprintf(seed_str, sizeof(seed_str), "%ld-%d-%d-%u", (long)time(NULL), rand(), counter, (unsigned int)clock());
    char hash[65];
    sha256_hash_string(seed_str, hash);
    strncpy(out_token, hash, max_len - 1);
    out_token[max_len - 1] = '\0';
}

/* ============================================================================
   RATE LIMITING
   ============================================================================ */
int is_rate_limited(const char *identifier) {
    time_t now = time(NULL);
    for (int i = 0; i < g_attempt_count; i++) {
        if (strcmp(g_attempts[i].identifier, identifier) == 0) {
            /* If 5+ failed attempts and within 10 minutes (600s), rate limit */
            if (g_attempts[i].failed_count >= 5) {
                if (now - g_attempts[i].last_attempt < 600) {
                    return 1;
                } else {
                    /* Window expired, reset counter */
                    g_attempts[i].failed_count = 0;
                    return 0;
                }
            }
            return 0;
        }
    }
    return 0;
}

void record_failed_login(const char *identifier) {
    time_t now = time(NULL);
    for (int i = 0; i < g_attempt_count; i++) {
        if (strcmp(g_attempts[i].identifier, identifier) == 0) {
            g_attempts[i].failed_count++;
            g_attempts[i].last_attempt = now;
            return;
        }
    }
    if (g_attempt_count < (int)(sizeof(g_attempts)/sizeof(g_attempts[0]))) {
        strncpy(g_attempts[g_attempt_count].identifier, identifier, ID_LEN - 1);
        g_attempts[g_attempt_count].failed_count = 1;
        g_attempts[g_attempt_count].last_attempt = now;
        g_attempt_count++;
    }
}

void reset_failed_logins(const char *identifier) {
    for (int i = 0; i < g_attempt_count; i++) {
        if (strcmp(g_attempts[i].identifier, identifier) == 0) {
            g_attempts[i].failed_count = 0;
            return;
        }
    }
}

/* ============================================================================
   AUDIT TRAIL
   ============================================================================ */
void add_audit_log(const char *action, const char *user_id, const char *target_student, const char *subject_id,
                   const char *date, const char *old_status, const char *new_status) {
    if (g_audit_count >= MAX_AUDIT_LOGS) return;
    AuditLog *log = &g_audit_logs[g_audit_count++];
    log->log_id = g_audit_count;
    strncpy(log->action, action ? action : "INFO", 31);
    strncpy(log->user_id, user_id ? user_id : "SYSTEM", ID_LEN - 1);
    strncpy(log->target_student, target_student ? target_student : "-", ID_LEN - 1);
    strncpy(log->subject_id, subject_id ? subject_id : "-", ID_LEN - 1);
    strncpy(log->date, date ? date : "-", DATE_LEN - 1);
    strncpy(log->old_status, old_status ? old_status : "-", STATUS_LEN - 1);
    strncpy(log->new_status, new_status ? new_status : "-", STATUS_LEN - 1);
    get_current_timestamp(log->timestamp, sizeof(log->timestamp));
}

/* ============================================================================
   SESSIONS
   ============================================================================ */
int validate_session_token(const char *token, char *out_user_id, char *out_role) {
    if (!token || strlen(token) == 0) return 0;
    time_t now = time(NULL);

    for (int i = 0; i < g_session_count; i++) {
        if (strcmp(g_sessions[i].token, token) == 0) {
            if (now > g_sessions[i].expires_at) {
                /* Expired: remove it */
                for (int j = i; j < g_session_count - 1; j++) {
                    g_sessions[j] = g_sessions[j + 1];
                }
                g_session_count--;
                return 0;
            }
            if (out_user_id) strncpy(out_user_id, g_sessions[i].user_id, ID_LEN - 1);
            if (out_role) strncpy(out_role, g_sessions[i].role, 15);
            return 1;
        }
    }
    return 0;
}

static int create_session(const char *user_id, const char *role, char *out_token) {
    char token[TOKEN_LEN];
    generate_token(token, sizeof(token));

    /* Remove oldest session if full */
    if (g_session_count >= MAX_SESSIONS) {
        for (int i = 0; i < MAX_SESSIONS - 1; i++) {
            g_sessions[i] = g_sessions[i + 1];
        }
        g_session_count = MAX_SESSIONS - 1;
    }

    UserSession *s = &g_sessions[g_session_count++];
    strncpy(s->token, token, TOKEN_LEN - 1);
    strncpy(s->user_id, user_id, ID_LEN - 1);
    strncpy(s->role, role, 15);
    s->expires_at = time(NULL) + (24 * 3600); /* 24 hours */
    get_current_timestamp(s->created_at, sizeof(s->created_at));

    if (out_token) strcpy(out_token, token);
    return 1;
}

int destroy_session_token(const char *token) {
    if (!token) return 0;
    for (int i = 0; i < g_session_count; i++) {
        if (strcmp(g_sessions[i].token, token) == 0) {
            for (int j = i; j < g_session_count - 1; j++) {
                g_sessions[j] = g_sessions[j + 1];
            }
            g_session_count--;
            return 1;
        }
    }
    return 0;
}

/* ============================================================================
   LOOKUPS
   ============================================================================ */
Subject* find_subject_by_id(const char *subject_id) {
    if (!subject_id) return NULL;
    for (int i = 0; i < g_subject_count; i++) {
        if (strcmp(g_subjects[i].subject_id, subject_id) == 0) {
            return &g_subjects[i];
        }
    }
    return NULL;
}

Student* find_student_by_id(const char *student_id) {
    if (!student_id) return NULL;
    for (int i = 0; i < g_student_count; i++) {
        if (strcmp(g_students[i].student_id, student_id) == 0) {
            return &g_students[i];
        }
    }
    return NULL;
}

Faculty* find_faculty_by_id(const char *faculty_id) {
    if (!faculty_id) return NULL;
    for (int i = 0; i < g_faculty_count; i++) {
        if (strcmp(g_faculty[i].faculty_id, faculty_id) == 0 ||
            strcmp(g_faculty[i].email, faculty_id) == 0) {
            return &g_faculty[i];
        }
    }
    return NULL;
}

/* ============================================================================
   NOTIFICATIONS
   ============================================================================ */
void add_notification(const char *student_id, const char *message, const char *subject_id, const char *type) {
    if (!student_id || !message) return;

    /* Prevent duplicate notifications for identical student + message on same day */
    char today[DATE_LEN];
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    strftime(today, sizeof(today), "%Y-%m-%d", t);

    for (int i = g_notification_count - 1; i >= 0 && i >= g_notification_count - 20; i--) {
        if (strcmp(g_notifications[i].student_id, student_id) == 0 &&
            strcmp(g_notifications[i].message, message) == 0 &&
            strncmp(g_notifications[i].created_at, today, 10) == 0) {
            return; /* Duplicate prevented */
        }
    }

    if (g_notification_count >= MAX_NOTIFICATIONS) return;
    Notification *n = &g_notifications[g_notification_count++];
    n->notification_id = g_notification_count;
    strncpy(n->student_id, student_id, ID_LEN - 1);
    strncpy(n->message, message, MSG_LEN - 1);
    strncpy(n->subject_id, subject_id ? subject_id : "ALL", ID_LEN - 1);
    strncpy(n->notification_type, type ? type : "info", 31);
    get_current_timestamp(n->created_at, sizeof(n->created_at));
    n->read_status = 0; /* unread */
}

/* ============================================================================
   PERSISTENCE (DISK SAVE & LOAD)
   ============================================================================ */
int save_all_to_disk(void) {
    FILE *fp = NULL;

    /* 1. Save Attendance Records */
    fp = fopen("data/lecture_attendance.csv", "w");
    if (!fp) fp = fopen("../data/lecture_attendance.csv", "w");
    if (fp) {
        fprintf(fp, "attendance_id,student_id,subject_id,date,status,updated_by,last_updated\n");
        for (int i = 0; i < g_attendance_count; i++) {
            AttendanceRecord *r = &g_attendance[i];
            fprintf(fp, "%d,%s,%s,%s,%s,%s,%s\n",
                    r->attendance_id, r->student_id, r->subject_id, r->date,
                    r->status, r->updated_by, r->last_updated);
        }
        fclose(fp);
    }

    /* 2. Save Notifications */
    fp = fopen("data/notifications.csv", "w");
    if (!fp) fp = fopen("../data/notifications.csv", "w");
    if (fp) {
        fprintf(fp, "notification_id,student_id,message,subject_id,notification_type,created_at,read_status\n");
        for (int i = 0; i < g_notification_count; i++) {
            Notification *n = &g_notifications[i];
            fprintf(fp, "%d,%s,\"%s\",%s,%s,%s,%d\n",
                    n->notification_id, n->student_id, n->message, n->subject_id,
                    n->notification_type, n->created_at, n->read_status);
        }
        fclose(fp);
    }

    /* 3. Save Upload History */
    fp = fopen("data/uploads.csv", "w");
    if (!fp) fp = fopen("../data/uploads.csv", "w");
    if (fp) {
        fprintf(fp, "upload_id,faculty_id,subject_id,file_name,upload_date,record_count,upload_status\n");
        for (int i = 0; i < g_upload_count; i++) {
            UploadRecord *u = &g_uploads[i];
            fprintf(fp, "%d,%s,%s,%s,%s,%d,%s\n",
                    u->upload_id, u->faculty_id, u->subject_id, u->file_name,
                    u->upload_date, u->record_count, u->upload_status);
        }
        fclose(fp);
    }

    /* 4. Save Audit Logs */
    fp = fopen("data/audit_logs.csv", "w");
    if (!fp) fp = fopen("../data/audit_logs.csv", "w");
    if (fp) {
        fprintf(fp, "log_id,action,user_id,target_student,subject_id,date,old_status,new_status,timestamp\n");
        for (int i = 0; i < g_audit_count; i++) {
            AuditLog *l = &g_audit_logs[i];
            fprintf(fp, "%d,%s,%s,%s,%s,%s,%s,%s,%s\n",
                    l->log_id, l->action, l->user_id, l->target_student,
                    l->subject_id, l->date, l->old_status, l->new_status, l->timestamp);
        }
        fclose(fp);
    }

    return 0;
}

int load_all_from_disk(void) {
    FILE *fp = fopen("data/lecture_attendance.csv", "r");
    if (!fp) fp = fopen("../data/lecture_attendance.csv", "r");
    if (!fp) return -1; /* File does not exist yet */

    char line[512];
    /* Read header and validate structure */
    if (!fgets(line, sizeof(line), fp)) {
        fclose(fp);
        return -1;
    }
    if (strstr(line, "student_id") == NULL && strstr(line, "attendance_id") == NULL) {
        fclose(fp);
        return -1;
    }

    g_attendance_count = 0;
    while (fgets(line, sizeof(line), fp) && g_attendance_count < MAX_ATTENDANCE_RECORDS) {
        /* Trim newline */
        size_t len = strlen(line);
        while (len > 0 && (line[len - 1] == '\r' || line[len - 1] == '\n')) line[--len] = '\0';
        if (len < 5) continue;

        AttendanceRecord *r = &g_attendance[g_attendance_count];
        int id = 0;
        char sid[ID_LEN] = {0}, sub[ID_LEN] = {0}, dt[DATE_LEN] = {0}, st[STATUS_LEN] = {0}, by[ID_LEN] = {0}, lu[32] = {0};

        int parsed = sscanf(line, "%d,%31[^,],%31[^,],%15[^,],%15[^,],%31[^,],%31[^\n]",
                            &id, sid, sub, dt, st, by, lu);
        if (parsed >= 5) {
            r->attendance_id = id ? id : (g_attendance_count + 1);
            strncpy(r->student_id, sid, ID_LEN - 1);
            strncpy(r->subject_id, sub, ID_LEN - 1);
            strncpy(r->date, dt, DATE_LEN - 1);
            strncpy(r->status, st, STATUS_LEN - 1);
            strncpy(r->updated_by, by[0] ? by : "FACULTY", ID_LEN - 1);
            strncpy(r->last_updated, lu[0] ? lu : dt, 31);
            g_attendance_count++;
        }
    }
    fclose(fp);

    /* Load Notifications */
    fp = fopen("data/notifications.csv", "r");
    if (!fp) fp = fopen("../data/notifications.csv", "r");
    if (fp) {
        fgets(line, sizeof(line), fp); /* skip header */
        g_notification_count = 0;
        while (fgets(line, sizeof(line), fp) && g_notification_count < MAX_NOTIFICATIONS) {
            Notification *n = &g_notifications[g_notification_count];
            char *p = line;
            n->notification_id = atoi(p);
            p = strchr(p, ','); if (!p) continue; p++;
            
            /* student_id */
            char *comma = strchr(p, ','); if (!comma) continue;
            *comma = '\0'; strncpy(n->student_id, p, ID_LEN - 1); p = comma + 1;

            /* message (may be quoted) */
            if (*p == '"') {
                p++;
                char *quote = strchr(p, '"');
                if (!quote) continue;
                *quote = '\0'; strncpy(n->message, p, MSG_LEN - 1);
                p = quote + 1;
                if (*p == ',') p++;
            } else {
                comma = strchr(p, ','); if (!comma) continue;
                *comma = '\0'; strncpy(n->message, p, MSG_LEN - 1); p = comma + 1;
            }

            /* subject_id */
            comma = strchr(p, ','); if (!comma) continue;
            *comma = '\0'; strncpy(n->subject_id, p, ID_LEN - 1); p = comma + 1;

            /* notification_type */
            comma = strchr(p, ','); if (!comma) continue;
            *comma = '\0'; strncpy(n->notification_type, p, 31); p = comma + 1;

            /* created_at */
            comma = strchr(p, ','); if (!comma) continue;
            *comma = '\0'; strncpy(n->created_at, p, 31); p = comma + 1;

            /* read_status */
            n->read_status = atoi(p);
            g_notification_count++;
        }
        fclose(fp);
    }

    return (g_attendance_count > 0) ? 0 : -1;
}

/* ============================================================================
   DEFAULT SEEDING
   ============================================================================ */
static void seed_default_upes_data(void) {
    /* 1. Subjects */
    g_subject_count = 0;
    const char *subs[6][3] = {
        {"CSE101", "Engineering Mathematics", "45"},
        {"CSE102", "C Programming", "45"},
        {"CSE103", "Engineering Physics", "45"},
        {"CSE104", "Basic Electrical Engineering", "45"},
        {"CSE105", "Environmental Studies", "45"},
        {"CSE106", "Engineering Graphics", "45"}
    };
    for (int i = 0; i < 6; i++) {
        Subject *s = &g_subjects[g_subject_count++];
        strncpy(s->subject_id, subs[i][0], ID_LEN - 1);
        strncpy(s->subject_name, subs[i][1], NAME_LEN - 1);
        strncpy(s->department, "CSE", DEPT_LEN - 1);
        s->semester = 1;
        s->total_planned = atoi(subs[i][2]);
    }

    /* 2. Faculty */
    g_faculty_count = 0;
    Faculty *f1 = &g_faculty[g_faculty_count++];
    strncpy(f1->faculty_id, "FAC101", ID_LEN - 1);
    strncpy(f1->name, "Dr. Rajesh Sharma", NAME_LEN - 1);
    strncpy(f1->email, "rsharma@ddn.upes.ac.in", EMAIL_LEN - 1);
    strncpy(f1->salt, "upes_fac_salt_101", SALT_LEN - 1);
    hash_password("faculty123", f1->salt, f1->password_hash);
    strncpy(f1->assigned_subjects, "CSE101,CSE102,CSE103,CSE104,CSE105,CSE106", 127);

    Faculty *f2 = &g_faculty[g_faculty_count++];
    strncpy(f2->faculty_id, "FAC102", ID_LEN - 1);
    strncpy(f2->name, "Prof. Neha Gupta", NAME_LEN - 1);
    strncpy(f2->email, "ngupta@ddn.upes.ac.in", EMAIL_LEN - 1);
    strncpy(f2->salt, "upes_fac_salt_102", SALT_LEN - 1);
    hash_password("faculty123", f2->salt, f2->password_hash);
    strncpy(f2->assigned_subjects, "CSE102,CSE104,CSE106", 127);

    /* 3. Students */
    const char *names[20] = {
        "Aarav Sharma", "Diya Patel", "Rohan Verma", "Ananya Iyer", "Kabir Mehta",
        "Ishaan Nair", "Meera Joshi", "Aditya Rao", "Sanya Gupta", "Vikram Singh",
        "Pooja Reddy", "Aryan Kulkarni", "Sneha Deshmukh", "Karthik Menon", "Tanvi Bhatia",
        "Rishabh Pandey", "Nidhi Agarwal", "Varun Chopra", "Kavya Saxena", "Siddharth Jain"
    };

    g_student_count = 0;
    for (int i = 0; i < 20; i++) {
        Student *st = &g_students[g_student_count++];
        snprintf(st->student_id, ID_LEN, "UPES5000%03d", 101 + i);
        strncpy(st->name, names[i], NAME_LEN - 1);
        snprintf(st->email, EMAIL_LEN, "student.%03d@stu.upes.ac.in", 101 + i);
        snprintf(st->salt, SALT_LEN, "salt_stu_%03d", 101 + i);
        hash_password("student123", st->salt, st->password_hash);
        strncpy(st->department, "CSE", DEPT_LEN - 1);
        st->semester = 1;
        strncpy(st->section, "CSE-1", 15);
    }

    /* 4. Seed 24 past lecture dates for initial demonstration data */
    const char *dates[24] = {
        "2026-09-01", "2026-09-03", "2026-09-05", "2026-09-08", "2026-09-10", "2026-09-12",
        "2026-09-15", "2026-09-17", "2026-09-19", "2026-09-22", "2026-09-24", "2026-09-26",
        "2026-09-29", "2026-10-01", "2026-10-03", "2026-10-06", "2026-10-08", "2026-10-10",
        "2026-10-13", "2026-10-15", "2026-10-17", "2026-10-20", "2026-10-22", "2026-10-24"
    };

    g_attendance_count = 0;
    for (int s = 0; s < g_subject_count; s++) {
        const char *sub_id = g_subjects[s].subject_id;
        for (int d = 0; d < 24; d++) {
            const char *dt = dates[d];
            for (int st_idx = 0; st_idx < g_student_count; st_idx++) {
                if (g_attendance_count >= MAX_ATTENDANCE_RECORDS) break;
                AttendanceRecord *rec = &g_attendance[g_attendance_count++];
                rec->attendance_id = g_attendance_count;
                strncpy(rec->student_id, g_students[st_idx].student_id, ID_LEN - 1);
                strncpy(rec->subject_id, sub_id, ID_LEN - 1);
                strncpy(rec->date, dt, DATE_LEN - 1);
                strncpy(rec->updated_by, "FAC101", ID_LEN - 1);
                snprintf(rec->last_updated, 32, "%s 10:00:00", dt);

                /* Specific student profiles */
                int is_present = 1;
                if (st_idx == 0) { /* Aarav ~95% */
                    is_present = (d % 20 != 0);
                } else if (st_idx == 1) { /* Diya ~62% */
                    is_present = (d % 3 != 0);
                } else if (st_idx == 2) { /* Rohan ~76% */
                    is_present = (d % 4 != 0);
                } else if (st_idx == 3) { /* Ananya 100% */
                    is_present = 1;
                } else if (st_idx == 4) { /* Kabir ~45% */
                    is_present = (d % 2 == 0);
                } else if (st_idx == 9) { /* Vikram ~73% */
                    is_present = (d != 2 && d != 6 && d != 11 && d != 15 && d != 19 && d != 21);
                } else {
                    is_present = ((d + st_idx) % 6 != 0);
                }

                strncpy(rec->status, is_present ? "Present" : "Absent", STATUS_LEN - 1);
            }
        }
    }

    /* 5. Seed initial notifications */
    g_notification_count = 0;
    add_notification("UPES5000101", "Today's attendance has been marked for C Programming: Present.", "CSE102", "attendance_marked");
    add_notification("UPES5000101", "Your Engineering Mathematics attendance has been updated.", "CSE101", "attendance_marked");
    add_notification("UPES5000102", "⚠️ Warning: Your overall attendance (62.5%) has fallen below the 75% threshold!", "ALL", "warning");
    add_notification("UPES5000102", "Today's attendance has been marked for Engineering Physics: Absent.", "CSE103", "attendance_marked");
    add_notification("UPES5000105", "⚠️ Critical Shortage: Attendance is 45.8%. Mandatory recovery plan required.", "ALL", "warning");
    add_notification("UPES5000110", "⚠️ Attention: Your attendance (73.6%) is approaching the 75% threshold.", "ALL", "warning");

    /* 6. Seed upload history */
    g_upload_count = 0;
    UploadRecord *u1 = &g_uploads[g_upload_count++];
    u1->upload_id = 1;
    strncpy(u1->faculty_id, "FAC101", ID_LEN - 1);
    strncpy(u1->subject_id, "CSE102", ID_LEN - 1);
    strncpy(u1->file_name, "CSE102_Attendance_Batch1_Oct24.csv", FILENAME_LEN - 1);
    strncpy(u1->upload_date, "2026-10-24 16:30:00", 31);
    u1->record_count = 20;
    strncpy(u1->upload_status, "Success", 31);

    UploadRecord *u2 = &g_uploads[g_upload_count++];
    u2->upload_id = 2;
    strncpy(u2->faculty_id, "FAC101", ID_LEN - 1);
    strncpy(u2->subject_id, "CSE101", ID_LEN - 1);
    strncpy(u2->file_name, "CSE101_Math_Lecture22.xlsx", FILENAME_LEN - 1);
    strncpy(u2->upload_date, "2026-10-22 17:15:00", 31);
    u2->record_count = 20;
    strncpy(u2->upload_status, "Success", 31);
}

void init_database(void) {
    srand((unsigned int)time(NULL));

    /* Always initialize subjects, faculty & students models */
    seed_default_upes_data();

    /* Try loading existing persisted records from disk */
    if (load_all_from_disk() == 0) {
        printf("[DATABASE] Successfully loaded %d attendance records from disk.\n", g_attendance_count);
    } else {
        printf("[DATABASE] No existing records found. Initializing with default seed and saving to disk.\n");
        save_all_to_disk();
    }
}

/* ============================================================================
   AUTHENTICATION
   ============================================================================ */
int authenticate_student(const char *student_id, const char *password, Student *out_student, char *out_token) {
    if (!student_id || !password) return 0;
    if (is_rate_limited(student_id)) return -2; /* Rate limited */

    for (int i = 0; i < g_student_count; i++) {
        if (strcmp(g_students[i].student_id, student_id) == 0) {
            char computed_hash[65];
            hash_password(password, g_students[i].salt, computed_hash);
            if (strcmp(g_students[i].password_hash, computed_hash) == 0) {
                reset_failed_logins(student_id);
                if (out_student) *out_student = g_students[i];
                if (out_token) create_session(g_students[i].student_id, "STUDENT", out_token);
                add_audit_log("LOGIN", student_id, student_id, "-", "-", "-", "-");
                return 1;
            } else {
                record_failed_login(student_id);
                return 0;
            }
        }
    }
    record_failed_login(student_id);
    return 0;
}

int authenticate_faculty(const char *faculty_id, const char *password, Faculty *out_faculty, char *out_token) {
    if (!faculty_id || !password) return 0;
    if (is_rate_limited(faculty_id)) return -2; /* Rate limited */

    for (int i = 0; i < g_faculty_count; i++) {
        if (strcmp(g_faculty[i].faculty_id, faculty_id) == 0 ||
            strcmp(g_faculty[i].email, faculty_id) == 0) {
            char computed_hash[65];
            hash_password(password, g_faculty[i].salt, computed_hash);
            if (strcmp(g_faculty[i].password_hash, computed_hash) == 0) {
                reset_failed_logins(faculty_id);
                if (out_faculty) *out_faculty = g_faculty[i];
                if (out_token) create_session(g_faculty[i].faculty_id, "FACULTY", out_token);
                add_audit_log("LOGIN", faculty_id, "-", "-", "-", "-", "-");
                return 1;
            } else {
                record_failed_login(faculty_id);
                return 0;
            }
        }
    }
    record_failed_login(faculty_id);
    return 0;
}

/* ============================================================================
   STUDENT DASHBOARD DATA
   ============================================================================ */
int get_student_dashboard_data(const char *student_id, float threshold_pct, StudentDashboardData *out_data) {
    if (!student_id || !out_data) return -1;
    memset(out_data, 0, sizeof(StudentDashboardData));
    out_data->required_threshold = threshold_pct;
    out_data->subject_count = g_subject_count;

    for (int s = 0; s < g_subject_count; s++) {
        Subject *sub = &g_subjects[s];
        SubjectAnalytics *sa = &out_data->subjects[s];
        strncpy(sa->subject_id, sub->subject_id, ID_LEN - 1);
        strncpy(sa->subject_name, sub->subject_name, NAME_LEN - 1);
        sa->remaining_classes = sub->total_planned;

        int att = 0, tot = 0;
        for (int a = 0; a < g_attendance_count; a++) {
            if (strcmp(g_attendance[a].student_id, student_id) == 0 &&
                strcmp(g_attendance[a].subject_id, sub->subject_id) == 0) {
                tot++;
                if (strcmp(g_attendance[a].status, "Present") == 0) {
                    att++;
                }
            }
        }

        sa->attended = att;
        sa->total = tot;
        sa->missed = tot - att;
        sa->percentage = calculate_percentage(att, tot);
        sa->is_eligible = (sa->percentage >= threshold_pct) ? 1 : 0;
        sa->classes_needed = calculate_recovery_needed(att, tot, threshold_pct);
        sa->allowable_leaves = calculate_allowable_leaves(att, tot, threshold_pct);
        sa->remaining_classes = MAX_VAL(0, sub->total_planned - tot);
        sa->is_achievable = check_recovery_achievable(sa->classes_needed, tot, sub->total_planned);

        out_data->total_attended += att;
        out_data->total_conducted += tot;
    }

    out_data->total_missed = out_data->total_conducted - out_data->total_attended;
    out_data->overall_percentage = calculate_percentage(out_data->total_attended, out_data->total_conducted);
    out_data->is_eligible = (out_data->overall_percentage >= threshold_pct) ? 1 : 0;
    out_data->overall_classes_needed = calculate_recovery_needed(out_data->total_attended, out_data->total_conducted, threshold_pct);
    out_data->overall_allowable_leaves = calculate_allowable_leaves(out_data->total_attended, out_data->total_conducted, threshold_pct);

    return 0;
}

int get_student_attendance_history(const char *student_id, const char *subject_filter, AttendanceRecord *out_records, int max_records) {
    if (!student_id || !out_records) return 0;
    int count = 0;
    /* Reverse chronological order (latest first) */
    for (int i = g_attendance_count - 1; i >= 0 && count < max_records; i--) {
        if (strcmp(g_attendance[i].student_id, student_id) == 0) {
            if (!subject_filter || strlen(subject_filter) == 0 || strcmp(subject_filter, "ALL") == 0 ||
                strcmp(g_attendance[i].subject_id, subject_filter) == 0) {
                out_records[count++] = g_attendance[i];
            }
        }
    }
    return count;
}

int get_student_notifications(const char *student_id, Notification *out_notifications, int max_notifs, int *unread_count) {
    if (!student_id) return 0;
    int count = 0;
    int unread = 0;
    for (int i = g_notification_count - 1; i >= 0; i--) {
        if (strcmp(g_notifications[i].student_id, student_id) == 0 ||
            strcmp(g_notifications[i].student_id, "ALL") == 0) {
            if (out_notifications && count < max_notifs) {
                out_notifications[count++] = g_notifications[i];
            }
            if (g_notifications[i].read_status == 0) {
                unread++;
            }
        }
    }
    if (unread_count) *unread_count = unread;
    return count;
}

void mark_notifications_read(const char *student_id) {
    if (!student_id) return;
    int changed = 0;
    for (int i = 0; i < g_notification_count; i++) {
        if (strcmp(g_notifications[i].student_id, student_id) == 0 ||
            strcmp(g_notifications[i].student_id, "ALL") == 0) {
            if (g_notifications[i].read_status == 0) {
                g_notifications[i].read_status = 1;
                changed = 1;
            }
        }
    }
    if (changed) {
        save_all_to_disk();
    }
}

/* ============================================================================
   FACULTY OPERATIONS & ATTENDANCE RECORDING
   ============================================================================ */
int mark_or_update_attendance(const char *student_id, const char *subject_id, const char *date, const char *status, const char *updated_by) {
    if (!student_id || !subject_id || !date || !status) return -1;
    char now_str[32];
    get_current_timestamp(now_str, sizeof(now_str));
    Subject *sub = find_subject_by_id(subject_id);
    const char *sub_name = sub ? sub->subject_name : subject_id;

    /* 1. Check if record already exists for (student_id, subject_id, date) */
    for (int i = 0; i < g_attendance_count; i++) {
        if (strcmp(g_attendance[i].student_id, student_id) == 0 &&
            strcmp(g_attendance[i].subject_id, subject_id) == 0 &&
            strcmp(g_attendance[i].date, date) == 0) {

            int status_changed = (strcmp(g_attendance[i].status, status) != 0);
            char old_st[STATUS_LEN];
            strncpy(old_st, g_attendance[i].status, STATUS_LEN - 1);

            strncpy(g_attendance[i].status, status, STATUS_LEN - 1);
            strncpy(g_attendance[i].updated_by, updated_by ? updated_by : "FACULTY", ID_LEN - 1);
            strncpy(g_attendance[i].last_updated, now_str, 31);

            if (status_changed) {
                char msg[MSG_LEN];
                snprintf(msg, sizeof(msg), "Your %s attendance on %s was updated to %s.", sub_name, date, status);
                add_notification(student_id, msg, subject_id, "attendance_updated");
                add_audit_log("UPDATE", updated_by, student_id, subject_id, date, old_st, status);
            }

            save_all_to_disk();
            return 1; /* updated existing record */
        }
    }

    /* 2. Otherwise insert new record */
    if (g_attendance_count < MAX_ATTENDANCE_RECORDS) {
        AttendanceRecord *rec = &g_attendance[g_attendance_count++];
        rec->attendance_id = g_attendance_count;
        strncpy(rec->student_id, student_id, ID_LEN - 1);
        strncpy(rec->subject_id, subject_id, ID_LEN - 1);
        strncpy(rec->date, date, DATE_LEN - 1);
        strncpy(rec->status, status, STATUS_LEN - 1);
        strncpy(rec->updated_by, updated_by ? updated_by : "FACULTY", ID_LEN - 1);
        strncpy(rec->last_updated, now_str, 31);

        char msg[MSG_LEN];
        snprintf(msg, sizeof(msg), "Today's attendance has been marked for %s: %s.", sub_name, status);
        add_notification(student_id, msg, subject_id, "attendance_marked");
        add_audit_log("MARK", updated_by, student_id, subject_id, date, "-", status);

        /* Trigger warning if overall attendance falls below 75% */
        StudentDashboardData dash;
        get_student_dashboard_data(student_id, 75.0f, &dash);
        if (dash.overall_percentage < 75.0f && strcmp(status, "Absent") == 0) {
            char warn[MSG_LEN];
            snprintf(warn, sizeof(warn), "⚠️ Warning: Your overall attendance (%.1f%%) has fallen below the 75%% threshold!", dash.overall_percentage);
            add_notification(student_id, warn, "ALL", "warning");
        }

        save_all_to_disk();
        return 2; /* inserted new record */
    }

    return -1;
}

int get_faculty_overview(int *total_students, int *total_subjects, int *total_records, int *defaulters_count) {
    if (total_students) *total_students = g_student_count;
    if (total_subjects) *total_subjects = g_subject_count;
    if (total_records) *total_records = g_attendance_count;

    int def_count = 0;
    for (int i = 0; i < g_student_count; i++) {
        StudentDashboardData dash;
        get_student_dashboard_data(g_students[i].student_id, 75.0f, &dash);
        if (dash.overall_percentage < 75.0f) {
            def_count++;
        }
    }
    if (defaulters_count) *defaulters_count = def_count;
    return 0;
}

int get_all_subjects(Subject *out_subjects, int max_subjects) {
    int count = (g_subject_count < max_subjects) ? g_subject_count : max_subjects;
    for (int i = 0; i < count; i++) {
        out_subjects[i] = g_subjects[i];
    }
    return count;
}

int get_all_students(Student *out_students, int max_students) {
    int count = (g_student_count < max_students) ? g_student_count : max_students;
    for (int i = 0; i < count; i++) {
        out_students[i] = g_students[i];
    }
    return count;
}

int get_subject_roster(const char *subject_id, const char *date, Student *students, char statuses[][STATUS_LEN], float percentages[], int max_students) {
    int count = (g_student_count < max_students) ? g_student_count : max_students;
    for (int i = 0; i < count; i++) {
        students[i] = g_students[i];

        int att = 0, tot = 0;
        char cur_status[STATUS_LEN] = "Present";
        for (int a = 0; a < g_attendance_count; a++) {
            if (strcmp(g_attendance[a].student_id, g_students[i].student_id) == 0 &&
                strcmp(g_attendance[a].subject_id, subject_id) == 0) {
                tot++;
                if (strcmp(g_attendance[a].status, "Present") == 0) att++;
                if (date && strcmp(g_attendance[a].date, date) == 0) {
                    strncpy(cur_status, g_attendance[a].status, STATUS_LEN - 1);
                }
            }
        }
        percentages[i] = calculate_percentage(att, tot);
        strncpy(statuses[i], cur_status, STATUS_LEN - 1);
    }
    return count;
}

int save_upload_history_record(const char *faculty_id, const char *subject_id, const char *file_name, int record_count, const char *status) {
    if (g_upload_count >= MAX_UPLOADS) return -1;
    UploadRecord *u = &g_uploads[g_upload_count++];
    u->upload_id = g_upload_count;
    strncpy(u->faculty_id, faculty_id ? faculty_id : "FACULTY", ID_LEN - 1);
    strncpy(u->subject_id, subject_id ? subject_id : "CSE", ID_LEN - 1);
    strncpy(u->file_name, file_name ? file_name : "upload.csv", FILENAME_LEN - 1);
    get_current_timestamp(u->upload_date, sizeof(u->upload_date));
    u->record_count = record_count;
    strncpy(u->upload_status, status ? status : "Success", 31);
    save_all_to_disk();
    return 0;
}

int get_upload_history_records(UploadRecord *out_records, int max_records) {
    int count = 0;
    for (int i = g_upload_count - 1; i >= 0 && count < max_records; i--) {
        out_records[count++] = g_uploads[i];
    }
    return count;
}
