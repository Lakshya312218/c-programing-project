#include <stdio.h>
#include <stdlib.h>
#include "database.h"
#include "server.h"

int main(int argc, char *argv[]) {
    int port = 5000;
    if (argc >= 2) {
        port = atoi(argv[1]);
        if (port <= 0) port = 5000;
    }

    printf("=======================================================================\n");
    printf("   Initializing UPES Student Attendance Analysis System (C Core)      \n");
    printf("=======================================================================\n");
    printf("[1/2] Seeding in-memory records and attendance dataset...\n");
    init_database();
    printf("      - 20 CSE Students loaded (UPES5000101 to UPES5000120)\n");
    printf("      - 6 B.Tech CSE Subjects loaded\n");
    printf("      - Historical attendance records & notifications generated\n");

    printf("[2/2] Launching HTTP REST Web Server on port %d...\n", port);
    return start_upes_http_server(port);
}
