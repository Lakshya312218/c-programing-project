#ifndef DATABASE_H
#define DATABASE_H

#include "models.h"

/* Database initialization & Persistence */
void init_database(void);
int save_all_to_disk(void);
int load_all_from_disk(void);

/* Authentication & Sessions */
int authenticate_student(const char *student_id, const char *password, Student *out_student, char *out_token);
int authenticate_faculty(const char *faculty_id, const char *password, Faculty *out_faculty, char *out_token);
int validate_session_token(const char *token, char *out_user_id, char *out_role);
int destroy_session_token(const char *token);

/* Rate Limiting */
int is_rate_limited(const char *identifier);
void record_failed_login(const char *identifier);
void reset_failed_logins(const char *identifier);

/* Entity Lookups */
Student* find_student_by_id(const char *student_id);
Faculty* find_faculty_by_id(const char *faculty_id);
Subject* find_subject_by_id(const char *subject_id);

/* Student Portal Data Access */
int get_student_dashboard_data(const char *student_id, float threshold_pct, StudentDashboardData *out_data);
int get_student_attendance_history(const char *student_id, const char *subject_filter, AttendanceRecord *out_records, int max_records);
int get_student_notifications(const char *student_id, Notification *out_notifications, int max_notifs, int *unread_count);
void mark_notifications_read(const char *student_id);

/* Faculty Portal Data Access & Operations */
int get_faculty_overview(int *total_students, int *total_subjects, int *total_records, int *defaulters_count);
int get_all_subjects(Subject *out_subjects, int max_subjects);
int get_all_students(Student *out_students, int max_students);
int get_subject_roster(const char *subject_id, const char *date, Student *students, char statuses[][STATUS_LEN], float percentages[], int max_students);
int mark_or_update_attendance(const char *student_id, const char *subject_id, const char *date, const char *status, const char *updated_by);
int save_upload_history_record(const char *faculty_id, const char *subject_id, const char *file_name, int record_count, const char *status);
int get_upload_history_records(UploadRecord *out_records, int max_records);

/* Notification Generation Helper */
void add_notification(const char *student_id, const char *message, const char *subject_id, const char *type);

/* Audit Trail Helper */
void add_audit_log(const char *action, const char *user_id, const char *target_student, const char *subject_id,
                   const char *date, const char *old_status, const char *new_status);

#endif /* DATABASE_H */
