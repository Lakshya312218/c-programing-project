#ifndef SHA256_H
#define SHA256_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint8_t  data[64];
    uint32_t datalen;
    uint64_t bitlen;
    uint32_t state[8];
} SHA256_CTX;

void sha256_init(SHA256_CTX *ctx);
void sha256_update(SHA256_CTX *ctx, const uint8_t data[], size_t len);
void sha256_final(SHA256_CTX *ctx, uint8_t hash[]);

/* Helper: hash a null-terminated string and format as 64-char hex string */
void sha256_hash_string(const char *str, char output[65]);

/* Helper: hash password with salt: SHA256(salt + password) */
void hash_password(const char *password, const char *salt, char output[65]);

#endif /* SHA256_H */
