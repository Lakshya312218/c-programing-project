#include <stdio.h>
#include <math.h>
#include "analytics.h"

float calculate_percentage(int attended, int total) {
    if (total <= 0) return 0.0f;
    return ((float)attended / (float)total) * 100.0f;
}

int calculate_recovery_needed(int attended, int total, float threshold_pct) {
    if (total <= 0) return 0;
    float current_pct = calculate_percentage(attended, total);
    if (current_pct >= threshold_pct) {
        return 0; /* Already eligible */
    }

    float r = threshold_pct / 100.0f;
    if (r >= 1.0f) {
        return (attended < total) ? -1 : 0; /* 100% is impossible if a class was missed */
    }

    /* Formula: n = ceil((R * T - A) / (1 - R)) */
    float numerator = (r * (float)total) - (float)attended;
    float denominator = 1.0f - r;
    int needed = (int)ceilf(numerator / denominator);
    return (needed > 0) ? needed : 0;
}

int calculate_allowable_leaves(int attended, int total, float threshold_pct) {
    if (total <= 0 || attended <= 0) return 0;
    float current_pct = calculate_percentage(attended, total);
    if (current_pct < threshold_pct) {
        return 0; /* Only display non-negative leave allowance when student is currently eligible */
    }

    float r = threshold_pct / 100.0f;
    if (r <= 0.0f) return 0;

    /* Formula: x = floor((A / R) - T) */
    int max_total = (int)floorf((float)attended / r);
    int allowable = max_total - total;
    return (allowable > 0) ? allowable : 0;
}

int check_recovery_achievable(int needed, int total, int total_planned) {
    int remaining = total_planned - total;
    if (remaining < 0) remaining = 0;
    if (needed <= remaining) {
        return 1; /* Achievable */
    }
    return 0; /* Mathematically impossible within remaining scheduled classes */
}

void simulate_hypothetical_leave(int attended, int total, int extra_leaves, float threshold_pct,
                                float *projected_pct, int *still_eligible) {
    int new_total = total + extra_leaves;
    *projected_pct = calculate_percentage(attended, new_total);
    *still_eligible = (*projected_pct >= threshold_pct) ? 1 : 0;
}
