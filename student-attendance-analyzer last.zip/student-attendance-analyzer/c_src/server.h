#ifndef SERVER_H
#define SERVER_H

int start_upes_http_server(int port);

#endif /* SERVER_H */
