#ifndef ANALYTICS_H
#define ANALYTICS_H

#include "models.h"

/* Attendance & Eligibility Math */
float calculate_percentage(int attended, int total);
int calculate_recovery_needed(int attended, int total, float threshold_pct);
int calculate_allowable_leaves(int attended, int total, float threshold_pct);
int check_recovery_achievable(int needed, int total, int total_planned);

/* Leave Simulator */
void simulate_hypothetical_leave(int attended, int total, int extra_leaves, float threshold_pct,
                                float *projected_pct, int *still_eligible);

#endif /* ANALYTICS_H */
