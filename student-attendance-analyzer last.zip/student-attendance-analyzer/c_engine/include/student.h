#ifndef STUDENT_H
#define STUDENT_H

#define MAX_STUDENTS 200
#define MAX_NAME_LEN 64
#define MAX_DEPT_LEN 16
#define MAX_SUBJECTS 5
#define CODE_LEN 16
#define DEFAULT_THRESHOLD 75.0f

typedef struct {
    char code[CODE_LEN];
    char name[32];
    int attended;
    int total;
    float percentage;
} SubjectRecord;

typedef struct {
    int roll_no;
    char name[MAX_NAME_LEN];
    char department[MAX_DEPT_LEN];
    SubjectRecord subjects[MAX_SUBJECTS];
    int subject_count;
    int total_attended;
    int total_conducted;
    float overall_percentage;
    int is_defaulter;       /* 1 if overall_percentage < threshold, 0 otherwise */
    int classes_needed;     /* Consecutive classes needed to reach threshold */
    int safe_bunks;         /* Consecutive classes that can be missed and still stay >= threshold */
} StudentRecord;

typedef struct {
    char code[CODE_LEN];
    char name[32];
    float average_percentage;
    int total_attended;
    int total_conducted;
    int highest_attended;
    int lowest_attended;
} SubjectSummary;

typedef struct {
    int total_students;
    int defaulter_count;
    int eligible_count;
    int honors_count;        /* Students >= 90% */
    float class_average;
    float highest_percentage;
    float lowest_percentage;
    char top_student_name[MAX_NAME_LEN];
    int top_student_roll;
    SubjectSummary subject_summaries[MAX_SUBJECTS];
    int subject_count;
    float threshold;
} ClassSummary;

#endif /* STUDENT_H */
