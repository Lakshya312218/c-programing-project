#ifndef ANALYTICS_H
#define ANALYTICS_H

#include "student.h"

/* Single student calculations */
void calculate_student_analytics(StudentRecord *student, float threshold);
int calculate_classes_needed(int attended, int total, float threshold);
int calculate_safe_bunks(int attended, int total, float threshold);

/* Class-level aggregation & analytics */
void compute_class_summary(StudentRecord *students, int count, ClassSummary *summary, float threshold);

/* Console display helpers */
void print_banner(void);
void print_student_table(const StudentRecord *students, int count);
void print_defaulter_report(const StudentRecord *students, int count);
void print_subject_summary(const ClassSummary *summary);
void print_summary_card(const ClassSummary *summary);
void print_individual_student(const StudentRecord *student);

#endif /* ANALYTICS_H */
