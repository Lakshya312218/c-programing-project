#ifndef FILE_HANDLER_H
#define FILE_HANDLER_H

#include "student.h"

/* Read attendance from CSV */
int load_students_from_csv(const char *filename, StudentRecord *students, int max_students);

/* Export analytical results to JSON for Web Dashboard consumption */
int export_analytics_json(const char *filename, const StudentRecord *students, int count, const ClassSummary *summary);

/* Export official defaulters notice to CSV */
int export_defaulters_csv(const char *filename, const StudentRecord *students, int count);

#endif /* FILE_HANDLER_H */
