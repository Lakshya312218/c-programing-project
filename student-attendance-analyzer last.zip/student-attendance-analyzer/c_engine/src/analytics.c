#include <stdio.h>
#include <string.h>
#include <math.h>
#include "../include/analytics.h"

int calculate_classes_needed(int attended, int total, float threshold) {
    float p = threshold / 100.0f;
    if (p >= 1.0f) {
        return (attended < total) ? -1 : 0; /* impossible if already missed */
    }
    float current_pct = (total > 0) ? ((float)attended / (float)total) * 100.0f : 0.0f;
    if (current_pct >= threshold) {
        return 0;
    }
    float numerator = (p * (float)total) - (float)attended;
    float denominator = 1.0f - p;
    int needed = (int)ceilf(numerator / denominator);
    return (needed > 0) ? needed : 0;
}

int calculate_safe_bunks(int attended, int total, float threshold) {
    float p = threshold / 100.0f;
    if (p <= 0.0f || total == 0) return 0;
    float current_pct = ((float)attended / (float)total) * 100.0f;
    if (current_pct < threshold) {
        return 0;
    }
    float numerator = (float)attended - (p * (float)total);
    int bunks = (int)floorf(numerator / p);
    return (bunks > 0) ? bunks : 0;
}

void calculate_student_analytics(StudentRecord *student, float threshold) {
    student->total_attended = 0;
    student->total_conducted = 0;

    for (int i = 0; i < student->subject_count; i++) {
        SubjectRecord *sub = &student->subjects[i];
        if (sub->total > 0) {
            sub->percentage = ((float)sub->attended / (float)sub->total) * 100.0f;
        } else {
            sub->percentage = 0.0f;
        }
        student->total_attended += sub->attended;
        student->total_conducted += sub->total;
    }

    if (student->total_conducted > 0) {
        student->overall_percentage = ((float)student->total_attended / (float)student->total_conducted) * 100.0f;
    } else {
        student->overall_percentage = 0.0f;
    }

    student->is_defaulter = (student->overall_percentage < threshold) ? 1 : 0;
    student->classes_needed = calculate_classes_needed(student->total_attended, student->total_conducted, threshold);
    student->safe_bunks = calculate_safe_bunks(student->total_attended, student->total_conducted, threshold);
}

void compute_class_summary(StudentRecord *students, int count, ClassSummary *summary, float threshold) {
    memset(summary, 0, sizeof(ClassSummary));
    summary->threshold = threshold;
    summary->total_students = count;
    if (count == 0) return;

    summary->highest_percentage = -1.0f;
    summary->lowest_percentage = 101.0f;
    summary->subject_count = (count > 0) ? students[0].subject_count : 0;

    /* Initialize subject summaries */
    for (int s = 0; s < summary->subject_count; s++) {
        strncpy(summary->subject_summaries[s].code, students[0].subjects[s].code, CODE_LEN - 1);
        strncpy(summary->subject_summaries[s].name, students[0].subjects[s].name, 31);
        summary->subject_summaries[s].highest_attended = -1;
        summary->subject_summaries[s].lowest_attended = 99999;
    }

    float total_pct_sum = 0.0f;

    for (int i = 0; i < count; i++) {
        StudentRecord *st = &students[i];
        calculate_student_analytics(st, threshold);

        total_pct_sum += st->overall_percentage;

        if (st->is_defaulter) {
            summary->defaulter_count++;
        } else {
            summary->eligible_count++;
        }

        if (st->overall_percentage >= 90.0f) {
            summary->honors_count++;
        }

        if (st->overall_percentage > summary->highest_percentage) {
            summary->highest_percentage = st->overall_percentage;
            strncpy(summary->top_student_name, st->name, MAX_NAME_LEN - 1);
            summary->top_student_roll = st->roll_no;
        }

        if (st->overall_percentage < summary->lowest_percentage) {
            summary->lowest_percentage = st->overall_percentage;
        }

        /* Subject aggregation */
        for (int s = 0; s < st->subject_count; s++) {
            SubjectSummary *ss = &summary->subject_summaries[s];
            ss->total_attended += st->subjects[s].attended;
            ss->total_conducted += st->subjects[s].total;
            if (st->subjects[s].attended > ss->highest_attended) {
                ss->highest_attended = st->subjects[s].attended;
            }
            if (st->subjects[s].attended < ss->lowest_attended) {
                ss->lowest_attended = st->subjects[s].attended;
            }
        }
    }

    summary->class_average = total_pct_sum / (float)count;

    for (int s = 0; s < summary->subject_count; s++) {
        SubjectSummary *ss = &summary->subject_summaries[s];
        if (ss->total_conducted > 0) {
            ss->average_percentage = ((float)ss->total_attended / (float)ss->total_conducted) * 100.0f;
        }
    }
}

void print_banner(void) {
    printf("\n=========================================================================================\n");
    printf("                  CAMPUS ATTENDANCE ANALYTICS & MONITORING SYSTEM                        \n");
    printf("=========================================================================================\n");
}

void print_summary_card(const ClassSummary *summary) {
    printf("\n+---------------------------------------------------------------------------------------+\n");
    printf("|                               CLASS ANALYTICS OVERVIEW                                |\n");
    printf("+---------------------------------------------------------------------------------------+\n");
    printf("  Total Students    : %-4d            |  Class Average       : %.2f%%\n", summary->total_students, summary->class_average);
    printf("  Eligible (>=%.0f%%) : %-4d            |  Defaulters (<%.0f%%)   : %-4d\n", summary->threshold, summary->eligible_count, summary->threshold, summary->defaulter_count);
    printf("  Honors (>=90%%)    : %-4d            |  Attendance Range    : %.2f%% - %.2f%%\n", summary->honors_count, summary->lowest_percentage, summary->highest_percentage);
    printf("  Class Topper      : %s (Roll: %d, %.2f%%)\n", summary->top_student_name, summary->top_student_roll, summary->highest_percentage);
    printf("+---------------------------------------------------------------------------------------+\n");
}

void print_student_table(const StudentRecord *students, int count) {
    printf("\n=========================================================================================\n");
    printf("%-5s | %-18s | %-4s | %-10s | %-7s | %-10s | %-15s\n", 
           "ROLL", "NAME", "DEPT", "ATTN/TOTAL", "PCT", "STATUS", "ACTION PLAN");
    printf("-----------------------------------------------------------------------------------------\n");
    for (int i = 0; i < count; i++) {
        const StudentRecord *st = &students[i];
        char status_str[16];
        char action_str[24];

        if (st->is_defaulter) {
            snprintf(status_str, sizeof(status_str), "DEFAULTER");
            snprintf(action_str, sizeof(action_str), "Need +%d classes", st->classes_needed);
        } else {
            snprintf(status_str, sizeof(status_str), "ELIGIBLE");
            if (st->safe_bunks > 0) {
                snprintf(action_str, sizeof(action_str), "Safe bunks: %d", st->safe_bunks);
            } else {
                snprintf(action_str, sizeof(action_str), "On edge (0 bunks)");
            }
        }

        printf("%-5d | %-18.18s | %-4s | %4d / %-4d | %6.2f%% | %-10s | %-15s\n",
               st->roll_no, st->name, st->department, st->total_attended, st->total_conducted,
               st->overall_percentage, status_str, action_str);
    }
    printf("=========================================================================================\n");
}

void print_defaulter_report(const StudentRecord *students, int count) {
    printf("\n=========================================================================================\n");
    printf("                     OFFICIAL DEFAULTER SHORTAGE LIST (< 75%%)                           \n");
    printf("=========================================================================================\n");
    printf("%-5s | %-20s | %-10s | %-8s | %-8s | %-20s\n", 
           "ROLL", "NAME", "ATTENDED", "TOTAL", "CURRENT", "MANDATORY RECOVERY");
    printf("-----------------------------------------------------------------------------------------\n");
    int defaulter_count = 0;
    for (int i = 0; i < count; i++) {
        const StudentRecord *st = &students[i];
        if (st->is_defaulter) {
            defaulter_count++;
            printf("%-5d | %-20.20s | %4d       | %4d     | %6.2f%%  | Must attend next %2d\n",
                   st->roll_no, st->name, st->total_attended, st->total_conducted,
                   st->overall_percentage, st->classes_needed);
        }
    }
    if (defaulter_count == 0) {
        printf("  Great news! No students are below the 75%% threshold.\n");
    }
    printf("=========================================================================================\n");
}

void print_subject_summary(const ClassSummary *summary) {
    printf("\n=========================================================================================\n");
    printf("                             SUBJECT-WISE PERFORMANCE                                    \n");
    printf("=========================================================================================\n");
    printf("%-10s | %-20s | %-12s | %-12s | %-10s\n",
           "CODE", "NAME", "TOTAL ATTN", "TOTAL COND", "AVG ATTN %%");
    printf("-----------------------------------------------------------------------------------------\n");
    for (int s = 0; s < summary->subject_count; s++) {
        const SubjectSummary *ss = &summary->subject_summaries[s];
        printf("%-10s | %-20.20s | %-12d | %-12d | %6.2f%%\n",
               ss->code, ss->name, ss->total_attended, ss->total_conducted, ss->average_percentage);
    }
    printf("=========================================================================================\n");
}

void print_individual_student(const StudentRecord *student) {
    printf("\n+---------------------------------------------------------------------------------------+\n");
    printf("| STUDENT PROFILE: %-20s (Roll No: %-5d | Dept: %-4s)             |\n",
           student->name, student->roll_no, student->department);
    printf("+---------------------------------------------------------------------------------------+\n");
    printf("  Overall Attendance : %d / %d (%.2f%%)\n", 
           student->total_attended, student->total_conducted, student->overall_percentage);
    printf("  Status             : %s\n", student->is_defaulter ? "CRITICAL (DEFAULTER)" : "GOOD STANDING (ELIGIBLE)");
    if (student->is_defaulter) {
        printf("  Recovery Plan      : Attend next %d consecutive classes to reach 75%%\n", student->classes_needed);
    } else {
        printf("  Safe Buffer        : Can afford to miss up to %d classes and maintain >= 75%%\n", student->safe_bunks);
    }
    printf("\n  Subject Breakdown:\n");
    for (int i = 0; i < student->subject_count; i++) {
        const SubjectRecord *sub = &student->subjects[i];
        printf("   - %-6s (%-16s) : %2d / %-2d  (%5.1f%%)  %s\n",
               sub->code, sub->name, sub->attended, sub->total, sub->percentage,
               (sub->percentage < 75.0f) ? "[SHORTAGE]" : "[OK]");
    }
    printf("+---------------------------------------------------------------------------------------+\n");
}
