#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "../include/file_handler.h"

static void trim_trailing_whitespace(char *str) {
    if (!str) return;
    int len = (int)strlen(str);
    while (len > 0 && (str[len - 1] == '\r' || str[len - 1] == '\n' || isspace((unsigned char)str[len - 1]))) {
        str[len - 1] = '\0';
        len--;
    }
}

int load_students_from_csv(const char *filename, StudentRecord *students, int max_students) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        fprintf(stderr, "Error: Could not open input file '%s'\n", filename);
        return -1;
    }

    char line[512];
    int count = 0;
    int is_header = 1;

    /* Known subject codes and descriptive names */
    const char *sub_codes[MAX_SUBJECTS] = {"MATH", "DSA", "OS", "DBMS", "CN"};
    const char *sub_names[MAX_SUBJECTS] = {
        "Mathematics", 
        "Data Structures", 
        "Operating Systems", 
        "Database Management", 
        "Computer Networks"
    };

    while (fgets(line, sizeof(line), fp) && count < max_students) {
        trim_trailing_whitespace(line);
        if (strlen(line) == 0) continue;

        if (is_header) {
            is_header = 0;
            /* If this line looks like a header, skip it */
            if (strstr(line, "Roll") || strstr(line, "roll") || strstr(line, "Name")) {
                continue;
            }
        }

        StudentRecord *st = &students[count];
        memset(st, 0, sizeof(StudentRecord));

        char *token = strtok(line, ",");
        if (!token) continue;
        st->roll_no = atoi(token);

        token = strtok(NULL, ",");
        if (!token) continue;
        strncpy(st->name, token, MAX_NAME_LEN - 1);

        token = strtok(NULL, ",");
        if (!token) continue;
        strncpy(st->department, token, MAX_DEPT_LEN - 1);

        st->subject_count = MAX_SUBJECTS;
        for (int s = 0; s < MAX_SUBJECTS; s++) {
            strncpy(st->subjects[s].code, sub_codes[s], CODE_LEN - 1);
            strncpy(st->subjects[s].name, sub_names[s], 31);

            /* Attended */
            token = strtok(NULL, ",");
            if (token) {
                st->subjects[s].attended = atoi(token);
            } else {
                st->subjects[s].attended = 0;
            }

            /* Total */
            token = strtok(NULL, ",");
            if (token) {
                st->subjects[s].total = atoi(token);
            } else {
                st->subjects[s].total = 0;
            }
        }

        count++;
    }

    fclose(fp);
    return count;
}

int export_analytics_json(const char *filename, const StudentRecord *students, int count, const ClassSummary *summary) {
    FILE *fp = fopen(filename, "w");
    if (!fp) {
        fprintf(stderr, "Error: Could not open output JSON file '%s'\n", filename);
        return -1;
    }

    fprintf(fp, "{\n");
    
    /* Summary Block */
    fprintf(fp, "  \"summary\": {\n");
    fprintf(fp, "    \"total_students\": %d,\n", summary->total_students);
    fprintf(fp, "    \"defaulters_count\": %d,\n", summary->defaulter_count);
    fprintf(fp, "    \"eligible_count\": %d,\n", summary->eligible_count);
    fprintf(fp, "    \"honors_count\": %d,\n", summary->honors_count);
    fprintf(fp, "    \"class_average\": %.2f,\n", summary->class_average);
    fprintf(fp, "    \"highest_percentage\": %.2f,\n", summary->highest_percentage);
    fprintf(fp, "    \"lowest_percentage\": %.2f,\n", summary->lowest_percentage);
    fprintf(fp, "    \"threshold\": %.2f,\n", summary->threshold);
    fprintf(fp, "    \"top_student\": {\n");
    fprintf(fp, "      \"roll\": %d,\n", summary->top_student_roll);
    fprintf(fp, "      \"name\": \"%s\",\n", summary->top_student_name);
    fprintf(fp, "      \"percentage\": %.2f\n", summary->highest_percentage);
    fprintf(fp, "    }\n");
    fprintf(fp, "  },\n");

    /* Subjects Block */
    fprintf(fp, "  \"subjects\": [\n");
    for (int s = 0; s < summary->subject_count; s++) {
        const SubjectSummary *ss = &summary->subject_summaries[s];
        fprintf(fp, "    {\n");
        fprintf(fp, "      \"code\": \"%s\",\n", ss->code);
        fprintf(fp, "      \"name\": \"%s\",\n", ss->name);
        fprintf(fp, "      \"average_percentage\": %.2f,\n", ss->average_percentage);
        fprintf(fp, "      \"total_attended\": %d,\n", ss->total_attended);
        fprintf(fp, "      \"total_conducted\": %d\n", ss->total_conducted);
        fprintf(fp, "    }%s\n", (s < summary->subject_count - 1) ? "," : "");
    }
    fprintf(fp, "  ],\n");

    /* Students Block */
    fprintf(fp, "  \"students\": [\n");
    for (int i = 0; i < count; i++) {
        const StudentRecord *st = &students[i];
        fprintf(fp, "    {\n");
        fprintf(fp, "      \"roll_no\": %d,\n", st->roll_no);
        fprintf(fp, "      \"name\": \"%s\",\n", st->name);
        fprintf(fp, "      \"department\": \"%s\",\n", st->department);
        fprintf(fp, "      \"total_attended\": %d,\n", st->total_attended);
        fprintf(fp, "      \"total_conducted\": %d,\n", st->total_conducted);
        fprintf(fp, "      \"overall_percentage\": %.2f,\n", st->overall_percentage);
        fprintf(fp, "      \"is_defaulter\": %s,\n", st->is_defaulter ? "true" : "false");
        fprintf(fp, "      \"classes_needed\": %d,\n", st->classes_needed);
        fprintf(fp, "      \"safe_bunks\": %d,\n", st->safe_bunks);
        fprintf(fp, "      \"subjects\": [\n");
        for (int s = 0; s < st->subject_count; s++) {
            const SubjectRecord *sub = &st->subjects[s];
            fprintf(fp, "        {\n");
            fprintf(fp, "          \"code\": \"%s\",\n", sub->code);
            fprintf(fp, "          \"name\": \"%s\",\n", sub->name);
            fprintf(fp, "          \"attended\": %d,\n", sub->attended);
            fprintf(fp, "          \"total\": %d,\n", sub->total);
            fprintf(fp, "          \"percentage\": %.2f\n", sub->percentage);
            fprintf(fp, "        }%s\n", (s < st->subject_count - 1) ? "," : "");
        }
        fprintf(fp, "      ]\n");
        fprintf(fp, "    }%s\n", (i < count - 1) ? "," : "");
    }
    fprintf(fp, "  ]\n");
    fprintf(fp, "}\n");

    fclose(fp);
    return 0;
}

int export_defaulters_csv(const char *filename, const StudentRecord *students, int count) {
    FILE *fp = fopen(filename, "w");
    if (!fp) {
        fprintf(stderr, "Error: Could not open output CSV file '%s'\n", filename);
        return -1;
    }

    fprintf(fp, "RollNo,Name,Department,Attended,Total,Percentage,ConsecutiveClassesNeededToReach75\n");
    for (int i = 0; i < count; i++) {
        const StudentRecord *st = &students[i];
        if (st->is_defaulter) {
            fprintf(fp, "%d,\"%s\",%s,%d,%d,%.2f,%d\n",
                    st->roll_no, st->name, st->department,
                    st->total_attended, st->total_conducted,
                    st->overall_percentage, st->classes_needed);
        }
    }

    fclose(fp);
    return 0;
}
