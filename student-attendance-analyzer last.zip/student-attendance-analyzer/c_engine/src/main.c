#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "../include/student.h"
#include "../include/analytics.h"
#include "../include/file_handler.h"

static void clear_input_buffer(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

static void to_lowercase(char *dest, const char *src, size_t max_len) {
    size_t i = 0;
    for (; i < max_len - 1 && src[i]; i++) {
        dest[i] = (char)tolower((unsigned char)src[i]);
    }
    dest[i] = '\0';
}

static void search_student_menu(StudentRecord *students, int count) {
    char query[64];
    printf("\nEnter Roll Number or Name to search: ");
    if (!fgets(query, sizeof(query), stdin)) return;
    
    /* Trim newline */
    size_t len = strlen(query);
    while (len > 0 && (query[len - 1] == '\n' || query[len - 1] == '\r')) {
        query[--len] = '\0';
    }
    if (len == 0) return;

    int is_numeric = 1;
    for (size_t i = 0; i < len; i++) {
        if (!isdigit((unsigned char)query[i])) {
            is_numeric = 0;
            break;
        }
    }

    int found = 0;
    if (is_numeric) {
        int target_roll = atoi(query);
        for (int i = 0; i < count; i++) {
            if (students[i].roll_no == target_roll) {
                print_individual_student(&students[i]);
                found = 1;
                break;
            }
        }
    } else {
        char query_lower[64];
        to_lowercase(query_lower, query, sizeof(query_lower));

        for (int i = 0; i < count; i++) {
            char name_lower[64];
            to_lowercase(name_lower, students[i].name, sizeof(name_lower));
            if (strstr(name_lower, query_lower)) {
                print_individual_student(&students[i]);
                found = 1;
            }
        }
    }

    if (!found) {
        printf("No student matched the search query '%s'.\n", query);
    }
}

static void what_if_calculator(void) {
    printf("\n--- WHAT-IF ATTENDANCE & BUNK SIMULATOR ---\n");
    int attended = 0, total = 0;
    float threshold = 75.0f;

    printf("Enter current classes attended: ");
    if (scanf("%d", &attended) != 1) { clear_input_buffer(); return; }
    printf("Enter total classes conducted: ");
    if (scanf("%d", &total) != 1) { clear_input_buffer(); return; }
    clear_input_buffer();

    if (total <= 0 || attended < 0 || attended > total) {
        printf("Error: Invalid inputs. Attended cannot exceed Total.\n");
        return;
    }

    float current_pct = ((float)attended / (float)total) * 100.0f;
    printf("\nCurrent Attendance: %d / %d = %.2f%%\n", attended, total, current_pct);

    if (current_pct < threshold) {
        int needed = calculate_classes_needed(attended, total, threshold);
        printf("[SHORTAGE ALERT] You are BELOW %.0f%%.\n", threshold);
        printf(">> You must attend the NEXT %d CONSECUTIVE CLASSES without missing any to reach %.0f%%.\n",
               needed, threshold);
        printf("   (New total will be: %d / %d = %.2f%%)\n",
               attended + needed, total + needed,
               ((float)(attended + needed) / (float)(total + needed)) * 100.0f);
    } else {
        int bunks = calculate_safe_bunks(attended, total, threshold);
        printf("[SAFE STATUS] You are currently ELIGIBLE (>= %.0f%%).\n", threshold);
        if (bunks > 0) {
            printf(">> You can safely MISS up to %d consecutive upcoming classes and still stay >= %.0f%%.\n",
                   bunks, threshold);
            printf("   (If you miss %d classes: %d / %d = %.2f%%)\n",
                   bunks, attended, total + bunks,
                   ((float)attended / (float)(total + bunks)) * 100.0f);
        } else {
            printf(">> You are on the border! You cannot miss any classes without dropping below %.0f%%.\n", threshold);
        }
    }
}

int main(int argc, char *argv[]) {
    StudentRecord students[MAX_STUDENTS];
    ClassSummary summary;
    float threshold = DEFAULT_THRESHOLD;

    const char *csv_path = "data/attendance.csv";
    const char *json_path = "data/analytics_report.json";
    const char *defaulter_csv_path = "data/defaulters_notice.csv";

    if (argc >= 2) {
        csv_path = argv[1];
    }

    print_banner();
    printf("Loading attendance records from: %s\n", csv_path);

    int student_count = load_students_from_csv(csv_path, students, MAX_STUDENTS);
    if (student_count <= 0) {
        /* Attempt alternative relative path */
        csv_path = "../data/attendance.csv";
        json_path = "../data/analytics_report.json";
        defaulter_csv_path = "../data/defaulters_notice.csv";
        student_count = load_students_from_csv(csv_path, students, MAX_STUDENTS);
    }

    if (student_count <= 0) {
        printf("Failed to load records. Please verify '%s' exists.\n", csv_path);
        return 1;
    }

    compute_class_summary(students, student_count, &summary, threshold);
    printf("Successfully loaded and analyzed %d students.\n", student_count);

    /* Automatically export the JSON so the web dashboard is in sync */
    export_analytics_json(json_path, students, student_count, &summary);
    printf("Analytics data synced to: %s\n", json_path);

    int choice = 0;
    while (1) {
        printf("\n==================== MAIN MENU ====================\n");
        printf(" [1] Class Analytics Overview Card\n");
        printf(" [2] Complete Student Roster & Status Table\n");
        printf(" [3] Official Defaulter Shortage List (< 75%%)\n");
        printf(" [4] Subject-Wise Performance Analysis\n");
        printf(" [5] Search Student Profile (Roll No / Name)\n");
        printf(" [6] What-If Attendance & Safe Bunk Simulator\n");
        printf(" [7] Re-export JSON for Web UI\n");
        printf(" [8] Export Official Defaulters Notice (CSV)\n");
        printf(" [9] Exit Program\n");
        printf("===================================================\n");
        printf("Enter selection (1-9): ");

        if (scanf("%d", &choice) != 1) {
            clear_input_buffer();
            printf("Invalid input. Please enter a number between 1 and 9.\n");
            continue;
        }
        clear_input_buffer();

        switch (choice) {
            case 1:
                print_summary_card(&summary);
                break;
            case 2:
                print_student_table(students, student_count);
                break;
            case 3:
                print_defaulter_report(students, student_count);
                break;
            case 4:
                print_subject_summary(&summary);
                break;
            case 5:
                search_student_menu(students, student_count);
                break;
            case 6:
                what_if_calculator();
                break;
            case 7:
                if (export_analytics_json(json_path, students, student_count, &summary) == 0) {
                    printf("Successfully exported to %s\n", json_path);
                }
                break;
            case 8:
                if (export_defaulters_csv(defaulter_csv_path, students, student_count) == 0) {
                    printf("Defaulters notice generated: %s\n", defaulter_csv_path);
                }
                break;
            case 9:
                printf("\nExiting Student Attendance Analytics System. Goodbye!\n");
                return 0;
            default:
                printf("Invalid selection. Please choose an option between 1 and 9.\n");
                break;
        }
    }

    return 0;
}
