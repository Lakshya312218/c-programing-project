"""
UPES Student Attendance Analysis System
Database Architecture & SQLite Persistence Manager
Compatible with Python 3.8+ (using built-in sqlite3)
"""

import os
import sqlite3
import csv

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "upes_attendance.db")
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

def get_connection():
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_schema(conn):
    """Create all required relational tables, constraints, and indexes with transactions."""
    with conn:
        # 1. Students Table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                student_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                department TEXT NOT NULL DEFAULT 'CSE',
                semester INTEGER NOT NULL DEFAULT 1,
                section TEXT NOT NULL DEFAULT 'CSE-1',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # 2. Faculty Table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS faculty (
                faculty_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                assigned_subjects TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # 3. Subjects Table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS subjects (
                subject_id TEXT PRIMARY KEY,
                subject_name TEXT NOT NULL,
                department TEXT NOT NULL DEFAULT 'CSE',
                semester INTEGER NOT NULL DEFAULT 1,
                total_planned INTEGER NOT NULL DEFAULT 45
            );
        """)

        # 4. Student-Subject Assignments
        conn.execute("""
            CREATE TABLE IF NOT EXISTS student_subject_assignments (
                student_id TEXT NOT NULL,
                subject_id TEXT NOT NULL,
                PRIMARY KEY (student_id, subject_id)
            );
        """)

        # 5. Attendance Records Table (Unique composite constraint prevents duplicates)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS attendance_records (
                attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT NOT NULL,
                subject_id TEXT NOT NULL,
                attendance_date TEXT NOT NULL,
                status TEXT CHECK(status IN ('Present', 'Absent')) NOT NULL,
                updated_by TEXT NOT NULL,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (student_id, subject_id, attendance_date)
            );
        """)

        # 6. Notifications Table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS notifications (
                notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT NOT NULL,
                message TEXT NOT NULL,
                subject_id TEXT DEFAULT 'ALL',
                notification_type TEXT DEFAULT 'info',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                read_status INTEGER DEFAULT 0
            );
        """)

        # 7. Upload History Table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS upload_history (
                upload_id INTEGER PRIMARY KEY AUTOINCREMENT,
                faculty_id TEXT NOT NULL,
                subject_id TEXT NOT NULL,
                file_name TEXT NOT NULL,
                upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                record_count INTEGER NOT NULL DEFAULT 0,
                upload_status TEXT NOT NULL DEFAULT 'Success'
            );
        """)

        # 8. User Sessions Table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS user_sessions (
                session_token TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                role TEXT CHECK(role IN ('STUDENT', 'FACULTY')) NOT NULL,
                expires_at INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # 9. Audit Logs Table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                user_id TEXT NOT NULL,
                target_student TEXT,
                subject_id TEXT,
                attendance_date TEXT,
                old_status TEXT,
                new_status TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # --- Performance & Integrity Indexes ---
        conn.execute("CREATE INDEX IF NOT EXISTS idx_att_student_subject ON attendance_records(student_id, subject_id);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_att_date ON attendance_records(attendance_date);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_notif_student ON notifications(student_id, read_status);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_sess_token ON user_sessions(session_token, expires_at);")

        # Seed subjects if missing
        subjects = [
            ("CSE101", "Engineering Mathematics", "CSE", 1, 45),
            ("CSE102", "C Programming", "CSE", 1, 45),
            ("CSE103", "Engineering Physics", "CSE", 1, 45),
            ("CSE104", "Basic Electrical Engg.", "CSE", 1, 45),
            ("CSE105", "Environmental Studies", "CSE", 1, 45),
            ("CSE106", "Engineering Graphics", "CSE", 1, 45)
        ]
        conn.executemany("""
            INSERT OR IGNORE INTO subjects (subject_id, subject_name, department, semester, total_planned)
            VALUES (?, ?, ?, ?, ?)
        """, subjects)

        # Seed faculty if missing
        import hashlib
        def h_pwd(pwd, salt):
            return hashlib.sha256(f"{salt}:{pwd}".encode("utf-8")).hexdigest()

        faculty = [
            ("FAC101", "Dr. Rajesh Sharma", "dr.rajesh@faculty.upes.ac.in", h_pwd("faculty123", "salt_fac_101"), "salt_fac_101", "CSE101,CSE102,CSE103,CSE104,CSE105,CSE106"),
            ("FAC102", "Dr. Priya Nair", "dr.priya@faculty.upes.ac.in", h_pwd("faculty123", "salt_fac_102"), "salt_fac_102", "CSE101,CSE102")
        ]
        conn.executemany("""
            INSERT OR IGNORE INTO faculty (faculty_id, name, email, password_hash, salt, assigned_subjects)
            VALUES (?, ?, ?, ?, ?, ?)
        """, faculty)

        # Seed 20 students if missing
        names = [
            "Aarav Sharma", "Diya Patel", "Rohan Verma", "Ananya Iyer", "Kabir Mehta",
            "Isha Kapoor", "Aditya Singh", "Sneha Kulkarni", "Arjun Nair", "Vikram Malhotra",
            "Pooja Das", "Kunal Sengupta", "Meera Joshi", "Rhea Bhatia", "Tanmay Deshmukh",
            "Rishabh Pandey", "Nidhi Agarwal", "Varun Chopra", "Kavya Saxena", "Siddharth Jain"
        ]
        students = []
        assignments = []
        for i, nm in enumerate(names):
            sid = f"UPES5000{101 + i}"
            salt = f"salt_stu_{101 + i}"
            em = f"student.{101 + i}@stu.upes.ac.in"
            students.append((sid, nm, em, h_pwd("student123", salt), salt, "CSE", 1, "CSE-1"))
            for sub_code, _, _, _, _ in subjects:
                assignments.append((sid, sub_code))

        conn.executemany("""
            INSERT OR IGNORE INTO students (student_id, name, email, password_hash, salt, department, semester, section)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, students)

        conn.executemany("""
            INSERT OR IGNORE INTO student_subject_assignments (student_id, subject_id)
            VALUES (?, ?)
        """, assignments)

def sync_from_csv(conn):
    """Synchronize persisted CSV data into SQLite tables."""
    att_csv = os.path.join(DATA_DIR, "lecture_attendance.csv")
    if not os.path.exists(att_csv):
        att_csv = os.path.join(DATA_DIR, "attendance.csv")
    if os.path.exists(att_csv):
        with open(att_csv, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            fieldnames = [fn.lower().strip() for fn in (reader.fieldnames or [])]
            if "student_id" in fieldnames or "studentid" in fieldnames:
                with conn:
                    for row in reader:
                        sid = row.get("student_id") or row.get("StudentID")
                        sub = row.get("subject_id") or row.get("SubjectID")
                        dt = row.get("date") or row.get("attendance_date")
                        st = row.get("status") or "Present"
                        by = row.get("updated_by") or "FACULTY"
                        lu = row.get("last_updated") or dt
                        if sid and sub and dt:
                            conn.execute("""
                                INSERT INTO attendance_records (student_id, subject_id, attendance_date, status, updated_by, last_updated)
                                VALUES (?, ?, ?, ?, ?, ?)
                                ON CONFLICT(student_id, subject_id, attendance_date) DO UPDATE SET
                                    status = excluded.status,
                                    updated_by = excluded.updated_by,
                                    last_updated = excluded.last_updated;
                            """, (sid, sub, dt, st, by, lu))

    # Synchronize notifications
    notif_csv = os.path.join(DATA_DIR, "notifications.csv")
    if os.path.exists(notif_csv):
        with open(notif_csv, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            with conn:
                for row in reader:
                    conn.execute("""
                        INSERT OR IGNORE INTO notifications (notification_id, student_id, message, subject_id, notification_type, created_at, read_status)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (row.get("notification_id"), row.get("student_id"), row.get("message"),
                          row.get("subject_id", "ALL"), row.get("notification_type", "info"),
                          row.get("created_at"), int(row.get("read_status", 0))))

    # Synchronize upload history
    up_csv = os.path.join(DATA_DIR, "uploads.csv")
    if os.path.exists(up_csv):
        with open(up_csv, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            with conn:
                for row in reader:
                    conn.execute("""
                        INSERT OR IGNORE INTO upload_history (upload_id, faculty_id, subject_id, file_name, upload_date, record_count, upload_status)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (row.get("upload_id"), row.get("faculty_id"), row.get("subject_id"),
                          row.get("file_name"), row.get("upload_date"),
                          int(row.get("record_count", 0)), row.get("upload_status", "Success")))

def get_stats(conn):
    cursor = conn.cursor()
    tables = ["students", "faculty", "subjects", "attendance_records", "notifications", "upload_history", "audit_logs"]
    stats = {}
    for t in tables:
        try:
            cursor.execute(f"SELECT COUNT(*) FROM {t}")
            stats[t] = cursor.fetchone()[0]
        except Exception:
            stats[t] = 0
    return stats

if __name__ == "__main__":
    conn = get_connection()
    init_schema(conn)
    sync_from_csv(conn)
    stats = get_stats(conn)
    print("=================================================================")
    print(" UPES SQLite Database Initialized & Synchronized Successfully   ")
    print(f" Database Path: {DB_PATH}")
    print("=================================================================")
    for table, count in stats.items():
        print(f" * {table:25}: {count:6} records")
    print("=================================================================")
    conn.close()
