@echo off
echo =======================================================================
echo    Compiling UPES Student Attendance Analysis System (C HTTP Server v2)
echo =======================================================================

taskkill /F /IM upes_server.exe >nul 2>&1
timeout /t 1 /nobreak >nul

gcc -Wall -Wextra -std=c99 -I c_src c_src/main.c c_src/analytics.c c_src/database.c c_src/sha256.c c_src/server.c -o upes_server.exe -lws2_32

if %errorlevel% equ 0 (
    echo [SUCCESS] Compilation Succeeded!
    echo Created executable: upes_server.exe
    echo.
    echo Starting UPES Web Application Server on port 5000...
    start "" "http://localhost:5000"
    upes_server.exe 5000
) else (
    echo [ERROR] Compilation failed. Please ensure GCC/MinGW is available in PATH.
)

pause
