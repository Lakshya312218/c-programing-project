# UPES Student Attendance Analysis System

A production-grade, dual-portal academic management web application engineered for **UPES (University of Petroleum and Energy Studies)**, Dehradun, India.

> **Project Prototype Notice:** This system is developed as an academic college project prototype for the Department of Computer Science & Engineering (CSE).

---

## ⚡ Quick Start: How to Connect the Server

### 🎯 Option 1: 1-Click Desktop Launcher (Fastest & Easiest)
1. Go to your **Desktop**.
2. Double-click **`Run_Attendance_System.bat`**.
3. A command window will launch the server engine on **port 5000**, and your browser will automatically open **`http://localhost:5000`**!
4. **Keep that command window open** while using the website. To stop the server, press `Ctrl+C` or close the window.

---

### 💻 Option 2: How to Open and Run in VS Code

If you saw the message **"404 Not Found - Resource does not exist"**, that happened because VS Code's *Live Preview* extension was looking for files without the backend server running. Here is the correct way to run it in VS Code:

1. In VS Code, go to **File > Open Folder...** and select `student-attendance-analyzer`.
2. **Method A (Press F5):**
   - Press **`F5`** or go to the **Run & Debug** tab on the left and click **Run UPES Attendance Server (Python)**.
   - It will start the server on port 5000.
3. **Method B (VS Code Terminal):**
   - Press ``Ctrl + ` `` to open the terminal.
   - Type:
     ```bash
     python server.py 5000
     ```
     *(or `./upes_server.exe 5000`)*
   - Open your browser to: **[http://localhost:5000](http://localhost:5000)**
4. If you use VS Code's **Live Preview** or **Live Server**, the root `index.html` will now automatically detect the server and route all API calls to `http://localhost:5000` seamlessly!

---

## 🔑 Demonstration Accounts

| Role | Username / ID | Password | Access Details |
| :--- | :--- | :--- | :--- |
| **Student (High Attendance)** | `UPES5000101` | `student123` | Aarav Sharma (91.67% Attendance — Eligible) |
| **Student (Defaulter / Shortage)** | `UPES5000102` | `student123` | Diya Patel (62.5% Attendance — Shortage Alert) |
| **Student (Borderline Edge)** | `UPES5000110` | `student123` | Vikram Malhotra (75.0% Attendance — Borderline) |
| **Faculty (Course Instructor)** | `FAC101` | `faculty123` | Dr. Rajesh Sharma (All Sem 1 CSE Courses) |
| **Faculty (Department Head)** | `FAC102` | `faculty123` | Dr. Priya Nair (CSE101, CSE102) |

---

## 🏛️ System Architecture

```text
student-attendance-analyzer/
├── index.html                   # Root Entry Point (Auto-routing & Live Preview fix)
├── upes_server.exe              # High-Performance C Server Engine (Winsock2)
├── server.py                    # Companion Python 3.13 REST API & Web Server
├── db_sqlite.py                 # SQLite Relational Persistence (9 relational tables)
├── calculations.py              # Attendance, recovery & leave math engine
├── run_automated_tests.py       # Automated 22-step End-to-End Test Suite
├── run_server.bat               # 1-Click Server launcher script
│
├── c_src/                       # C Programming Source Code
│   ├── models.h                 # Data structures (Student, Faculty, Sessions, Logs)
│   ├── sha256.h / .c            # RFC 6234 standard SHA-256 + Password Salting
│   ├── analytics.h / .c         # Mathematical recovery & leave algorithms
│   ├── database.h / .c          # Multi-table in-memory & CSV persistence
│   ├── server.h / .c            # High-performance Winsock2 HTTP Server & JSON APIs
│   └── main.c                   # Server entry point
│
├── data/                        # Persistent Storage (Survives Server Restarts)
│   ├── upes_attendance.db       # SQLite Database (Students, Faculty, Subjects, Records)
│   ├── lecture_attendance.csv   # 2,880 historical lecture attendance records
│   ├── notifications.csv        # Student alerts and warning notifications
│   ├── uploads.csv              # Faculty batch upload audit history
│   └── audit_logs.csv           # Security audit logs
│
├── web_ui/                      # Web Presentation Layer (HTML5 / CSS3 / Vanilla JS)
│   ├── index.html               # Dual Portal Selection Landing Page
│   ├── student_login.html       # UPES Student Portal Login (Quick-Fill Demo buttons)
│   ├── faculty_login.html       # UPES Faculty Portal Login
│   ├── student_dashboard.html   # Student Portal: Attendance, Recovery, Simulator, PDF
│   ├── faculty_dashboard.html   # Faculty Portal: Roster Marking, Excel/CSV Upload, Reports
│   ├── css/
│   │   └── upes_style.css       # Clean, minimal white & UPES navy design
│   └── js/
│       ├── student_portal.js    # Student charts, recovery simulator & jsPDF export
│       └── faculty_portal.js    # SheetJS Excel parser, manual marking & reports
│
├── .vscode/                     # VS Code Workspace Configuration
│   ├── launch.json              # F5 Debugger profiles (Python & C)
│   ├── tasks.json               # Build & run tasks
│   └── settings.json            # Workspace environment settings
│
└── sample_templates/
    └── upes_attendance_template.csv # Official roster template for faculty uploads
```

---

## 📐 Mathematical Formulas

### 1. Attendance Percentage
$$\text{Attendance \%} = \left(\frac{\text{Attended Classes}}{\text{Total Classes Conducted}}\right) \times 100$$

### 2. Defaulter Recovery Classes
When attendance falls below threshold $R$ ($0.75$ for $75\%$), the minimum consecutive future classes $n$ required is:
$$n = \left\lceil \frac{R \cdot T - A}{1 - R} \right\rceil$$

### 3. Allowable Leaves (Bunk Buffer)
For an eligible student ($\ge 75\%$), the maximum number of classes $x$ they can safely miss:
$$x = \left\lfloor \frac{A}{R} - T \right\rfloor$$

### 4. Remaining Semester Realism Check
$$\text{Remaining} = \max(0, T_{\text{planned}} - T)$$
If $n > \text{Remaining}$, the system explicitly alerts that standard recovery within remaining scheduled lectures is mathematically impossible.

---

## 🔒 Security Features
1. **RFC 6234 SHA-256 with Salting:** No plaintext passwords anywhere in database or code.
2. **Server-Side Session Validation:** 64-character cryptographic tokens.
3. **Role-Based Access Control (RBAC):** Students cannot view other students' records or access faculty APIs (HTTP 403 Forbidden).
4. **Brute-Force Rate Limiting:** Locks login for 10 minutes after 5 consecutive failed attempts.
5. **Path Traversal Protection:** Blocks `../` URL attacks against the filesystem.
6. **Robust CSV / Excel Parser:** Detects invalid roll numbers, malformed dates, and missing columns with per-row diagnostic feedback.

---

## 🧪 Automated Testing
To run the automated 22-step verification test suite:
```bash
python run_automated_tests.py
```
Outputs:
```text
=================================================================
 [ALL TESTS PASSED SUCCESSFULLY! 100% VERIFIED]                 
=================================================================
```
