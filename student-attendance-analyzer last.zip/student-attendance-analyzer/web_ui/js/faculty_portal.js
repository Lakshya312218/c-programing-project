/* ============================================================
   UPES Faculty Portal — Client Engine v2.0
   Clean, Professional, Secure & Real Data Integration
   ============================================================ */

'use strict';

const API_BASE = (window.location.protocol === 'http:' && window.location.port === '5000') ? '' : 'http://localhost:5000';

let currentFaculty = null;
let authToken      = null;
let allStudents    = [];
let currentRoster  = [];
let parsedRows     = [];
let currentReportData = [];
let currentReportType = 'all';

const SUBJECTS_MAP = {
  CSE101: 'Engineering Mathematics',
  CSE102: 'C Programming',
  CSE103: 'Engineering Physics',
  CSE104: 'Basic Electrical Engg.',
  CSE105: 'Environmental Studies',
  CSE106: 'Engineering Graphics',
};

// ── Initialization ───────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  const sessionStr = sessionStorage.getItem('faculty_session');
  if (!sessionStr) {
    window.location.href = 'faculty_login.html';
    return;
  }

  try {
    const session = JSON.parse(sessionStr);
    currentFaculty = session.faculty;
    authToken = session.token;
  } catch (e) {
    sessionStorage.clear();
    window.location.href = 'faculty_login.html';
    return;
  }

  if (!currentFaculty || !authToken) {
    sessionStorage.clear();
    window.location.href = 'faculty_login.html';
    return;
  }

  // Populate Header info
  document.getElementById('facultyNameLabel').textContent = currentFaculty.name || currentFaculty.id;
  document.getElementById('profileName').textContent = currentFaculty.name || 'Faculty Instructor';
  document.getElementById('profileId').textContent = currentFaculty.id;
  document.getElementById('profileSubjects').textContent = currentFaculty.subjects || 'All Semester 1 Courses';

  // Set default dates
  const today = new Date().toISOString().split('T')[0];
  const maDate = document.getElementById('ma-date');
  const upDate = document.getElementById('up-date');
  if (maDate) maDate.value = today;
  if (upDate) upDate.value = today;

  // Load Real Data
  await loadOverview();
  await loadAllStudents();
  await loadUploadHistory();
});

// ── Tab Switching ────────────────────────────────────────────
function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.toggle('active', c.id === `tab-${name}`));
}

// ── Authenticated Fetch Helper ───────────────────────────────
async function authFetch(url, options = {}) {
  const fullUrl = url.startsWith('http') ? url : (API_BASE + url);
  options.headers = options.headers || {};
  if (authToken) {
    options.headers['Authorization'] = `Bearer ${authToken}`;
  }
  let res;
  try {
    res = await fetch(fullUrl, options);
  } catch (err) {
    showToast('Cannot connect to backend server on port 5000. Please start the server.', 'error');
    throw err;
  }
  if (res.status === 401 || res.status === 403) {
    showToast('Session expired or unauthorized. Please log in again.', 'error');
    setTimeout(() => {
      sessionStorage.clear();
      window.location.href = 'faculty_login.html';
    }, 1500);
    throw new Error('Unauthorized');
  }
  return res;
}

// ── Overview & Defaulters ────────────────────────────────────
async function loadOverview() {
  try {
    const res = await authFetch('/api/faculty/overview');
    const data = await res.json();
    if (data.success) {
      document.getElementById('ov-students').textContent   = data.total_students || 0;
      document.getElementById('ov-subjects').textContent   = data.total_subjects || 6;
      document.getElementById('ov-eligible').textContent   = data.eligible_count || 0;
      document.getElementById('ov-defaulters').textContent = data.defaulters_count || 0;
    }
  } catch (err) {
    console.error('Error loading overview stats:', err);
  }

  // Load Defaulters List
  try {
    const res = await authFetch('/api/faculty/reports?type=low_attendance');
    const data = await res.json();
    renderDefaulters(data.students || []);
  } catch (err) {
    console.error('Error loading defaulter watchlist:', err);
  }
}

function renderDefaulters(list) {
  const tbody = document.getElementById('defaulterList');
  if (list.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px; color:var(--green); font-weight:600;">✓ Excellent! All students are currently meeting the mandatory 75% attendance threshold.</td></tr>';
    return;
  }

  tbody.innerHTML = list.map(s => {
    const deficit = (75.0 - s.percentage).toFixed(1);
    return `
      <tr>
        <td><strong style="font-family:monospace; color:var(--navy);">${s.id}</strong></td>
        <td><strong>${s.name}</strong></td>
        <td>${s.dept || 'CSE'} (Sem ${s.semester || 1})</td>
        <td><span style="font-weight:700; color:var(--red);">${s.percentage.toFixed(1)}%</span></td>
        <td><span class="badge badge-red">-${deficit}% below</span></td>
        <td><strong>${s.classes_needed} consecutive classes</strong></td>
      </tr>
    `;
  }).join('');
}

// ── Manual Attendance Recording ──────────────────────────────
async function loadRoster() {
  const subject = document.getElementById('ma-subject').value;
  const date    = document.getElementById('ma-date').value;

  if (!subject) {
    showToast('Please select a course', 'error');
    return;
  }
  if (!date) {
    showToast('Please select a lecture date', 'error');
    return;
  }

  try {
    const res = await authFetch(`/api/faculty/roster?subject=${encodeURIComponent(subject)}&date=${encodeURIComponent(date)}`);
    const data = await res.json();
    if (!data.success) throw new Error(data.message || 'Failed to load roster');

    currentRoster = data.students || [];
    renderRoster(subject, date);
  } catch (err) {
    showToast(err.message || 'Error loading class roster', 'error');
  }
}

function renderRoster(subject, date) {
  const card  = document.getElementById('rosterCard');
  const title = document.getElementById('rosterTitle');
  const sub   = document.getElementById('rosterSub');
  const cont  = document.getElementById('rosterContainer');

  title.textContent = `${SUBJECTS_MAP[subject] || subject} — Lecture Roster`;
  sub.textContent   = `Class Date: ${date} • Enrolled Students: ${currentRoster.length}`;
  card.style.display = 'block';

  cont.innerHTML = currentRoster.map((s, idx) => {
    const isPresent = (s.status === 'Present');
    const pctColor = s.percentage >= 75 ? 'var(--green)' : s.percentage >= 60 ? 'var(--amber)' : 'var(--red)';
    return `
      <div class="roster-card" id="rosterRow_${s.id}">
        <div class="roster-student-info">
          <span style="font-weight:700; color:var(--text-light); width:24px;">${idx + 1}.</span>
          <span class="roster-id">${s.id}</span>
          <span class="roster-name">${s.name}</span>
          <span class="roster-pct" style="background:#f1f5f9; color:${pctColor};">
            ${s.percentage.toFixed(1)}%
          </span>
        </div>
        <div class="roster-controls">
          <button type="button" class="btn-toggle-att ${isPresent ? 'present' : ''}"
                  onclick="setStudentStatus('${s.id}', 'Present')">Present</button>
          <button type="button" class="btn-toggle-att ${!isPresent ? 'absent' : ''}"
                  onclick="setStudentStatus('${s.id}', 'Absent')">Absent</button>
        </div>
      </div>
    `;
  }).join('');

  card.scrollIntoView({ behavior: 'smooth' });
}

function setStudentStatus(id, status) {
  const st = currentRoster.find(r => r.id === id);
  if (st) st.status = status;

  const row = document.getElementById(`rosterRow_${id}`);
  if (row) {
    const pBtn = row.querySelector('.btn-toggle-att:first-child');
    const aBtn = row.querySelector('.btn-toggle-att:last-child');
    if (status === 'Present') {
      pBtn.classList.add('present');
      aBtn.classList.remove('absent');
    } else {
      pBtn.classList.remove('present');
      aBtn.classList.add('absent');
    }
  }
}

function markAllRoster(status) {
  currentRoster.forEach(s => setStudentStatus(s.id, status));
}

function promptConfirmManualSave() {
  const subject = document.getElementById('ma-subject').value;
  const date    = document.getElementById('ma-date').value;

  const presentCount = currentRoster.filter(r => r.status === 'Present').length;
  const absentCount  = currentRoster.length - presentCount;

  openConfirmModal(
    'Confirm Attendance Submission',
    `You are recording attendance for <strong>${SUBJECTS_MAP[subject] || subject}</strong> on <strong>${date}</strong>:<br><br>
     • <strong>Present:</strong> ${presentCount} students<br>
     • <strong>Absent:</strong> ${absentCount} students<br><br>
     Would you like to synchronize these records with the central academic database?`,
    executeSaveManualAttendance
  );
}

async function executeSaveManualAttendance() {
  const subject = document.getElementById('ma-subject').value;
  const date    = document.getElementById('ma-date').value;

  const records = currentRoster.map(r => ({
    student_id: r.id,
    status: r.status || 'Present'
  }));

  try {
    const res = await authFetch('/api/faculty/attendance/manual', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subject_id: subject,
        date: date,
        faculty_id: currentFaculty.id,
        records: records
      })
    });

    const data = await res.json();
    if (data.success) {
      showToast(`Success: Recorded ${data.marked_count || 0} and updated ${data.updated_count || 0} attendance records ✅`, 'success');
      document.getElementById('rosterCard').style.display = 'none';
      await loadOverview();
      await loadAllStudents();
    } else {
      showToast(data.message || 'Failed to save attendance', 'error');
    }
  } catch (err) {
    showToast(err.message || 'Network error saving attendance', 'error');
  }
}

// ── Excel (.xlsx) & CSV Upload Engine ────────────────────────
function handleFileDrop(e) {
  e.preventDefault();
  document.getElementById('uploadZone').classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) processUploadedFile(file);
}

function handleFileSelect(e) {
  const file = e.target.files[0];
  if (file) processUploadedFile(file);
}

function processUploadedFile(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (!['xlsx', 'xls', 'csv'].includes(ext)) {
    showToast('Unsupported file type. Please upload a valid .xlsx or .csv file.', 'error');
    return;
  }

  document.getElementById('previewFilename').textContent = `File: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;

  const reader = new FileReader();

  if (ext === 'xlsx' || ext === 'xls') {
    reader.onload = function(e) {
      try {
        if (!window.XLSX) {
          showToast('Excel parser library loading, please try in a moment.', 'warning');
          return;
        }
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        validateAndParseRows(jsonRows, file.name);
      } catch (err) {
        showToast('Error parsing Excel file structure: ' + err.message, 'error');
      }
    };
    reader.readAsArrayBuffer(file);
  } else {
    // CSV File
    reader.onload = function(e) {
      const text = e.target.result;
      const lines = text.split(/\r?\n/).map(l => l.split(','));
      validateAndParseRows(lines, file.name);
    };
    reader.readAsText(file);
  }
}

function validateAndParseRows(rawGrid, filename) {
  if (!rawGrid || rawGrid.length < 2) {
    showToast('Uploaded spreadsheet does not contain any data rows.', 'error');
    return;
  }

  const fallbackDate = document.getElementById('up-date').value || new Date().toISOString().split('T')[0];
  const targetSub    = document.getElementById('up-subject').value || 'CSE102';

  parsedRows = [];
  const errors = [];

  // Parse header
  const header = rawGrid[0].map(h => String(h || '').trim().toLowerCase().replace(/\s+/g, '_'));
  let idCol = header.findIndex(h => h.includes('student') || h.includes('id') || h.includes('roll'));
  let dateCol = header.findIndex(h => h.includes('date'));
  let statusCol = header.findIndex(h => h.includes('status') || h.includes('attendance'));
  let nameCol = header.findIndex(h => h.includes('name'));

  if (idCol === -1) idCol = 0;
  if (dateCol === -1 && rawGrid[0].length >= 3) dateCol = 2;
  if (statusCol === -1) statusCol = rawGrid[0].length - 1;

  for (let r = 1; r < rawGrid.length; r++) {
    const row = rawGrid[r];
    if (!row || row.length === 0 || !row[0]) continue;

    const rawId = String(row[idCol] || '').trim();
    if (!rawId) continue;

    let dt = (dateCol !== -1 && row[dateCol]) ? String(row[dateCol]).trim() : fallbackDate;
    // Format Excel serial dates if needed
    if (!isNaN(dt) && Number(dt) > 40000) {
      const dateObj = new Date(Math.round((Number(dt) - 25569) * 86400 * 1000));
      dt = dateObj.toISOString().split('T')[0];
    }

    let statRaw = (statusCol !== -1 && row[statusCol]) ? String(row[statusCol]).trim().toLowerCase() : 'present';
    let stat = 'Present';
    if (statRaw === 'a' || statRaw === 'absent' || statRaw === '0') {
      stat = 'Absent';
    } else if (statRaw === 'p' || statRaw === 'present' || statRaw === '1') {
      stat = 'Present';
    } else {
      errors.push(`Row ${r + 1}: Invalid status "${statRaw}" (must be Present or Absent)`);
    }

    // Validate student existence
    const registeredStudent = allStudents.find(s => s.id === rawId);
    let sName = (nameCol !== -1 && row[nameCol]) ? String(row[nameCol]).trim() : (registeredStudent ? registeredStudent.name : '—');

    let isValid = true;
    let note = 'Valid';

    if (!registeredStudent) {
      isValid = false;
      note = `Unregistered ID (${rawId})`;
      errors.push(`Row ${r + 1}: Student ID "${rawId}" not registered in database roster`);
    } else if (!/^\d{4}-\d{2}-\d{2}$/.test(dt)) {
      isValid = false;
      note = 'Invalid Date Format';
      errors.push(`Row ${r + 1}: Date "${dt}" is not in YYYY-MM-DD format`);
    }

    parsedRows.push({
      rowNum: r + 1,
      id: rawId,
      name: sName,
      date: dt,
      status: stat,
      isValid: isValid,
      note: note
    });
  }

  renderUploadPreview(errors);
}

function renderUploadPreview(errors) {
  const card = document.getElementById('uploadPreviewCard');
  const tbody = document.getElementById('previewTableBody');
  const validPill = document.getElementById('valValidCount');
  const errPill = document.getElementById('valErrorCount');
  const errBox = document.getElementById('errorReportBox');
  const errList = document.getElementById('errorList');
  const submitBtn = document.getElementById('btnSubmitUpload');

  const validCount = parsedRows.filter(r => r.isValid).length;
  const errorCount = parsedRows.filter(r => !r.isValid).length;

  validPill.textContent = `${validCount} Valid Records`;
  errPill.textContent = `${errorCount} Rejected Records`;
  errPill.style.display = (errorCount > 0) ? 'inline-block' : 'none';

  if (errors.length > 0) {
    errBox.style.display = 'flex';
    errList.innerHTML = errors.slice(0, 10).map(e => `<li>${e}</li>`).join('') +
                        (errors.length > 10 ? `<li>… and ${errors.length - 10} more errors</li>` : '');
  } else {
    errBox.style.display = 'none';
  }

  tbody.innerHTML = parsedRows.slice(0, 25).map(r => `
    <tr style="${r.isValid ? '' : 'background:#fff1f2;'}">
      <td>${r.rowNum}</td>
      <td><strong style="font-family:monospace;">${r.id}</strong></td>
      <td>${r.name}</td>
      <td>${r.date}</td>
      <td>
        <span class="badge ${r.status === 'Present' ? 'badge-green' : 'badge-red'}">
          ${r.status}
        </span>
      </td>
      <td>
        <span class="badge ${r.isValid ? 'badge-green' : 'badge-red'}">
          ${r.note}
        </span>
      </td>
    </tr>
  `).join('');

  submitBtn.disabled = (validCount === 0);
  card.style.display = 'block';
  card.scrollIntoView({ behavior: 'smooth' });
}

function promptConfirmUpload() {
  const validRows = parsedRows.filter(r => r.isValid);
  const targetSub = document.getElementById('up-subject').value;

  openConfirmModal(
    'Confirm Spreadsheet Synchronization',
    `You are about to commit <strong>${validRows.length} attendance records</strong> for course <strong>${SUBJECTS_MAP[targetSub] || targetSub}</strong>.<br><br>
     Existing attendance for the same dates will be safely updated without duplicates. Confirm upload?`,
    executeSubmitUpload
  );
}

async function executeSubmitUpload() {
  const validRows = parsedRows.filter(r => r.isValid);
  const targetSub = document.getElementById('up-subject').value;

  const csvPayload = "student_id,name,date,status\n" +
    validRows.map(r => `${r.id},${r.name},${r.date},${r.status}`).join('\n');

  try {
    const res = await authFetch('/api/faculty/attendance/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subject_id: targetSub,
        faculty_id: currentFaculty.id,
        file_name: 'uploaded_attendance.csv',
        csv_data: csvPayload
      })
    });

    const data = await res.json();
    if (data.success) {
      showToast(`Upload synchronized: ${data.processed || validRows.length} records processed successfully ✅`, 'success');
      clearUpload();
      await loadOverview();
      await loadAllStudents();
      await loadUploadHistory();
    } else {
      showToast(data.message || 'File upload failed', 'error');
    }
  } catch (err) {
    showToast(err.message || 'Error communicating with upload endpoint', 'error');
  }
}

function clearUpload() {
  parsedRows = [];
  document.getElementById('uploadPreviewCard').style.display = 'none';
  document.getElementById('fileInput').value = '';
}

function downloadSampleTemplate() {
  const csv = "student_id,student_name,date,status\n" +
              "UPES5000101,Aarav Sharma,2026-11-09,Present\n" +
              "UPES5000102,Diya Patel,2026-11-09,Absent\n" +
              "UPES5000103,Rohan Verma,2026-11-09,Present\n" +
              "UPES5000104,Ananya Iyer,2026-11-09,Present\n" +
              "UPES5000105,Kabir Mehta,2026-11-09,Absent\n";
  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'UPES_Attendance_Template.csv';
  a.click();
  showToast('Sample template downloaded ✅', 'success');
}

async function loadUploadHistory() {
  try {
    const res = await authFetch('/api/faculty/upload-history');
    const data = await res.json();
    const tbody = document.getElementById('recentUpdates');
    const uploads = data.history || [];

    if (uploads.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:18px; color:var(--text-light);">No previous uploads recorded.</td></tr>';
      return;
    }

    tbody.innerHTML = uploads.map(u => `
      <tr>
        <td>${u.date}</td>
        <td><strong>${SUBJECTS_MAP[u.subject] || u.subject}</strong></td>
        <td style="font-family:monospace; font-size:12px;">${u.file}</td>
        <td>${u.records}</td>
        <td>${u.faculty}</td>
        <td><span class="badge ${u.status === 'Success' ? 'badge-green' : 'badge-amber'}">${u.status}</span></td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Upload history error:', err);
  }
}

// ── Student Directory ────────────────────────────────────────
async function loadAllStudents() {
  try {
    const res = await authFetch('/api/faculty/reports?type=all');
    const data = await res.json();
    allStudents = data.students || [];
    filterStudentTable();
  } catch (err) {
    console.error('Error loading students:', err);
  }
}

function filterStudentTable() {
  const query = (document.getElementById('searchStudent')?.value || '').toLowerCase().trim();
  const filter = document.getElementById('filterStatus')?.value || 'ALL';

  const filtered = allStudents.filter(s => {
    const matchSearch = (!query || s.id.toLowerCase().includes(query) || s.name.toLowerCase().includes(query));
    const matchFilter = (filter === 'ALL') ||
                        (filter === 'ELIGIBLE' && s.percentage >= 75.0) ||
                        (filter === 'DEFAULTER' && s.percentage < 75.0);
    return matchSearch && matchFilter;
  });

  const tbody = document.getElementById('allStudentsTable');
  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; padding:24px; color:var(--text-light);">No matching student records found.</td></tr>';
    return;
  }

  tbody.innerHTML = filtered.map(s => {
    const isElig = (s.percentage >= 75.0);
    const color = isElig ? 'var(--green)' : 'var(--red)';
    return `
      <tr>
        <td><strong style="font-family:monospace;">${s.id}</strong></td>
        <td><strong>${s.name}</strong></td>
        <td>${s.dept || 'CSE'}</td>
        <td>${s.section || 'CSE-1'}</td>
        <td>${s.attended}</td>
        <td>${s.conducted}</td>
        <td><strong style="color:${color};">${s.percentage.toFixed(1)}%</strong></td>
        <td><span class="badge ${isElig ? 'badge-green' : 'badge-red'}">${isElig ? 'Eligible' : 'Defaulter'}</span></td>
        <td>${isElig ? '<span style="color:var(--green);">In Good Standing</span>' : `<strong style="color:var(--red);">Need ${s.classes_needed} classes</strong>`}</td>
      </tr>
    `;
  }).join('');
}

// ── Reports & PDF Generation ─────────────────────────────────
async function generateReport(type) {
  currentReportType = type;
  try {
    const res = await authFetch(`/api/faculty/reports?type=${type}`);
    const data = await res.json();
    currentReportData = data.students || [];

    const heading = document.getElementById('reportHeading');
    const sub = document.getElementById('reportSubHeading');
    const container = document.getElementById('reportContainer');
    const tbody = document.getElementById('reportTableBody');

    if (type === 'low_attendance') {
      heading.textContent = 'Defaulter Students Report (Attendance < 75%)';
      sub.textContent = `Students requiring academic recovery • Total: ${currentReportData.length}`;
    } else if (type === 'eligible') {
      heading.textContent = 'Examination Eligible Students Report (Attendance ≥ 75%)';
      sub.textContent = `Qualified examinees • Total: ${currentReportData.length}`;
    } else {
      heading.textContent = 'Complete Semester Attendance Summary (All Students)';
      sub.textContent = `All enrolled B.Tech CSE candidates • Total: ${currentReportData.length}`;
    }

    tbody.innerHTML = currentReportData.map((s, idx) => `
      <tr>
        <td>${idx + 1}</td>
        <td><strong style="font-family:monospace;">${s.id}</strong></td>
        <td>${s.name}</td>
        <td>${s.dept || 'CSE'}</td>
        <td>${s.attended} / ${s.conducted}</td>
        <td><strong style="color:${s.percentage >= 75 ? 'var(--green)' : 'var(--red)'};">${s.percentage.toFixed(1)}%</strong></td>
        <td><span class="badge ${s.percentage >= 75 ? 'badge-green' : 'badge-red'}">${s.status}</span></td>
        <td>${s.percentage >= 75 ? '—' : `<strong>${s.classes_needed} classes</strong>`}</td>
      </tr>
    `).join('');

    container.style.display = 'block';
    container.scrollIntoView({ behavior: 'smooth' });
  } catch (err) {
    showToast('Failed to generate report', 'error');
  }
}

function exportReportCSV() {
  if (currentReportData.length === 0) return;
  const header = "student_id,name,department,semester,attended,conducted,percentage,status,classes_needed\n";
  const rows = currentReportData.map(s =>
    `${s.id},"${s.name}",${s.dept||'CSE'},${s.semester||1},${s.attended},${s.conducted},${s.percentage.toFixed(2)},${s.status},${s.classes_needed}`
  ).join('\n');

  const blob = new Blob([header + rows], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `UPES_Attendance_Report_${currentReportType}.csv`;
  a.click();
  showToast('Report CSV exported ✅', 'success');
}

function exportDefaultersCSV() {
  const defaulters = allStudents.filter(s => s.percentage < 75.0);
  const header = "student_id,name,department,percentage,classes_needed_to_reach_75\n";
  const rows = defaulters.map(s => `${s.id},"${s.name}",${s.dept||'CSE'},${s.percentage.toFixed(2)},${s.classes_needed}`).join('\n');
  const blob = new Blob([header + rows], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'UPES_Defaulters_Notice.csv';
  a.click();
  showToast('Defaulters list exported ✅', 'success');
}

function downloadFacultyPDF() {
  if (currentReportData.length === 0) {
    showToast('Generate a report first', 'error');
    return;
  }

  const { jsPDF } = window.jspdf || {};
  if (!jsPDF) {
    window.print();
    return;
  }

  try {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

    // Top Header
    doc.setFillColor(0, 33, 71);
    doc.rect(0, 0, 210, 28, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('UNIVERSITY OF PETROLEUM AND ENERGY STUDIES (UPES)', 14, 12);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('Department of Computer Science & Engineering • Official Faculty Report', 14, 20);

    // Metadata
    doc.setTextColor(30, 41, 59);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text(`REPORT: ${document.getElementById('reportHeading').textContent.toUpperCase()}`, 14, 38);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(`Generated By: ${currentFaculty.name} (${currentFaculty.id})`, 14, 45);
    doc.text(`Date of Generation: ${new Date().toLocaleDateString('en-GB')}`, 130, 45);

    // Table Header
    let y = 52;
    doc.setFillColor(0, 33, 71);
    doc.rect(14, y, 182, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.text('#', 16, y + 5);
    doc.text('Student ID', 24, y + 5);
    doc.text('Name', 58, y + 5);
    doc.text('Att / Tot', 115, y + 5);
    doc.text('Percentage', 142, y + 5);
    doc.text('Status', 170, y + 5);

    // Table Rows
    y += 7;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(30, 41, 59);

    currentReportData.forEach((s, idx) => {
      if (y > 275) {
        doc.addPage();
        y = 20;
      }
      if (idx % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, y, 182, 7, 'F');
      }
      doc.text(String(idx + 1), 16, y + 5);
      doc.text(s.id, 24, y + 5);
      doc.text(s.name.substring(0, 26), 58, y + 5);
      doc.text(`${s.attended}/${s.conducted}`, 115, y + 5);
      doc.text(`${s.percentage.toFixed(1)}%`, 144, y + 5);

      if (s.percentage >= 75) {
        doc.setTextColor(46, 125, 50);
        doc.text('Eligible', 170, y + 5);
      } else {
        doc.setTextColor(198, 40, 40);
        doc.text('Defaulter', 170, y + 5);
      }
      doc.setTextColor(30, 41, 59);
      y += 7;
    });

    doc.save(`UPES_Faculty_Report_${currentReportType}.pdf`);
    showToast('Faculty Report PDF generated successfully ✅', 'success');
  } catch (err) {
    console.error('PDF error:', err);
    window.print();
  }
}

// ── Modals & Toast Utilities ─────────────────────────────────
let confirmCallback = null;

function openConfirmModal(title, message, callback) {
  document.getElementById('confirmTitle').textContent = title;
  document.getElementById('confirmMessage').innerHTML = message;
  confirmCallback = callback;

  const modal = document.getElementById('confirmModal');
  modal.classList.remove('hidden');

  document.getElementById('confirmActionBtn').onclick = () => {
    closeConfirmModal();
    if (confirmCallback) confirmCallback();
  };
}

function closeConfirmModal() {
  document.getElementById('confirmModal').classList.add('hidden');
  confirmCallback = null;
}

function logout() {
  if (authToken) {
    fetch(API_BASE + '/api/auth/logout', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${authToken}` }
    }).catch(() => {});
  }
  sessionStorage.clear();
  window.location.href = 'faculty_login.html';
}

function showToast(msg, type = '') {
  const tc = document.getElementById('toasts');
  if (!tc) return;
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️'}</span> <div>${msg}</div>`;
  tc.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}
