/* ============================================================
   UPES Student Portal — Client Engine v2.0
   Clean, Professional, Secure & Real Data Integration
   ============================================================ */

'use strict';

const API_BASE = (window.location.protocol === 'http:' && window.location.port === '5000') ? '' : 'http://localhost:5000';

let currentStudent = null;
let authToken      = null;
let dashData       = null;
let historyRecords = [];
let chartInstance  = null;

const THRESHOLD = 75.0;

const SUBJECTS_MAP = {
  CSE101: 'Engineering Mathematics',
  CSE102: 'C Programming',
  CSE103: 'Engineering Physics',
  CSE104: 'Basic Electrical Engg.',
  CSE105: 'Environmental Studies',
  CSE106: 'Engineering Graphics',
};

// ── Initialization ───────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  const sessionStr = sessionStorage.getItem('student_session');
  if (!sessionStr) {
    window.location.href = 'student_login.html';
    return;
  }

  try {
    const session = JSON.parse(sessionStr);
    currentStudent = session.student;
    authToken = session.token;
  } catch (e) {
    sessionStorage.clear();
    window.location.href = 'student_login.html';
    return;
  }

  if (!currentStudent || !authToken) {
    sessionStorage.clear();
    window.location.href = 'student_login.html';
    return;
  }

  // Populate Header & Welcome info
  document.getElementById('userLabel').textContent = currentStudent.name || currentStudent.id;
  document.getElementById('welcomeName').textContent = `Welcome, ${currentStudent.name}`;
  document.getElementById('metaId').textContent = currentStudent.id;
  document.getElementById('metaDept').textContent = currentStudent.dept || 'CSE';
  document.getElementById('metaSem').textContent = currentStudent.semester || '1';
  document.getElementById('metaSec').textContent = currentStudent.section || 'CSE-1';

  // Load Real Data from Backend
  await loadDashboard();
  await loadNotifications();
  await loadHistory();
});

// ── Tab Navigation ───────────────────────────────────────────
function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.toggle('active', c.id === `tab-${name}`));
}

// ── Authenticated Fetch Helper ───────────────────────────────
async function authFetch(url, options = {}) {
  const fullUrl = url.startsWith('http') ? url : (API_BASE + url);
  options.headers = options.headers || {};
  if (authToken) {
    options.headers['Authorization'] = `Bearer ${authToken}`;
  }
  let res;
  try {
    res = await fetch(fullUrl, options);
  } catch (err) {
    showToast('Cannot connect to backend server on port 5000. Please start the server.', 'error');
    throw err;
  }
  if (res.status === 401 || res.status === 403) {
    showToast('Session expired or access denied. Please login again.', 'error');
    setTimeout(() => {
      sessionStorage.clear();
      window.location.href = 'student_login.html';
    }, 1500);
    throw new Error('Unauthorized');
  }
  return res;
}

// ── Dashboard Data ───────────────────────────────────────────
async function loadDashboard() {
  try {
    const res = await authFetch(`/api/student/dashboard?id=${encodeURIComponent(currentStudent.id)}&threshold=${THRESHOLD}`);
    dashData = await res.json();
    if (!dashData.success) throw new Error(dashData.message || 'Failed to load dashboard');
    renderOverview();
    renderSubjects();
    prefillCalculators();
  } catch (err) {
    showToast(err.message || 'Error loading attendance data', 'error');
  }
}

function renderOverview() {
  if (!dashData || !dashData.overall) return;
  const o = dashData.overall;

  document.getElementById('kpi-conducted').textContent = o.conducted;
  document.getElementById('kpi-attended').textContent  = o.attended;
  document.getElementById('kpi-missed').textContent    = o.missed;
  document.getElementById('kpi-pct').textContent       = o.percentage.toFixed(1) + '%';

  // Color percentage KPI
  const kpiCardPct = document.getElementById('kpiCardPct');
  kpiCardPct.className = 'kpi-card ' + (o.percentage >= 75 ? 'green' : o.percentage >= 60 ? 'amber' : 'red');

  // Buffer / Recovery KPI Card
  const bufferLabel = document.getElementById('bufferLabel');
  const bufferVal   = document.getElementById('bufferValue');
  const bufferSub   = document.getElementById('bufferSub');
  const bufferCard  = document.getElementById('kpiCardBuffer');

  if (o.is_eligible) {
    bufferLabel.textContent = 'Allowable Leaves';
    bufferVal.textContent   = `+${o.allowable_leaves}`;
    bufferSub.textContent   = 'Classes you can skip safely';
    bufferCard.className    = 'kpi-card green';
  } else {
    bufferLabel.textContent = 'Recovery Needed';
    bufferVal.textContent   = `${o.classes_needed}`;
    bufferSub.textContent   = 'Consecutive classes to attend';
    bufferCard.className    = 'kpi-card red';
  }

  // Progress Bar
  const fill = document.getElementById('progFill');
  fill.style.width = Math.min(o.percentage, 100) + '%';
  fill.className = 'progress-fill ' + (o.percentage >= 75 ? '' : o.percentage >= 60 ? 'amber' : 'red');

  document.getElementById('progPct').textContent = `${o.percentage.toFixed(2)}%`;
  document.getElementById('progLabel').textContent = o.is_eligible ? 'Eligible for Examination' : 'Below 75% Requirement (Defaulter)';

  // Overall Badge
  const badge = document.getElementById('overallBadge');
  badge.className = 'badge ' + (o.is_eligible ? 'badge-green' : 'badge-red');
  badge.textContent = o.is_eligible ? '✓ Eligible for Exams' : '⚠ Attendance Shortage';

  // Alert Banner
  const alert = document.getElementById('eligAlert');
  alert.style.display = 'flex';
  if (o.is_eligible) {
    alert.className = 'alert alert-success';
    alert.innerHTML = `<span>✅</span> <div><strong>Good Standing:</strong> Your overall attendance is <strong>${o.percentage.toFixed(1)}%</strong>. You can safely miss up to <strong>${o.allowable_leaves} more classes</strong> while maintaining required eligibility.</div>`;
  } else {
    alert.className = 'alert alert-danger';
    alert.innerHTML = `<span>❌</span> <div><strong>Attendance Shortage Warning:</strong> Your overall attendance is <strong>${o.percentage.toFixed(1)}%</strong> (below the mandatory 75% requirement). You must attend the next <strong>${o.classes_needed} consecutive classes</strong> to regain eligibility.</div>`;
  }

  renderChart();
}

function renderChart() {
  const ctx = document.getElementById('subjectChart');
  if (!ctx || !dashData.subjects) return;

  if (chartInstance) chartInstance.destroy();

  const labels = dashData.subjects.map(s => s.name);
  const pcts   = dashData.subjects.map(s => s.percentage);
  const colors = pcts.map(p => p >= 75 ? '#2E7D32' : p >= 60 ? '#E65100' : '#C62828');

  chartInstance = new Chart(ctx.getContext('2d'), {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Attendance %',
        data: pcts,
        backgroundColor: colors,
        borderRadius: 5,
        maxBarThickness: 45
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => `Attendance: ${ctx.raw.toFixed(1)}%`
          }
        }
      },
      scales: {
        y: {
          min: 0,
          max: 100,
          grid: { color: '#e2e8f0' },
          ticks: { callback: v => v + '%' }
        },
        x: {
          grid: { display: false },
          ticks: { font: { size: 11 } }
        }
      }
    }
  });
}

function renderSubjects() {
  const tbody = document.getElementById('subjectsBody');
  if (!dashData || !dashData.subjects || dashData.subjects.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:24px;">No subject records available.</td></tr>';
    return;
  }

  tbody.innerHTML = dashData.subjects.map(s => {
    const isElig = s.is_eligible;
    const color = s.percentage >= 75 ? 'var(--green)' : s.percentage >= 60 ? 'var(--amber)' : 'var(--red)';
    return `
      <tr>
        <td>
          <strong>${s.name}</strong><br>
          <span style="font-size:11.5px; color:var(--text-light); font-family:monospace;">${s.code}</span>
        </td>
        <td>${s.total}</td>
        <td><strong>${s.attended}</strong></td>
        <td>${s.missed}</td>
        <td>
          <div style="display:flex; align-items:center; gap:8px;">
            <div style="flex:1; height:7px; background:#e2e8f0; border-radius:4px; min-width:60px;">
              <div style="width:${Math.min(s.percentage, 100)}%; height:100%; border-radius:4px; background:${color};"></div>
            </div>
            <span style="font-weight:700; color:${color}; min-width:44px;">${s.percentage.toFixed(1)}%</span>
          </div>
        </td>
        <td>
          <span class="badge ${isElig ? 'badge-green' : 'badge-red'}">
            ${isElig ? '✓ Eligible' : '⚠ Below 75%'}
          </span>
        </td>
        <td>
          ${isElig
            ? `<span style="color:var(--green); font-weight:700;">+${s.allowable_leaves} leaves</span>`
            : `<span style="color:var(--red); font-weight:700;">Need ${s.classes_needed}</span>`}
        </td>
        <td style="color:var(--text-light); font-size:12.5px;">${s.remaining} classes</td>
      </tr>
    `;
  }).join('');
}

// ── Attendance History & Calendar ─────────────────────────────
async function loadHistory() {
  try {
    const res = await authFetch(`/api/student/history?id=${encodeURIComponent(currentStudent.id)}&subject=ALL`);
    const data = await res.json();
    historyRecords = data.records || [];
    renderHistory();
    renderCalendar();
    renderActivityFeed();
  } catch (err) {
    console.error('History load error:', err);
  }
}

function renderHistory() {
  const subFilter = document.getElementById('histSubject')?.value || 'ALL';
  const statFilter = document.getElementById('histStatus')?.value || 'ALL';

  const filtered = historyRecords.filter(r => {
    const matchSub  = (subFilter === 'ALL' || r.subject_id === subFilter);
    const matchStat = (statFilter === 'ALL' || r.status === statFilter);
    return matchSub && matchStat;
  });

  const tbody = document.getElementById('historyBody');
  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:24px; color:var(--text-light);">No matching attendance records found.</td></tr>';
    return;
  }

  tbody.innerHTML = filtered.map((r, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><strong>${r.date}</strong></td>
      <td>${r.subject_name || SUBJECTS_MAP[r.subject_id] || r.subject_id}</td>
      <td>
        <span class="badge ${r.status === 'Present' ? 'badge-green' : 'badge-red'}">
          ${r.status === 'Present' ? '● Present' : '○ Absent'}
        </span>
      </td>
      <td style="font-size:12px; color:var(--text-light); font-family:monospace;">${r.updated_by}</td>
      <td style="font-size:12px; color:var(--text-light);">${r.last_updated || '—'}</td>
    </tr>
  `).join('');
}

function renderCalendar() {
  const grid = document.getElementById('calendarGrid');
  if (!grid) return;

  if (historyRecords.length === 0) {
    grid.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:30px; color:var(--text-light);">No lecture calendar records found.</div>';
    return;
  }

  // Sort unique dates ascending
  const uniqueDates = [...new Set(historyRecords.map(r => r.date))].sort().reverse().slice(0, 36);

  grid.innerHTML = uniqueDates.map(dt => {
    const dayRecords = historyRecords.filter(r => r.date === dt);
    const presentCount = dayRecords.filter(r => r.status === 'Present').length;
    const totalCount = dayRecords.length;
    const isAllPresent = (presentCount === totalCount);

    return `
      <div class="calendar-day-card">
        <div class="cal-date">${dt}</div>
        <div style="font-size:11px; color:var(--text-mid); margin-bottom:4px;">
          ${presentCount} / ${totalCount} Present
        </div>
        <span class="badge ${isAllPresent ? 'badge-green' : 'badge-amber'}" style="font-size:10.5px; padding:2px 8px;">
          ${isAllPresent ? 'Full Attendance' : `${totalCount - presentCount} Absent`}
        </span>
      </div>
    `;
  }).join('');
}

function renderActivityFeed() {
  const feed = document.getElementById('recentActivityFeed');
  if (!feed) return;

  const recents = historyRecords.slice(0, 5);
  if (recents.length === 0) {
    feed.innerHTML = '<div style="text-align:center; padding:20px; color:var(--text-light);">No recent activity.</div>';
    return;
  }

  feed.innerHTML = recents.map(r => `
    <div class="activity-item">
      <div class="activity-icon ${r.status === 'Present' ? 'present' : 'absent'}">
        ${r.status === 'Present' ? '✓' : '✗'}
      </div>
      <div class="activity-details">
        <div class="activity-text">
          Marked <strong>${r.status}</strong> for ${r.subject_name || SUBJECTS_MAP[r.subject_id] || r.subject_id}
        </div>
        <div class="activity-time">Class Date: ${r.date} • Recorded by ${r.updated_by}</div>
      </div>
    </div>
  `).join('');
}

// ── Notifications ────────────────────────────────────────────
async function loadNotifications() {
  try {
    const res = await authFetch(`/api/student/notifications?id=${encodeURIComponent(currentStudent.id)}`);
    const data = await res.json();
    renderNotifications(data.notifications || [], data.unread_count || 0);
  } catch (err) {
    console.error('Notifications load error:', err);
  }
}

function renderNotifications(notifs, unreadCount) {
  const badge = document.getElementById('notifBadge');
  badge.textContent = unreadCount > 0 ? unreadCount : '';
  badge.dataset.count = unreadCount;

  const list = document.getElementById('notifList');
  if (notifs.length === 0) {
    list.innerHTML = '<div style="text-align:center; padding:30px; color:var(--text-light);">No notifications at this time.</div>';
    return;
  }

  list.innerHTML = notifs.map(n => {
    const icon = n.type === 'warning' ? '⚠️' : n.type === 'attendance_updated' ? '🔄' : '📌';
    return `
      <div class="notif-item ${n.read ? '' : 'unread'}">
        <div class="notif-icon">${icon}</div>
        <div style="flex:1;">
          <div class="notif-msg">${n.message}</div>
          <div class="notif-meta">
            ${n.created_at} ${n.subject_id && n.subject_id !== 'ALL' ? '• ' + (SUBJECTS_MAP[n.subject_id] || n.subject_id) : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

async function markAllNotificationsRead() {
  try {
    const res = await authFetch('/api/student/notifications/read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ student_id: currentStudent.id })
    });
    const data = await res.json();
    if (data.success) {
      document.getElementById('notifBadge').textContent = '';
      document.querySelectorAll('.notif-item.unread').forEach(el => el.classList.remove('unread'));
      showToast('All notifications marked as read', 'success');
    }
  } catch (err) {
    showToast('Failed to update notifications', 'error');
  }
}

// ── Calculators ──────────────────────────────────────────────
function prefillCalculators() {
  if (!dashData || !dashData.overall) return;
  const o = dashData.overall;

  document.getElementById('lc-attended').value = o.attended;
  document.getElementById('lc-total').value    = o.conducted;
  document.getElementById('lc-threshold').value = o.threshold;

  document.getElementById('rc-attended').value = o.attended;
  document.getElementById('rc-total').value    = o.conducted;
  document.getElementById('rc-planned').value  = 45;
  document.getElementById('rc-threshold').value = o.threshold;
}

async function calcLeave() {
  const attended  = parseInt(document.getElementById('lc-attended').value) || 0;
  const total     = parseInt(document.getElementById('lc-total').value) || 0;
  const extra     = parseInt(document.getElementById('lc-extra').value) || 0;
  const threshold = parseFloat(document.getElementById('lc-threshold').value) || 75.0;

  if (total <= 0) {
    showToast('Total classes must be greater than zero', 'error');
    return;
  }

  const box = document.getElementById('lc-result');
  box.style.display = 'block';

  try {
    const res = await authFetch('/api/student/calculator/leave', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ attended, total, extra_leaves: extra, threshold })
    });
    const d = await res.json();
    if (d.success) {
      box.className = 'alert ' + (d.is_still_eligible ? 'alert-success' : 'alert-danger');
      box.innerHTML = `
        <div>
          <strong>Simulation Results (${extra} additional leaves):</strong><br>
          • New Projected Attendance: <strong>${d.projected_pct.toFixed(2)}%</strong> (${attended} / ${d.projected_total})<br>
          • Eligibility Status: <strong>${d.is_still_eligible ? '✓ Still Eligible' : '✗ Ineligible (Below Threshold)'}</strong><br>
          • Maximum leaves you can take before dropping below ${threshold}%: <strong>${d.allowable_leaves} classes</strong>
        </div>
      `;
      return;
    }
  } catch (e) {}

  // Client Math Fallback
  const newTot = total + extra;
  const newPct = (attended / newTot) * 100.0;
  const eligible = (newPct >= threshold);
  const maxLeaves = Math.max(0, Math.floor((attended / (threshold / 100.0)) - total));

  box.className = 'alert ' + (eligible ? 'alert-success' : 'alert-danger');
  box.innerHTML = `
    <div>
      <strong>Simulation Results (${extra} additional leaves):</strong><br>
      • Projected Attendance: <strong>${newPct.toFixed(2)}%</strong><br>
      • Status: <strong>${eligible ? '✓ Eligible' : '✗ Ineligible'}</strong><br>
      • Maximum allowable leaves: <strong>${maxLeaves} classes</strong>
    </div>
  `;
}

async function calcRecovery() {
  const attended  = parseInt(document.getElementById('rc-attended').value) || 0;
  const total     = parseInt(document.getElementById('rc-total').value) || 0;
  const planned   = parseInt(document.getElementById('rc-planned').value) || 45;
  const threshold = parseFloat(document.getElementById('rc-threshold').value) || 75.0;

  if (total <= 0) {
    showToast('Total classes must be greater than zero', 'error');
    return;
  }

  const box = document.getElementById('rc-result');
  box.style.display = 'block';

  try {
    const res = await authFetch('/api/student/calculator/recovery', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ attended, total, total_planned: planned, threshold })
    });
    const d = await res.json();
    if (d.success) {
      const isAch = d.is_achievable;
      box.className = 'alert ' + (isAch ? 'alert-warning' : 'alert-danger');
      box.innerHTML = `
        <div>
          <strong>Recovery Action Plan:</strong><br>
          • Minimum Consecutive Classes to Attend: <strong>${d.needed} classes</strong><br>
          • Remaining Scheduled Lectures: <strong>${d.remaining_classes} classes</strong><br>
          • Projected Attendance after recovery: <strong>${d.projected_pct.toFixed(2)}%</strong><br>
          • Feasibility: <strong>${isAch ? '✓ Mathematically Achievable within normal schedule' : '✗ Impossible within scheduled classes without makeup sessions'}</strong>
        </div>
      `;
      return;
    }
  } catch (e) {}

  // Client Formula
  const r = threshold / 100.0;
  const currentPct = (attended / total) * 100.0;
  let needed = 0;
  if (currentPct < threshold) {
    needed = Math.ceil(((r * total) - attended) / (1.0 - r));
    needed = Math.max(0, needed);
  }
  const remaining = Math.max(0, planned - total);
  const isAchievable = (needed <= remaining);

  box.className = 'alert ' + (isAchievable ? 'alert-warning' : 'alert-danger');
  box.innerHTML = `
    <div>
      <strong>Recovery Action Plan:</strong><br>
      • Consecutive Classes Needed: <strong>${needed}</strong><br>
      • Feasibility: <strong>${isAchievable ? '✓ Achievable' : '✗ Exceeds remaining classes'}</strong>
    </div>
  `;
}

// ── Official Attendance Report (PDF Generation) ──────────────
function downloadStudentPDF() {
  if (!dashData || !dashData.overall) {
    showToast('Attendance data not loaded yet', 'error');
    return;
  }

  const { jsPDF } = window.jspdf || {};
  if (!jsPDF) {
    // If CDN is unavailable, open a printable official report view
    window.print();
    return;
  }

  try {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const o = dashData.overall;

    // Header
    doc.setFillColor(0, 33, 71); // UPES Navy
    doc.rect(0, 0, 210, 32, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text('UNIVERSITY OF PETROLEUM AND ENERGY STUDIES (UPES)', 14, 14);

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('School of Computer Science • Official Student Attendance Transcript', 14, 22);

    // Student Information Block
    doc.setTextColor(30, 41, 59);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('STUDENT PROFILE', 14, 42);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.text(`Student Name: ${currentStudent.name}`, 14, 50);
    doc.text(`Student ID / Reg No: ${currentStudent.id}`, 14, 56);
    doc.text(`Department: ${currentStudent.dept || 'CSE'}`, 14, 62);

    doc.text(`Semester: ${currentStudent.semester || 1}`, 115, 50);
    doc.text(`Section: ${currentStudent.section || 'CSE-1'}`, 115, 56);
    doc.text(`Report Date: ${new Date().toLocaleDateString('en-GB')}`, 115, 62);

    // Divider Line
    doc.setDrawColor(226, 232, 240);
    doc.line(14, 68, 196, 68);

    // Overall Summary Box
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(14, 72, 182, 26, 3, 3, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(0, 33, 71);
    doc.text('CUMULATIVE ATTENDANCE SUMMARY', 20, 80);

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(71, 85, 105);
    doc.text(`Conducted: ${o.conducted}    |    Attended: ${o.attended}    |    Missed: ${o.missed}`, 20, 88);

    doc.setFont('helvetica', 'bold');
    if (o.is_eligible) {
      doc.setTextColor(46, 125, 50);
      doc.text(`Overall Attendance: ${o.percentage.toFixed(1)}% — STATUS: ELIGIBLE FOR EXAMINATIONS`, 20, 94);
    } else {
      doc.setTextColor(198, 40, 40);
      doc.text(`Overall Attendance: ${o.percentage.toFixed(1)}% — STATUS: DEFAULTER (Requires ${o.classes_needed} classes)`, 20, 94);
    }

    // Table Header
    let y = 108;
    doc.setFillColor(0, 33, 71);
    doc.rect(14, y, 182, 8, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.text('Course Code', 18, y + 5.5);
    doc.text('Course Title', 45, y + 5.5);
    doc.text('Total', 115, y + 5.5);
    doc.text('Attended', 132, y + 5.5);
    doc.text('Percentage', 152, y + 5.5);
    doc.text('Eligibility', 175, y + 5.5);

    // Table Rows
    y += 8;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(30, 41, 59);

    dashData.subjects.forEach((s, idx) => {
      if (idx % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, y, 182, 8, 'F');
      }
      doc.text(s.code, 18, y + 5.5);
      doc.text(s.name.substring(0, 32), 45, y + 5.5);
      doc.text(String(s.total), 117, y + 5.5);
      doc.text(String(s.attended), 136, y + 5.5);
      doc.text(`${s.percentage.toFixed(1)}%`, 154, y + 5.5);
      
      if (s.is_eligible) {
        doc.setTextColor(46, 125, 50);
        doc.text('Eligible', 176, y + 5.5);
      } else {
        doc.setTextColor(198, 40, 40);
        doc.text('Defaulter', 176, y + 5.5);
      }
      doc.setTextColor(30, 41, 59);
      y += 8;
    });

    // Verification Footer
    y += 16;
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('Note: Mandatory attendance cutoff for UPES End-Semester Examinations is 75.0%.', 14, y);
    doc.text('This transcript is generated electronically by UPES Student Attendance Analysis System.', 14, y + 5);

    doc.save(`UPES_Attendance_Report_${currentStudent.id}.pdf`);
    showToast('Attendance Report (PDF) downloaded successfully ✅', 'success');
  } catch (err) {
    console.error('PDF error:', err);
    window.print();
  }
}

// ── Utility ──────────────────────────────────────────────────
function logout() {
  if (authToken) {
    fetch(API_BASE + '/api/auth/logout', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${authToken}` }
    }).catch(() => {});
  }
  sessionStorage.clear();
  window.location.href = 'student_login.html';
}

function showToast(msg, type = '') {
  const tc = document.getElementById('toasts');
  if (!tc) return;
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️'}</span> <div>${msg}</div>`;
  tc.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}
