// Embedded fallback dataset (ensures instant load even if opened directly via file://)
const FALLBACK_DATA = {
  summary: {
    total_students: 15,
    defaulters_count: 8,
    eligible_count: 7,
    honors_count: 4,
    class_average: 74.42,
    highest_percentage: 98.98,
    lowest_percentage: 47.45,
    threshold: 75.00,
    top_student: { roll: 104, name: "Ananya Iyer", percentage: 98.98 }
  },
  subjects: [
    { code: "MATH", name: "Mathematics", average_percentage: 74.17, total_attended: 445, total_conducted: 600 },
    { code: "DSA", name: "Data Structures", average_percentage: 75.33, total_attended: 452, total_conducted: 600 },
    { code: "OS", name: "Operating Systems", average_percentage: 73.33, total_attended: 418, total_conducted: 570 },
    { code: "DBMS", name: "Database Management", average_percentage: 76.50, total_attended: 459, total_conducted: 600 },
    { code: "CN", name: "Computer Networks", average_percentage: 72.63, total_attended: 414, total_conducted: 570 }
  ],
  students: [
    { roll_no: 101, name: "Aarav Sharma", department: "CSE", total_attended: 185, total_conducted: 196, overall_percentage: 94.39, is_defaulter: false, classes_needed: 0, safe_bunks: 50, subjects: [{ code: "MATH", name: "Mathematics", attended: 38, total: 40, percentage: 95.00 }, { code: "DSA", name: "Data Structures", attended: 36, total: 40, percentage: 90.00 }, { code: "OS", name: "Operating Systems", attended: 35, total: 38, percentage: 92.11 }, { code: "DBMS", name: "Database Management", attended: 39, total: 40, percentage: 97.50 }, { code: "CN", name: "Computer Networks", attended: 37, total: 38, percentage: 97.37 }] },
    { roll_no: 102, name: "Diya Patel", department: "CSE", total_attended: 117, total_conducted: 196, overall_percentage: 59.69, is_defaulter: true, classes_needed: 120, safe_bunks: 0, subjects: [{ code: "MATH", name: "Mathematics", attended: 24, total: 40, percentage: 60.00 }, { code: "DSA", name: "Data Structures", attended: 25, total: 40, percentage: 62.50 }, { code: "OS", name: "Operating Systems", attended: 22, total: 38, percentage: 57.89 }, { code: "DBMS", name: "Database Management", attended: 26, total: 40, percentage: 65.00 }, { code: "CN", name: "Computer Networks", attended: 20, total: 38, percentage: 52.63 }] },
    { roll_no: 103, name: "Rohan Verma", department: "CSE", total_attended: 152, total_conducted: 196, overall_percentage: 77.55, is_defaulter: false, classes_needed: 0, safe_bunks: 6, subjects: [{ code: "MATH", name: "Mathematics", attended: 32, total: 40, percentage: 80.00 }, { code: "DSA", name: "Data Structures", attended: 30, total: 40, percentage: 75.00 }, { code: "OS", name: "Operating Systems", attended: 29, total: 38, percentage: 76.32 }, { code: "DBMS", name: "Database Management", attended: 31, total: 40, percentage: 77.50 }, { code: "CN", name: "Computer Networks", attended: 30, total: 38, percentage: 78.95 }] },
    { roll_no: 104, name: "Ananya Iyer", department: "CSE", total_attended: 194, total_conducted: 196, overall_percentage: 98.98, is_defaulter: false, classes_needed: 0, safe_bunks: 62, subjects: [{ code: "MATH", name: "Mathematics", attended: 39, total: 40, percentage: 97.50 }, { code: "DSA", name: "Data Structures", attended: 40, total: 40, percentage: 100.00 }, { code: "OS", name: "Operating Systems", attended: 37, total: 38, percentage: 97.37 }, { code: "DBMS", name: "Database Management", attended: 40, total: 40, percentage: 100.00 }, { code: "CN", name: "Computer Networks", attended: 38, total: 38, percentage: 100.00 }] },
    { roll_no: 105, name: "Kabir Mehta", department: "CSE", total_attended: 93, total_conducted: 196, overall_percentage: 47.45, is_defaulter: true, classes_needed: 216, safe_bunks: 0, subjects: [{ code: "MATH", name: "Mathematics", attended: 18, total: 40, percentage: 45.00 }, { code: "DSA", name: "Data Structures", attended: 20, total: 40, percentage: 50.00 }, { code: "OS", name: "Operating Systems", attended: 19, total: 38, percentage: 50.00 }, { code: "DBMS", name: "Database Management", attended: 21, total: 40, percentage: 52.50 }, { code: "CN", name: "Computer Networks", attended: 15, total: 38, percentage: 39.47 }] },
    { roll_no: 106, name: "Ishaan Nair", department: "CSE", total_attended: 138, total_conducted: 196, overall_percentage: 70.41, is_defaulter: true, classes_needed: 36, safe_bunks: 0, subjects: [{ code: "MATH", name: "Mathematics", attended: 28, total: 40, percentage: 70.00 }, { code: "DSA", name: "Data Structures", attended: 29, total: 40, percentage: 72.50 }, { code: "OS", name: "Operating Systems", attended: 27, total: 38, percentage: 71.05 }, { code: "DBMS", name: "Database Management", attended: 28, total: 40, percentage: 70.00 }, { code: "CN", name: "Computer Networks", attended: 26, total: 38, percentage: 68.42 }] },
    { roll_no: 107, name: "Meera Joshi", department: "CSE", total_attended: 170, total_conducted: 196, overall_percentage: 86.73, is_defaulter: false, classes_needed: 0, safe_bunks: 30, subjects: [{ code: "MATH", name: "Mathematics", attended: 35, total: 40, percentage: 87.50 }, { code: "DSA", name: "Data Structures", attended: 34, total: 40, percentage: 85.00 }, { code: "OS", name: "Operating Systems", attended: 32, total: 38, percentage: 84.21 }, { code: "DBMS", name: "Database Management", attended: 36, total: 40, percentage: 90.00 }, { code: "CN", name: "Computer Networks", attended: 33, total: 38, percentage: 86.84 }] },
    { roll_no: 108, name: "Aditya Rao", department: "CSE", total_attended: 110, total_conducted: 196, overall_percentage: 56.12, is_defaulter: true, classes_needed: 148, safe_bunks: 0, subjects: [{ code: "MATH", name: "Mathematics", attended: 22, total: 40, percentage: 55.00 }, { code: "DSA", name: "Data Structures", attended: 24, total: 40, percentage: 60.00 }, { code: "OS", name: "Operating Systems", attended: 20, total: 38, percentage: 52.63 }, { code: "DBMS", name: "Database Management", attended: 23, total: 40, percentage: 57.50 }, { code: "CN", name: "Computer Networks", attended: 21, total: 38, percentage: 55.26 }] },
    { roll_no: 109, name: "Sanya Gupta", department: "CSE", total_attended: 184, total_conducted: 196, overall_percentage: 93.88, is_defaulter: false, classes_needed: 0, safe_bunks: 49, subjects: [{ code: "MATH", name: "Mathematics", attended: 37, total: 40, percentage: 92.50 }, { code: "DSA", name: "Data Structures", attended: 38, total: 40, percentage: 95.00 }, { code: "OS", name: "Operating Systems", attended: 36, total: 38, percentage: 94.74 }, { code: "DBMS", name: "Database Management", attended: 38, total: 40, percentage: 95.00 }, { code: "CN", name: "Computer Networks", attended: 35, total: 38, percentage: 92.11 }] },
    { roll_no: 110, name: "Vikram Singh", department: "CSE", total_attended: 146, total_conducted: 196, overall_percentage: 74.49, is_defaulter: true, classes_needed: 4, safe_bunks: 0, subjects: [{ code: "MATH", name: "Mathematics", attended: 30, total: 40, percentage: 75.00 }, { code: "DSA", name: "Data Structures", attended: 31, total: 40, percentage: 77.50 }, { code: "OS", name: "Operating Systems", attended: 28, total: 38, percentage: 73.68 }, { code: "DBMS", name: "Database Management", attended: 29, total: 40, percentage: 72.50 }, { code: "CN", name: "Computer Networks", attended: 28, total: 38, percentage: 73.68 }] },
    { roll_no: 111, name: "Pooja Reddy", department: "CSE", total_attended: 124, total_conducted: 196, overall_percentage: 63.27, is_defaulter: true, classes_needed: 92, safe_bunks: 0, subjects: [{ code: "MATH", name: "Mathematics", attended: 26, total: 40, percentage: 65.00 }, { code: "DSA", name: "Data Structures", attended: 25, total: 40, percentage: 62.50 }, { code: "OS", name: "Operating Systems", attended: 24, total: 38, percentage: 63.16 }, { code: "DBMS", name: "Database Management", attended: 27, total: 40, percentage: 67.50 }, { code: "CN", name: "Computer Networks", attended: 22, total: 38, percentage: 57.89 }] },
    { roll_no: 112, name: "Aryan Kulkarni", department: "CSE", total_attended: 180, total_conducted: 196, overall_percentage: 91.84, is_defaulter: false, classes_needed: 0, safe_bunks: 44, subjects: [{ code: "MATH", name: "Mathematics", attended: 36, total: 40, percentage: 90.00 }, { code: "DSA", name: "Data Structures", attended: 37, total: 40, percentage: 92.50 }, { code: "OS", name: "Operating Systems", attended: 34, total: 38, percentage: 89.47 }, { code: "DBMS", name: "Database Management", attended: 37, total: 40, percentage: 92.50 }, { code: "CN", name: "Computer Networks", attended: 36, total: 38, percentage: 94.74 }] },
    { roll_no: 113, name: "Sneha Deshmukh", department: "CSE", total_attended: 95, total_conducted: 196, overall_percentage: 48.47, is_defaulter: true, classes_needed: 208, safe_bunks: 0, subjects: [{ code: "MATH", name: "Mathematics", attended: 19, total: 40, percentage: 47.50 }, { code: "DSA", name: "Data Structures", attended: 22, total: 40, percentage: 55.00 }, { code: "OS", name: "Operating Systems", attended: 18, total: 38, percentage: 47.37 }, { code: "DBMS", name: "Database Management", attended: 20, total: 40, percentage: 50.00 }, { code: "CN", name: "Computer Networks", attended: 16, total: 38, percentage: 42.11 }] },
    { roll_no: 114, name: "Karthik Menon", department: "CSE", total_attended: 165, total_conducted: 196, overall_percentage: 84.18, is_defaulter: false, classes_needed: 0, safe_bunks: 24, subjects: [{ code: "MATH", name: "Mathematics", attended: 34, total: 40, percentage: 85.00 }, { code: "DSA", name: "Data Structures", attended: 33, total: 40, percentage: 82.50 }, { code: "OS", name: "Operating Systems", attended: 31, total: 38, percentage: 81.58 }, { code: "DBMS", name: "Database Management", attended: 35, total: 40, percentage: 87.50 }, { code: "CN", name: "Computer Networks", attended: 32, total: 38, percentage: 84.21 }] },
    { roll_no: 115, name: "Tanvi Bhatia", department: "CSE", total_attended: 135, total_conducted: 196, overall_percentage: 68.88, is_defaulter: true, classes_needed: 48, safe_bunks: 0, subjects: [{ code: "MATH", name: "Mathematics", attended: 27, total: 40, percentage: 67.50 }, { code: "DSA", name: "Data Structures", attended: 28, total: 40, percentage: 70.00 }, { code: "OS", name: "Operating Systems", attended: 26, total: 38, percentage: 68.42 }, { code: "DBMS", name: "Database Management", attended: 29, total: 40, percentage: 72.50 }, { code: "CN", name: "Computer Networks", attended: 25, total: 38, percentage: 65.79 }] }
  ]
};

let appState = {
  data: FALLBACK_DATA,
  activeFilter: "all",
  searchQuery: "",
  charts: {}
};

// Initialize Application
document.addEventListener("DOMContentLoaded", async () => {
  setupTheme();
  setupEventListeners();
  await loadData();
  renderDashboard();
});

// Load JSON data or use fallback
async function loadData() {
  const candidatePaths = [
    "../data/analytics_report.json",
    "data/analytics_report.json",
    "./data/analytics_report.json"
  ];

  for (const path of candidatePaths) {
    try {
      const res = await fetch(path);
      if (!res.ok) continue;

      const json = await res.json();
      if (json && json.summary && json.students) {
        appState.data = json;
        return;
      }
    } catch (err) {
      console.info(`JSON not available at ${path}; trying next fallback.`, err);
    }
  }

  console.info("Using embedded analytics data (standalone mode). ");
  appState.data = FALLBACK_DATA;
}

// Setup Event Listeners
function setupEventListeners() {
  // Theme Toggle
  const themeBtn = document.getElementById("themeToggleBtn");
  if (themeBtn) {
    themeBtn.addEventListener("click", toggleTheme);
  }

  // Filter Chips
  document.querySelectorAll(".filter-chip").forEach(chip => {
    chip.addEventListener("click", (e) => {
      document.querySelectorAll(".filter-chip").forEach(c => c.classList.remove("active"));
      e.target.classList.add("active");
      appState.activeFilter = e.target.getAttribute("data-filter");
      renderTable();
    });
  });

  // Search Input
  const searchInput = document.getElementById("tableSearch");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      appState.searchQuery = e.target.value.toLowerCase().trim();
      renderTable();
    });
  }

  // What-If Calculator Button
  const calcBtn = document.getElementById("calcSubmitBtn");
  if (calcBtn) {
    calcBtn.addEventListener("click", runWhatIfCalculator);
  }

  // Export CSV Button
  const exportBtn = document.getElementById("exportCsvBtn");
  if (exportBtn) {
    exportBtn.addEventListener("click", exportCurrentTableCsv);
  }

  // Modal Close
  const modalClose = document.getElementById("modalCloseBtn");
  const modalOverlay = document.getElementById("studentModal");
  if (modalClose && modalOverlay) {
    modalClose.addEventListener("click", () => modalOverlay.classList.remove("active"));
    modalOverlay.addEventListener("click", (e) => {
      if (e.target === modalOverlay) modalOverlay.classList.remove("active");
    });
  }
}

// Theme handling
function setupTheme() {
  const savedTheme = localStorage.getItem("att_theme") || "dark";
  document.documentElement.setAttribute("data-theme", savedTheme);
  updateThemeIcon(savedTheme);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute("data-theme") || "dark";
  const target = (current === "dark") ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", target);
  localStorage.setItem("att_theme", target);
  updateThemeIcon(target);
  // Re-render charts with updated theme colors
  renderCharts();
}

function updateThemeIcon(theme) {
  const iconSpan = document.getElementById("themeIcon");
  const textSpan = document.getElementById("themeText");
  if (iconSpan && textSpan) {
    if (theme === "dark") {
      iconSpan.textContent = "☀️";
      textSpan.textContent = "Light Mode";
    } else {
      iconSpan.textContent = "🌙";
      textSpan.textContent = "Dark Mode";
    }
  }
}

// Render Dashboard
function renderDashboard() {
  renderKpis();
  renderCharts();
  renderTable();
}

// Render KPI Cards
function renderKpis() {
  const { summary } = appState.data;
  if (!summary) return;

  const totalStudentsEl = document.getElementById("kpiTotalStudents");
  const classAvgEl = document.getElementById("kpiClassAvg");
  const progressBarEl = document.getElementById("kpiProgressBar");
  const defaultersEl = document.getElementById("kpiDefaulters");
  const defaultersSubEl = document.getElementById("kpiDefaultersSub");
  const eligibleEl = document.getElementById("kpiEligible");
  const honorsSubEl = document.getElementById("kpiHonorsSub");

  if (totalStudentsEl) totalStudentsEl.textContent = summary.total_students;
  if (classAvgEl) classAvgEl.textContent = `${summary.class_average.toFixed(1)}%`;
  if (progressBarEl) progressBarEl.style.width = `${Math.min(summary.class_average, 100)}%`;

  if (defaultersEl) defaultersEl.textContent = summary.defaulters_count;
  if (defaultersSubEl) {
    const defPct = ((summary.defaulters_count / summary.total_students) * 100).toFixed(0);
    defaultersSubEl.textContent = `${defPct}% of class below ${summary.threshold}%`;
  }

  if (eligibleEl) eligibleEl.textContent = summary.eligible_count;
  if (honorsSubEl) honorsSubEl.textContent = `${summary.honors_count} students with ≥90%`;

  const topperNameEl = document.getElementById("kpiTopperName");
  const topperPctEl = document.getElementById("kpiTopperPct");
  if (summary.top_student && topperNameEl && topperPctEl) {
    topperNameEl.textContent = summary.top_student.name;
    topperPctEl.textContent = `${summary.top_student.percentage.toFixed(1)}% (Roll #${summary.top_student.roll})`;
  }
}

// Render Charts with Chart.js
function renderCharts() {
  if (typeof Chart === "undefined") return;

  const isLight = document.documentElement.getAttribute("data-theme") === "light";
  const textColor = isLight ? "#334155" : "#94a3b8";
  const gridColor = isLight ? "rgba(0,0,0,0.06)" : "rgba(255,255,255,0.07)";

  const { summary, subjects, students } = appState.data;

  // 1. Doughnut Chart: Eligibility Ratio
  const ctxEligibility = document.getElementById("chartEligibility");
  if (ctxEligibility) {
    if (appState.charts.eligibility) appState.charts.eligibility.destroy();
    appState.charts.eligibility = new Chart(ctxEligibility, {
      type: "doughnut",
      data: {
        labels: ["Eligible (≥75%)", "Defaulters (<75%)"],
        datasets: [{
          data: [summary.eligible_count, summary.defaulters_count],
          backgroundColor: ["#10b981", "#ef4444"],
          borderWidth: 0,
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom",
            labels: { color: textColor, boxWidth: 12, padding: 14 }
          }
        },
        cutout: "68%"
      }
    });
  }

  // 2. Bar Chart: Subject-wise Attendance
  const ctxSubjects = document.getElementById("chartSubjects");
  if (ctxSubjects && subjects) {
    if (appState.charts.subjects) appState.charts.subjects.destroy();

    const labels = subjects.map(s => s.code);
    const dataVals = subjects.map(s => s.average_percentage);
    const bgColors = dataVals.map(val => val >= 75 ? "rgba(59, 130, 246, 0.85)" : "rgba(239, 68, 68, 0.85)");

    appState.charts.subjects = new Chart(ctxSubjects, {
      type: "bar",
      data: {
        labels: labels,
        datasets: [{
          label: "Subject Average %",
          data: dataVals,
          backgroundColor: bgColors,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            min: 50,
            max: 100,
            grid: { color: gridColor },
            ticks: {
              color: textColor,
              callback: (val) => val + "%"
            }
          },
          x: {
            grid: { display: false },
            ticks: { color: textColor }
          }
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (context) => `Avg: ${context.raw.toFixed(2)}%`
            }
          }
        }
      }
    });
  }
}

// Render Filtered Table
function renderTable() {
  const tbody = document.getElementById("studentsTableBody");
  if (!tbody) return;

  const { students } = appState.data;
  if (!students) return;

  const filtered = students.filter(st => {
    // Filter chip check
    if (appState.activeFilter === "defaulters" && !st.is_defaulter) return false;
    if (appState.activeFilter === "eligible" && st.is_defaulter) return false;
    if (appState.activeFilter === "honors" && st.overall_percentage < 90.0) return false;

    // Search query check
    if (appState.searchQuery) {
      const matchRoll = st.roll_no.toString().includes(appState.searchQuery);
      const matchName = st.name.toLowerCase().includes(appState.searchQuery);
      if (!matchRoll && !matchName) return false;
    }
    return true;
  });

  tbody.innerHTML = "";

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 24px; color: var(--text-muted);">No student records matched the active filter.</td></tr>`;
    return;
  }

  filtered.forEach(st => {
    const tr = document.createElement("tr");

    let statusPill = "";
    let actionPlan = "";

    if (st.is_defaulter) {
      statusPill = `<span class="status-pill defaulter">⚠️ Defaulter</span>`;
      actionPlan = `<span style="color: var(--accent-danger); font-weight: 600;">Need +${st.classes_needed} classes</span>`;
    } else if (st.overall_percentage >= 90) {
      statusPill = `<span class="status-pill honors">⭐ Honors</span>`;
      actionPlan = `<span style="color: var(--accent-purple);">Safe bunks: ${st.safe_bunks}</span>`;
    } else {
      statusPill = `<span class="status-pill eligible">✓ Eligible</span>`;
      actionPlan = `<span style="color: var(--accent-success);">Safe bunks: ${st.safe_bunks}</span>`;
    }

    const pctClass = st.overall_percentage >= 90 ? "pct-high" : (st.overall_percentage >= 75 ? "pct-med" : "pct-low");

    tr.innerHTML = `
      <td><strong>#${st.roll_no}</strong></td>
      <td><strong>${st.name}</strong></td>
      <td><span style="color: var(--text-muted);">${st.department}</span></td>
      <td>${st.total_attended} / ${st.total_conducted}</td>
      <td><span class="pct-badge ${pctClass}">${st.overall_percentage.toFixed(2)}%</span></td>
      <td>${statusPill}</td>
      <td>${actionPlan}</td>
      <td>
        <button class="btn-secondary" style="padding: 4px 10px; font-size: 0.78rem;" onclick="viewStudentModal(${st.roll_no})">
          Details
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// View Student Details in Modal
window.viewStudentModal = function(rollNo) {
  const student = appState.data.students.find(s => s.roll_no === rollNo);
  if (!student) return;

  const modal = document.getElementById("studentModal");
  document.getElementById("modalStudentName").textContent = student.name;
  document.getElementById("modalStudentInfo").textContent = `Roll No: ${student.roll_no} • Department: ${student.department}`;
  document.getElementById("modalOverallPct").textContent = `${student.overall_percentage.toFixed(2)}% (${student.total_attended}/${student.total_conducted} classes)`;

  const adviceEl = document.getElementById("modalActionAdvice");
  if (student.is_defaulter) {
    adviceEl.className = "calc-result-box alert-defaulter";
    adviceEl.innerHTML = `<strong>⚠️ Defaulter Notice:</strong> Must attend the next <strong>${student.classes_needed} consecutive classes</strong> to reach the mandatory 75% requirement.`;
  } else {
    adviceEl.className = "calc-result-box alert-safe";
    adviceEl.innerHTML = `<strong>✓ Eligible:</strong> Student is in good standing. Can miss up to <strong>${student.safe_bunks} classes</strong> and still maintain $\\ge 75\\%$.`;
  }

  const listEl = document.getElementById("modalSubjectList");
  listEl.innerHTML = "";

  student.subjects.forEach(sub => {
    const isSubShortage = sub.percentage < 75.0;
    const item = document.createElement("div");
    item.className = "subject-item";
    item.innerHTML = `
      <div>
        <div style="font-weight: 600;">${sub.name} (${sub.code})</div>
        <div style="font-size: 0.8rem; color: var(--text-muted);">${sub.attended} attended / ${sub.total} held</div>
      </div>
      <div style="text-align: right;">
        <span class="pct-badge ${isSubShortage ? 'pct-low' : 'pct-high'}">${sub.percentage.toFixed(1)}%</span>
        <div style="font-size: 0.75rem; color: ${isSubShortage ? 'var(--accent-danger)' : 'var(--accent-success)'};">
          ${isSubShortage ? 'Shortage' : 'Satisfactory'}
        </div>
      </div>
    `;
    listEl.appendChild(item);
  });

  modal.classList.add("active");
};

// Interactive What-If Calculator
function runWhatIfCalculator() {
  const attendedInput = document.getElementById("calcAttended");
  const totalInput = document.getElementById("calcTotal");
  const targetInput = document.getElementById("calcTarget");
  const resultBox = document.getElementById("calcResult");

  const attended = parseInt(attendedInput.value, 10);
  const total = parseInt(totalInput.value, 10);
  const targetPct = parseFloat(targetInput.value) || 75.0;

  if (isNaN(attended) || isNaN(total) || total <= 0 || attended < 0 || attended > total) {
    alert("Please enter valid positive numbers where Attended is not greater than Total.");
    return;
  }

  const currentPct = (attended / total) * 100;
  const p = targetPct / 100;

  if (currentPct < targetPct) {
    // Consecutive needed
    const numerator = (p * total) - attended;
    const denominator = 1.0 - p;
    const needed = Math.ceil(numerator / denominator);

    resultBox.className = "calc-result-box alert-defaulter";
    resultBox.innerHTML = `
      <strong>Current Attendance: ${currentPct.toFixed(2)}% (Below ${targetPct}%)</strong><br>
      You must attend the next <strong>${needed} consecutive classes</strong> without missing any to reach ${targetPct}%.<br>
      <small style="color: var(--text-muted);">Future status will be: ${attended + needed} / ${total + needed} = ${(((attended + needed) / (total + needed)) * 100).toFixed(2)}%</small>
    `;
  } else {
    // Safe bunks
    const numerator = attended - (p * total);
    const bunks = Math.floor(numerator / p);

    resultBox.className = "calc-result-box alert-safe";
    resultBox.innerHTML = `
      <strong>Current Attendance: ${currentPct.toFixed(2)}% (Eligible!)</strong><br>
      You have a buffer! You can safely miss up to <strong>${bunks} consecutive classes</strong> and still maintain $\\ge ${targetPct}\\%$.<br>
      <small style="color: var(--text-muted);">If you miss ${bunks} classes: ${attended} / ${total + bunks} = ${((attended / (total + bunks)) * 100).toFixed(2)}%</small>
    `;
  }
}

// Export Table to CSV
function exportCurrentTableCsv() {
  const { students } = appState.data;
  if (!students) return;

  let csvContent = "data:text/csv;charset=utf-8,";
  csvContent += "RollNo,Name,Department,Attended,Total,Percentage,Status,ClassesNeeded\r\n";

  students.forEach(st => {
    const status = st.is_defaulter ? "Defaulter" : "Eligible";
    csvContent += `${st.roll_no},"${st.name}",${st.department},${st.total_attended},${st.total_conducted},${st.overall_percentage.toFixed(2)},${status},${st.classes_needed}\r\n`;
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "student_attendance_analysis.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
