import math

def calculate_attendance_percentage(attended: int, total: int) -> float:
    """Calculate attendance percentage safely without divide-by-zero."""
    if total <= 0:
        return 0.0
    return round((attended / total) * 100.0, 2)

def calculate_recovery_classes(attended: int, total: int, threshold_pct: float = 75.0, total_planned: int = 45) -> dict:
    """
    Calculate consecutive classes needed to recover eligibility.
    Formula: n = ceiling((R * T - A) / (1 - R))
    """
    r = threshold_pct / 100.0
    current_pct = calculate_attendance_percentage(attended, total)
    
    if current_pct >= threshold_pct:
        return {
            "needed": 0,
            "projected_attended": attended,
            "projected_total": total,
            "projected_pct": current_pct,
            "is_achievable": True,
            "remaining_classes": max(0, total_planned - total),
            "message": f"Already eligible ({current_pct}% >= {threshold_pct}%)."
        }
    
    if r >= 1.0:
        return {
            "needed": -1,
            "is_achievable": False,
            "message": "Cannot reach 100% attendance if any class has been missed."
        }
    
    numerator = (r * total) - attended
    denominator = 1.0 - r
    needed = math.ceil(numerator / denominator)
    needed = max(0, needed)
    
    projected_attended = attended + needed
    projected_total = total + needed
    projected_pct = calculate_attendance_percentage(projected_attended, projected_total)
    
    remaining_classes = max(0, total_planned - total)
    is_achievable = needed <= remaining_classes
    
    if is_achievable:
        msg = f"Must attend the next {needed} consecutive classes to reach {threshold_pct}%."
    else:
        msg = (
            f"Mathematical requirement is {needed} classes, but only {remaining_classes} "
            f"classes remain in this semester. Standard recovery is impossible without makeup classes."
        )
    
    return {
        "needed": needed,
        "projected_attended": projected_attended,
        "projected_total": projected_total,
        "projected_pct": projected_pct,
        "is_achievable": is_achievable,
        "remaining_classes": remaining_classes,
        "message": msg
    }

def calculate_allowable_leaves(attended: int, total: int, threshold_pct: float = 75.0) -> dict:
    """
    Maximum additional classes that can be missed while retaining eligibility.
    Formula: x = floor((A / R) - T)
    """
    r = threshold_pct / 100.0
    current_pct = calculate_attendance_percentage(attended, total)
    
    if current_pct < threshold_pct:
        return {
            "allowable_leaves": 0,
            "is_eligible": False,
            "message": f"Currently below {threshold_pct}%. No leaves can be taken."
        }
    
    if r <= 0.0 or total == 0:
        return {
            "allowable_leaves": 0,
            "is_eligible": True,
            "message": "Eligible"
        }
    
    max_total = math.floor(attended / r)
    allowable = max_total - total
    allowable = max(0, allowable)
    
    projected_total = total + allowable
    projected_pct = calculate_attendance_percentage(attended, projected_total)
    
    return {
        "allowable_leaves": allowable,
        "is_eligible": True,
        "projected_total": projected_total,
        "projected_pct": projected_pct,
        "message": f"Can safely miss up to {allowable} consecutive classes and maintain >= {threshold_pct}%."
    }

def simulate_hypothetical_leave(attended: int, total: int, leave_count: int, threshold_pct: float = 75.0) -> dict:
    """What-if leave simulator."""
    new_attended = attended
    new_total = total + leave_count
    new_pct = calculate_attendance_percentage(new_attended, new_total)
    is_still_eligible = new_pct >= threshold_pct
    
    pct_drop = round(calculate_attendance_percentage(attended, total) - new_pct, 2)
    
    return {
        "additional_leaves": leave_count,
        "current_pct": calculate_attendance_percentage(attended, total),
        "projected_attended": new_attended,
        "projected_total": new_total,
        "projected_pct": new_pct,
        "pct_drop": pct_drop,
        "is_still_eligible": is_still_eligible,
        "status": "Eligible" if is_still_eligible else "Defaulter (Critical)"
    }
