@echo off
echo =====================================================================
echo    Compiling Student Attendance Analytics Engine (C)
echo =====================================================================

where gcc >nul 2>nul
if %errorlevel% neq 0 (
    echo [WARNING] gcc was not found in your standard PATH.
    echo If you have MinGW, Code::Blocks, or Dev-C++ installed, ensure gcc is in PATH.
    echo Trying to compile using C:\MinGW\bin\gcc.exe if available...
)

gcc -Wall -Wextra -std=c99 -I c_engine/include c_engine/src/*.c -o attendance_analyzer.exe -lm

if %errorlevel% equ 0 (
    echo [SUCCESS] Compilation succeeded!
    echo Created executable: attendance_analyzer.exe
    echo.
    echo Running Attendance Analyzer...
    echo =====================================================================
    attendance_analyzer.exe data/attendance.csv
) else (
    echo [ERROR] Compilation failed. Please check your compiler configuration.
)

pause
