"""
UPES Student Attendance Analysis System — Automated End-to-End Test Suite
Tests: Calculations, Persistence, Security/RBAC, Authentication, CSV Uploads & API Endpoints
"""

import sys
import time
import json
import urllib.request
import urllib.error
import urllib.parse
import os
import math
import subprocess

BASE_URL = "http://localhost:5000"

def log_test(name, passed, detail=""):
    mark = "[PASS]" if passed else "[FAIL]"
    print(f" {mark} {name}")
    if detail:
        print(f"        -> {detail}")
    if not passed:
        raise AssertionError(f"Test failed: {name} - {detail}")

def http_req(path, method="GET", data=None, headers=None):
    url = f"{BASE_URL}{path}"
    req_headers = {"Content-Type": "application/json", "Connection": "close"}
    if headers:
        req_headers.update(headers)
    
    encoded_data = json.dumps(data).encode("utf-8") if data is not None else None
    req = urllib.request.Request(url, data=encoded_data, headers=req_headers, method=method)
    
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            body = resp.read().decode("utf-8")
            status = resp.status
            try:
                parsed_json = json.loads(body)
            except Exception:
                parsed_json = None
            return status, body, parsed_json
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        try:
            parsed_json = json.loads(body)
        except Exception:
            parsed_json = None
        return e.code, body, parsed_json
    except Exception as e:
        return 0, str(e), None

def run_calculation_tests():
    print("\n--- 1. Testing Mathematical Calculation Engine ---")
    
    # 1. Attendance Percentage
    from calculations import calculate_attendance_percentage, calculate_recovery_classes, calculate_allowable_leaves, simulate_hypothetical_leave
    
    pct_zero = calculate_attendance_percentage(0, 0)
    log_test("Percentage divide-by-zero protection (0/0)", pct_zero == 0.0, f"Got: {pct_zero}")
    
    pct_normal = calculate_attendance_percentage(24, 30)
    log_test("Percentage calculation (24/30)", pct_normal == 80.0, f"Got: {pct_normal}")
    
    # 2. Allowable Leaves
    # If attended = 24, total = 24, threshold = 75%:
    # max_total = floor(24 / 0.75) = 32 -> allowable = 32 - 24 = 8
    res_leaves = calculate_allowable_leaves(24, 24, 75.0)
    log_test("Allowable leaves for 100% attendee (24/24 @ 75%)", res_leaves["allowable_leaves"] == 8, f"Got: {res_leaves['allowable_leaves']}")
    
    # If already below threshold: allowable leaves must be 0
    res_below = calculate_allowable_leaves(15, 24, 75.0)
    log_test("Allowable leaves for defaulter (15/24 = 62.5% @ 75%)", res_below["allowable_leaves"] == 0, f"Got: {res_below['allowable_leaves']}")
    
    # 3. Recovery Classes
    # If attended = 15, total = 24, threshold = 75%:
    # r = 0.75, num = 0.75*24 - 15 = 18 - 15 = 3; den = 1 - 0.75 = 0.25 -> n = ceil(3 / 0.25) = 12
    res_rec = calculate_recovery_classes(15, 24, 75.0, total_planned=45)
    log_test("Recovery classes needed (15/24 @ 75%)", res_rec["needed"] == 12, f"Got: {res_rec['needed']}")
    log_test("Recovery feasibility check (12 needed <= 21 remaining)", res_rec["is_achievable"] == True, f"Achievable: {res_rec['is_achievable']}")
    
    # Check infeasible scenario
    res_infeasible = calculate_recovery_classes(10, 35, 75.0, total_planned=45)
    log_test("Infeasible recovery detection (needed > remaining)", res_infeasible["is_achievable"] == False, f"Needed: {res_infeasible['needed']}, Remaining: {res_infeasible['remaining_classes']}")

def run_api_and_security_tests():
    print("\n--- 2. Testing C Server API, Authentication & Security ---")
    
    # Root Page Check
    status, body, _ = http_req("/")
    log_test("Root endpoint HTTP 200", status == 200, f"Status: {status}")
    log_test("Root page contains UPES branding", "UPES Student Attendance Analysis System" in body or "UPES Attendance" in body)

    # Student Login - Valid
    status, body, data = http_req("/api/auth/student-login", method="POST", data={
        "student_id": "UPES5000101",
        "password": "student123"
    })
    log_test("Student login (Valid credentials)", status == 200 and data.get("success") == True, f"Status: {status}")
    student_token = data.get("token")
    log_test("Student session token issued", bool(student_token), f"Token: {student_token[:16]}...")

    # Student Login - Invalid
    status, body, data = http_req("/api/auth/student-login", method="POST", data={
        "student_id": "UPES5000101",
        "password": "wrongpassword"
    })
    log_test("Student login (Invalid password rejected)", status == 401 and data.get("success") == False, f"Status: {status}")

    # Faculty Login - Valid
    status, body, data = http_req("/api/auth/faculty-login", method="POST", data={
        "faculty_id": "FAC101",
        "password": "faculty123"
    })
    log_test("Faculty login (Valid credentials)", status == 200 and data.get("success") == True, f"Status: {status}")
    faculty_token = data.get("token")
    log_test("Faculty session token issued", bool(faculty_token), f"Token: {faculty_token[:16]}...")

    # Student Dashboard API
    status, body, data = http_req(f"/api/student/dashboard?id=UPES5000101", headers={"Authorization": f"Bearer {student_token}"})
    log_test("Student dashboard data retrieval", status == 200 and data.get("success") == True, f"Status: {status}")
    log_test("Student dashboard subjects list has 6 courses", len(data.get("subjects", [])) == 6, f"Count: {len(data.get('subjects', []))}")
    log_test("Overall percentage >= 75%", data.get("overall", {}).get("percentage", 0) >= 75.0, f"Percentage: {data.get('overall', {}).get('percentage')}%")

    # Student History API
    status, body, data = http_req(f"/api/student/history?id=UPES5000101", headers={"Authorization": f"Bearer {student_token}"})
    log_test("Student attendance history retrieval", status == 200 and data.get("success") == True, f"Status: {status}")
    log_test("History has recorded entries", len(data.get("records", [])) > 0, f"Count: {len(data.get('records', []))}")

    # Student Notifications API
    status, body, data = http_req(f"/api/student/notifications?id=UPES5000101", headers={"Authorization": f"Bearer {student_token}"})
    log_test("Student notifications retrieval", status == 200 and data.get("success") == True, f"Status: {status}")

    # RBAC: Student attempting to snoop on another student
    status, body, data = http_req(f"/api/student/dashboard?id=UPES5000102", headers={"Authorization": f"Bearer {student_token}"})
    log_test("RBAC: Student forbidden from viewing another student's dashboard", status == 403, f"Status: {status} (Expected 403)")

    # Faculty Overview API
    status, body, data = http_req("/api/faculty/overview", headers={"Authorization": f"Bearer {faculty_token}"})
    log_test("Faculty overview retrieval", status == 200 and data.get("success") == True, f"Status: {status}")
    log_test("Total students count is 20", data.get("total_students") == 20, f"Count: {data.get('total_students')}")
    log_test("Defaulters count tracked", data.get("defaulters_count", 0) > 0, f"Defaulters: {data.get('defaulters_count')}")

    # Manual Attendance Marking API
    test_date = "2026-11-09"
    status, body, data = http_req("/api/faculty/attendance/manual", method="POST", headers={"Authorization": f"Bearer {faculty_token}"}, data={
        "subject_id": "CSE102",
        "date": test_date,
        "faculty_id": "FAC101",
        "records": [
            {"student_id": "UPES5000101", "status": "Present"},
            {"student_id": "UPES5000102", "status": "Absent"}
        ]
    })
    log_test("Manual attendance synchronization", status == 200 and data.get("success") == True, f"Status: {status}")

    # CSV Upload API (Testing fix for nested strtok with multiple rows)
    csv_sample = (
        "student_id,name,date,status\n"
        "UPES5000101,Aarav Sharma,2026-11-10,Present\n"
        "UPES5000102,Diya Patel,2026-11-10,Present\n"
        "UPES5000103,Rohan Verma,2026-11-10,Absent\n"
        "UPES5000104,Ananya Iyer,2026-11-10,Present\n"
        "INVALID_ID,Fake Student,2026-11-10,Present\n"
    )
    status, body, data = http_req("/api/faculty/attendance/upload", method="POST", headers={"Authorization": f"Bearer {faculty_token}"}, data={
        "subject_id": "CSE102",
        "faculty_id": "FAC101",
        "file_name": "test_batch.csv",
        "csv_data": csv_sample
    })
    log_test("Multi-line CSV upload (nested strtok fix verification)", status == 200 and data.get("processed") == 4, f"Processed: {data.get('processed')}")
    log_test("Invalid student row rejected with diagnostic error", data.get("rejected") == 1, f"Rejected: {data.get('rejected')}")

    # Security: Path Traversal Attempt
    status, body, _ = http_req("/../../c_src/server.c")
    log_test("Security: Path traversal blocked (HTTP 403 or 404)", status in (403, 404), f"Status: {status}")

    # Logout
    status, body, data = http_req("/api/auth/logout", method="POST", headers={"Authorization": f"Bearer {student_token}"})
    log_test("Student logout", status == 200 and data.get("success") == True, f"Status: {status}")

if __name__ == "__main__":
    print("=================================================================")
    print("   UPES Student Attendance Analyzer — Test Verification Suite    ")
    print("=================================================================")
    try:
        run_calculation_tests()
        run_api_and_security_tests()
        print("\n=================================================================")
        print(" [ALL TESTS PASSED SUCCESSFULLY! 100% VERIFIED]                 ")
        print("=================================================================")
    except Exception as e:
        print(f"\n[TEST SUITE FAILURE]: {e}")
        sys.exit(1)
